--
-- PostgreSQL database dump
--

\restrict JCdsKm7Spy8Yc6FkjIlGyLd53f5dc39GvsKPVlYaouJXYOMutRd6dKVbXTmPoEl

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: alisaberi
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO alisaberi;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: deletion_reason; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.deletion_reason AS ENUM (
    'user_requested',
    'admin_action',
    'compliance',
    'data_retention_policy',
    'account_violation',
    'test_cleanup',
    'inactive_account'
);


ALTER TYPE auth.deletion_reason OWNER TO alisaberi;

--
-- Name: device_type; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.device_type AS ENUM (
    'web',
    'ios',
    'android',
    'desktop',
    'other'
);


ALTER TYPE auth.device_type OWNER TO alisaberi;

--
-- Name: enrollment_status; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.enrollment_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'expired',
    'failed'
);


ALTER TYPE auth.enrollment_status OWNER TO alisaberi;

--
-- Name: mfa_type; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.mfa_type AS ENUM (
    'totp',
    'sms',
    'email',
    'webauthn',
    'backup_codes'
);


ALTER TYPE auth.mfa_type OWNER TO alisaberi;

--
-- Name: provider_type; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.provider_type AS ENUM (
    'oauth2',
    'saml',
    'oidc',
    'ldap'
);


ALTER TYPE auth.provider_type OWNER TO alisaberi;

--
-- Name: user_status; Type: TYPE; Schema: auth; Owner: alisaberi
--

CREATE TYPE auth.user_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'deleted',
    'disabled',
    'marked_for_deletion'
);


ALTER TYPE auth.user_status OWNER TO alisaberi;

--
-- Name: custodian_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.custodian_status AS ENUM (
    'pending',
    'active',
    'suspended',
    'revoked'
);


ALTER TYPE public.custodian_status OWNER TO alisaberi;

--
-- Name: custodian_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.custodian_type AS ENUM (
    'individual',
    'professional',
    'institutional',
    'monay_service'
);


ALTER TYPE public.custodian_type OWNER TO alisaberi;

--
-- Name: recovery_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.recovery_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'completed',
    'expired',
    'cancelled'
);


ALTER TYPE public.recovery_status OWNER TO alisaberi;

--
-- Name: verification_level; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.verification_level AS ENUM (
    'basic',
    'verified',
    'enhanced'
);


ALTER TYPE public.verification_level OWNER TO alisaberi;

--
-- Name: calculate_risk_score(uuid, inet, character varying, character varying); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.calculate_risk_score(p_user_id uuid, p_ip_address inet, p_device_fingerprint character varying, p_session_id character varying) RETURNS TABLE(risk_score integer, risk_level character varying, risk_factors jsonb, requires_mfa boolean, requires_challenge boolean, should_block boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_score INTEGER := 0;
    v_factors JSONB := '[]'::jsonb;
    v_ip_rep RECORD;
    v_user_profile RECORD;
    v_device RECORD;
BEGIN
    -- Check IP reputation
    SELECT * INTO v_ip_rep FROM auth.ip_reputation WHERE ip_address = p_ip_address;
    IF FOUND THEN
        IF v_ip_rep.is_tor THEN
            v_score := v_score + 30;
            v_factors := v_factors || jsonb_build_object('factor', 'tor_network', 'score', 30);
        END IF;
        IF v_ip_rep.is_vpn THEN
            v_score := v_score + 20;
            v_factors := v_factors || jsonb_build_object('factor', 'vpn_detected', 'score', 20);
        END IF;
        IF v_ip_rep.reputation_score < 30 THEN
            v_score := v_score + 25;
            v_factors := v_factors || jsonb_build_object('factor', 'low_ip_reputation', 'score', 25);
        END IF;
    ELSE
        -- Unknown IP
        v_score := v_score + 10;
        v_factors := v_factors || jsonb_build_object('factor', 'unknown_ip', 'score', 10);
    END IF;
    
    -- Check user risk profile
    SELECT * INTO v_user_profile FROM auth.user_risk_profiles WHERE user_id = p_user_id;
    IF FOUND THEN
        IF v_user_profile.current_score > 70 THEN
            v_score := v_score + 20;
            v_factors := v_factors || jsonb_build_object('factor', 'high_user_risk', 'score', 20);
        END IF;
        IF v_user_profile.anomaly_count > 5 THEN
            v_score := v_score + 15;
            v_factors := v_factors || jsonb_build_object('factor', 'multiple_anomalies', 'score', 15);
        END IF;
    END IF;
    
    -- Check device fingerprint
    IF p_device_fingerprint IS NOT NULL THEN
        SELECT * INTO v_device FROM auth.device_fingerprints 
        WHERE user_id = p_user_id AND fingerprint_hash = p_device_fingerprint;
        
        IF NOT FOUND THEN
            v_score := v_score + 15;
            v_factors := v_factors || jsonb_build_object('factor', 'unknown_device', 'score', 15);
        ELSIF NOT v_device.is_trusted THEN
            v_score := v_score + 10;
            v_factors := v_factors || jsonb_build_object('factor', 'untrusted_device', 'score', 10);
        END IF;
    END IF;
    
    -- Determine risk level and actions
    risk_score := v_score;
    risk_factors := v_factors;
    
    CASE
        WHEN v_score <= 30 THEN
            risk_level := 'low';
            requires_mfa := false;
            requires_challenge := false;
            should_block := false;
        WHEN v_score <= 60 THEN
            risk_level := 'medium';
            requires_mfa := true;
            requires_challenge := false;
            should_block := false;
        WHEN v_score <= 80 THEN
            risk_level := 'high';
            requires_mfa := true;
            requires_challenge := true;
            should_block := false;
        ELSE
            risk_level := 'critical';
            requires_mfa := true;
            requires_challenge := true;
            should_block := true;
    END CASE;
    
    -- Record the assessment
    INSERT INTO auth.risk_assessments (
        user_id, session_id, score, level, factors,
        requires_mfa, requires_challenge, should_block
    ) VALUES (
        p_user_id, p_session_id, v_score, risk_level, v_factors,
        requires_mfa, requires_challenge, should_block
    );
    
    RETURN NEXT;
END;
$$;


ALTER FUNCTION auth.calculate_risk_score(p_user_id uuid, p_ip_address inet, p_device_fingerprint character varying, p_session_id character varying) OWNER TO alisaberi;

--
-- Name: FUNCTION calculate_risk_score(p_user_id uuid, p_ip_address inet, p_device_fingerprint character varying, p_session_id character varying); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.calculate_risk_score(p_user_id uuid, p_ip_address inet, p_device_fingerprint character varying, p_session_id character varying) IS 'Calculate risk score for an authentication attempt';


--
-- Name: calculate_user_risk_score(uuid); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.calculate_user_risk_score(p_user_id uuid) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_score INTEGER := 0;
    v_account_age_days INTEGER;
    v_failed_attempts INTEGER;
    v_device_count INTEGER;
    v_location_count INTEGER;
BEGIN
    -- Account age factor
    SELECT EXTRACT(DAY FROM NOW() - created_at) INTO v_account_age_days
    FROM auth.users WHERE id = p_user_id;
    
    IF v_account_age_days < 7 THEN
        v_score := v_score + 10;
    END IF;
    
    -- Recent failed login attempts
    SELECT COUNT(*) INTO v_failed_attempts
    FROM auth.audit_logs
    WHERE user_id = p_user_id 
    AND action = 'login' 
    AND status = 'failure'
    AND created_at > NOW() - INTERVAL '1 hour';
    
    v_score := v_score + (v_failed_attempts * 5);
    
    -- Multiple devices
    SELECT COUNT(DISTINCT device_id) INTO v_device_count
    FROM auth.sessions
    WHERE user_id = p_user_id
    AND created_at > NOW() - INTERVAL '30 days';
    
    IF v_device_count > 5 THEN
        v_score := v_score + 10;
    END IF;
    
    -- Multiple locations
    SELECT COUNT(DISTINCT ip_address) INTO v_location_count
    FROM auth.audit_logs
    WHERE user_id = p_user_id
    AND created_at > NOW() - INTERVAL '7 days';
    
    IF v_location_count > 10 THEN
        v_score := v_score + 15;
    END IF;
    
    -- Cap at 100
    RETURN LEAST(v_score, 100);
END;
$$;


ALTER FUNCTION auth.calculate_user_risk_score(p_user_id uuid) OWNER TO alisaberi;

--
-- Name: check_auto_block_ip(inet); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.check_auto_block_ip(check_ip inet) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_critical_count INTEGER;
    v_high_count INTEGER;
BEGIN
    -- Count recent critical and high severity events
    SELECT 
        COUNT(*) FILTER (WHERE severity = 'critical'),
        COUNT(*) FILTER (WHERE severity = 'high')
    INTO v_critical_count, v_high_count
    FROM auth.security_events
    WHERE ip_address = check_ip
    AND created_at > NOW() - INTERVAL '1 hour';
    
    -- Auto-block if thresholds exceeded
    IF v_critical_count >= 3 OR v_high_count >= 10 THEN
        INSERT INTO auth.ip_blacklist (
            ip_address, reason, threat_score, auto_blocked, blocked_until
        ) VALUES (
            check_ip,
            format('Auto-blocked: %s critical, %s high severity events', v_critical_count, v_high_count),
            LEAST(100, (v_critical_count * 20 + v_high_count * 5)),
            true,
            NOW() + INTERVAL '24 hours'
        )
        ON CONFLICT (ip_address) DO UPDATE
        SET blocked_until = GREATEST(EXCLUDED.blocked_until, auth.ip_blacklist.blocked_until),
            threat_score = GREATEST(EXCLUDED.threat_score, auth.ip_blacklist.threat_score);
    END IF;
END;
$$;


ALTER FUNCTION auth.check_auto_block_ip(check_ip inet) OWNER TO alisaberi;

--
-- Name: FUNCTION check_auto_block_ip(check_ip inet); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.check_auto_block_ip(check_ip inet) IS 'Check if an IP should be auto-blocked based on recent events';


--
-- Name: cleanup_expired_otp_codes(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.cleanup_expired_otp_codes() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM auth.otp_codes
  WHERE expires_at < CURRENT_TIMESTAMP
  OR (used_at IS NOT NULL AND used_at < CURRENT_TIMESTAMP - INTERVAL '24 hours');
END;
$$;


ALTER FUNCTION auth.cleanup_expired_otp_codes() OWNER TO alisaberi;

--
-- Name: cleanup_old_security_events(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.cleanup_old_security_events() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Delete events older than 90 days
    DELETE FROM auth.security_events 
    WHERE created_at < NOW() - INTERVAL '90 days'
    AND severity != 'critical';
    
    -- Delete rate limit violations older than 30 days
    DELETE FROM auth.rate_limit_violations
    WHERE created_at < NOW() - INTERVAL '30 days';
    
    -- Delete expired IP blacklist entries
    DELETE FROM auth.ip_blacklist
    WHERE blocked_until < NOW()
    AND permanent = false;
    
    -- Delete expired IP whitelist entries
    DELETE FROM auth.ip_whitelist
    WHERE expires_at < NOW();
    
    -- Delete old traffic patterns
    DELETE FROM auth.traffic_patterns
    WHERE detected_at < NOW() - INTERVAL '7 days';
END;
$$;


ALTER FUNCTION auth.cleanup_old_security_events() OWNER TO alisaberi;

--
-- Name: is_ip_blacklisted(inet); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.is_ip_blacklisted(check_ip inet) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM auth.ip_blacklist
        WHERE ip_address = check_ip
        AND (permanent = true OR (blocked_until IS NULL OR blocked_until > NOW()))
        AND unblocked_at IS NULL
    );
END;
$$;


ALTER FUNCTION auth.is_ip_blacklisted(check_ip inet) OWNER TO alisaberi;

--
-- Name: FUNCTION is_ip_blacklisted(check_ip inet); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.is_ip_blacklisted(check_ip inet) IS 'Check if an IP address is currently blacklisted';


--
-- Name: is_ip_whitelisted(inet); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.is_ip_whitelisted(check_ip inet) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM auth.ip_whitelist
        WHERE ip_address = check_ip
        AND (expires_at IS NULL OR expires_at > NOW())
    );
END;
$$;


ALTER FUNCTION auth.is_ip_whitelisted(check_ip inet) OWNER TO alisaberi;

--
-- Name: FUNCTION is_ip_whitelisted(check_ip inet); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.is_ip_whitelisted(check_ip inet) IS 'Check if an IP address is currently whitelisted';


--
-- Name: purge_user_data(uuid, boolean); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.purge_user_data(p_user_id uuid, p_force boolean DEFAULT false) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_environment VARCHAR(20);
  v_can_purge BOOLEAN;
  v_purge_after TIMESTAMPTZ;
BEGIN
  -- Get environment
  v_environment := COALESCE(current_setting('app.environment', true), 'production');
  
  -- NEVER allow purge in production
  IF v_environment = 'production' AND NOT p_force THEN
    RAISE EXCEPTION 'Data purging is not allowed in production environment';
  END IF;
  
  -- Check if user can be purged
  SELECT can_be_purged, purge_after 
  INTO v_can_purge, v_purge_after
  FROM auth.users WHERE id = p_user_id;
  
  IF NOT v_can_purge THEN
    RAISE EXCEPTION 'User % is not marked for purging', p_user_id;
  END IF;
  
  IF v_purge_after > CURRENT_TIMESTAMP AND NOT p_force THEN
    RAISE EXCEPTION 'User % cannot be purged until %', p_user_id, v_purge_after;
  END IF;
  
  -- Log before purging
  INSERT INTO auth.deletion_audit (
    user_id, action, notes, environment
  ) VALUES (
    p_user_id, 'purge_executed', 'User data permanently deleted', v_environment
  );
  
  -- Delete related data (cascade will handle most)
  DELETE FROM auth.sessions WHERE user_id = p_user_id;
  DELETE FROM auth.devices WHERE user_id = p_user_id;
  DELETE FROM auth.mfa_configs WHERE user_id = p_user_id;
  DELETE FROM auth.otp_codes WHERE user_id = p_user_id;
  DELETE FROM auth.password_reset_tokens WHERE user_id = p_user_id;
  
  -- Finally delete the user
  DELETE FROM auth.users WHERE id = p_user_id;
  
  RETURN true;
END;
$$;


ALTER FUNCTION auth.purge_user_data(p_user_id uuid, p_force boolean) OWNER TO alisaberi;

--
-- Name: record_security_event(character varying, uuid, inet, character varying, character varying, character varying, jsonb); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.record_security_event(p_event_type character varying, p_user_id uuid, p_ip_address inet, p_path character varying, p_method character varying, p_severity character varying, p_metadata jsonb) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_event_id UUID;
BEGIN
    INSERT INTO auth.security_events (
        event_type, user_id, ip_address, path, method, severity, metadata
    ) VALUES (
        p_event_type, p_user_id, p_ip_address, p_path, p_method, p_severity, p_metadata
    ) RETURNING id INTO v_event_id;
    
    -- Auto-block IP if too many critical events
    IF p_severity = 'critical' THEN
        PERFORM auth.check_auto_block_ip(p_ip_address);
    END IF;
    
    RETURN v_event_id;
END;
$$;


ALTER FUNCTION auth.record_security_event(p_event_type character varying, p_user_id uuid, p_ip_address inet, p_path character varying, p_method character varying, p_severity character varying, p_metadata jsonb) OWNER TO alisaberi;

--
-- Name: FUNCTION record_security_event(p_event_type character varying, p_user_id uuid, p_ip_address inet, p_path character varying, p_method character varying, p_severity character varying, p_metadata jsonb); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.record_security_event(p_event_type character varying, p_user_id uuid, p_ip_address inet, p_path character varying, p_method character varying, p_severity character varying, p_metadata jsonb) IS 'Record a security event and trigger auto-blocking if needed';


--
-- Name: restore_user(uuid, uuid, text); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.restore_user(p_user_id uuid, p_restored_by uuid, p_notes text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_previous_status auth.user_status;
BEGIN
  -- Get the status before deletion
  SELECT last_status_before_deletion INTO v_previous_status 
  FROM auth.users WHERE id = p_user_id;
  
  -- Restore user
  UPDATE auth.users
  SET 
    status = COALESCE(v_previous_status, 'active'),
    deleted_at = NULL,
    deletion_requested_at = NULL,
    deletion_requested_by = NULL,
    deletion_reason = NULL,
    deletion_notes = NULL,
    last_status_before_deletion = NULL,
    purge_after = NULL,
    can_be_purged = false
  WHERE id = p_user_id;
  
  -- Log the restoration
  INSERT INTO auth.deletion_audit (
    user_id, action, performed_by, notes
  ) VALUES (
    p_user_id, 'restore', p_restored_by, p_notes
  );
  
  RETURN true;
END;
$$;


ALTER FUNCTION auth.restore_user(p_user_id uuid, p_restored_by uuid, p_notes text) OWNER TO alisaberi;

--
-- Name: scheduled_purge_cleanup(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.scheduled_purge_cleanup() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_environment VARCHAR(20);
  v_user RECORD;
BEGIN
  v_environment := COALESCE(current_setting('app.environment', true), 'production');
  
  -- Only run in non-production environments
  IF v_environment = 'production' THEN
    RETURN;
  END IF;
  
  -- Find users ready for purging
  FOR v_user IN 
    SELECT id, email 
    FROM auth.users 
    WHERE can_be_purged = true 
      AND purge_after IS NOT NULL 
      AND purge_after <= CURRENT_TIMESTAMP
      AND deleted_at IS NOT NULL
  LOOP
    BEGIN
      PERFORM auth.purge_user_data(v_user.id, false);
      RAISE NOTICE 'Purged user %', v_user.email;
    EXCEPTION WHEN OTHERS THEN
      RAISE WARNING 'Failed to purge user %: %', v_user.email, SQLERRM;
    END;
  END LOOP;
END;
$$;


ALTER FUNCTION auth.scheduled_purge_cleanup() OWNER TO alisaberi;

--
-- Name: soft_delete_user(uuid, uuid, auth.deletion_reason, text); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.soft_delete_user(p_user_id uuid, p_deleted_by uuid, p_reason auth.deletion_reason, p_notes text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
  v_current_status auth.user_status;
  v_environment VARCHAR(20);
BEGIN
  -- Get current environment from settings or default to production
  v_environment := COALESCE(current_setting('app.environment', true), 'production');
  
  -- Get current user status
  SELECT status INTO v_current_status FROM auth.users WHERE id = p_user_id;
  
  -- Update user record
  UPDATE auth.users
  SET 
    status = 'deleted',
    deleted_at = CURRENT_TIMESTAMP,
    deletion_requested_at = COALESCE(deletion_requested_at, CURRENT_TIMESTAMP),
    deletion_requested_by = p_deleted_by,
    deletion_reason = p_reason,
    deletion_notes = p_notes,
    last_status_before_deletion = v_current_status,
    -- Set purge date based on environment
    purge_after = CASE 
      WHEN v_environment = 'development' THEN CURRENT_TIMESTAMP + INTERVAL '1 day'
      WHEN v_environment = 'test' THEN CURRENT_TIMESTAMP
      WHEN v_environment = 'staging' THEN CURRENT_TIMESTAMP + INTERVAL '7 days'
      ELSE NULL -- Never purge in production
    END,
    can_be_purged = v_environment != 'production'
  WHERE id = p_user_id;
  
  -- Log the action
  INSERT INTO auth.deletion_audit (
    user_id, action, performed_by, reason, notes, environment
  ) VALUES (
    p_user_id, 'soft_delete', p_deleted_by, p_reason, p_notes, v_environment
  );
  
  -- Revoke all active sessions
  UPDATE auth.sessions SET revoked_at = CURRENT_TIMESTAMP 
  WHERE user_id = p_user_id AND revoked_at IS NULL;
  
  RETURN true;
END;
$$;


ALTER FUNCTION auth.soft_delete_user(p_user_id uuid, p_deleted_by uuid, p_reason auth.deletion_reason, p_notes text) OWNER TO alisaberi;

--
-- Name: sync_monay_users(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.sync_monay_users() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    monay_tenant_id UUID;
BEGIN
    -- Get Monay tenant ID
    SELECT id INTO monay_tenant_id FROM auth.tenants WHERE slug = 'monay';
    
    -- This would connect to monay database and sync users
    -- Implementation depends on dblink or external script
    -- Placeholder for actual sync logic
    
    RAISE NOTICE 'User sync function created. Run external sync script to migrate users.';
END;
$$;


ALTER FUNCTION auth.sync_monay_users() OWNER TO alisaberi;

--
-- Name: toggle_user_status(uuid, character varying, uuid, text); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.toggle_user_status(p_user_id uuid, p_action character varying, p_performed_by uuid, p_reason text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF p_action = 'disable' THEN
    UPDATE auth.users
    SET 
      status = 'disabled',
      disabled_at = CURRENT_TIMESTAMP,
      disabled_by = p_performed_by,
      disabled_reason = p_reason
    WHERE id = p_user_id;
    
    -- Revoke active sessions
    UPDATE auth.sessions SET revoked_at = CURRENT_TIMESTAMP 
    WHERE user_id = p_user_id AND revoked_at IS NULL;
    
  ELSIF p_action = 'enable' THEN
    UPDATE auth.users
    SET 
      status = 'active',
      disabled_at = NULL,
      disabled_by = NULL,
      disabled_reason = NULL
    WHERE id = p_user_id;
  ELSE
    RAISE EXCEPTION 'Invalid action: %', p_action;
  END IF;
  
  -- Log the action
  INSERT INTO auth.deletion_audit (
    user_id, action, performed_by, notes
  ) VALUES (
    p_user_id, p_action, p_performed_by, p_reason
  );
  
  RETURN true;
END;
$$;


ALTER FUNCTION auth.toggle_user_status(p_user_id uuid, p_action character varying, p_performed_by uuid, p_reason text) OWNER TO alisaberi;

--
-- Name: update_tenant_settings_updated_at(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.update_tenant_settings_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION auth.update_tenant_settings_updated_at() OWNER TO alisaberi;

--
-- Name: update_updated_at(); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION auth.update_updated_at() OWNER TO alisaberi;

--
-- Name: update_user_risk_profile(uuid, character varying, jsonb); Type: FUNCTION; Schema: auth; Owner: alisaberi
--

CREATE FUNCTION auth.update_user_risk_profile(p_user_id uuid, p_event_type character varying, p_event_data jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_profile RECORD;
    v_new_score INTEGER;
BEGIN
    -- Get or create profile
    INSERT INTO auth.user_risk_profiles (user_id)
    VALUES (p_user_id)
    ON CONFLICT (user_id) DO NOTHING;
    
    SELECT * INTO v_profile FROM auth.user_risk_profiles WHERE user_id = p_user_id;
    
    -- Calculate new score based on event
    v_new_score := v_profile.current_score;
    
    CASE p_event_type
        WHEN 'failed_login' THEN
            v_new_score := v_new_score + 5;
        WHEN 'password_reset' THEN
            v_new_score := v_new_score + 10;
        WHEN 'mfa_disabled' THEN
            v_new_score := v_new_score + 15;
        WHEN 'suspicious_location' THEN
            v_new_score := v_new_score + 20;
        WHEN 'successful_login' THEN
            v_new_score := GREATEST(0, v_new_score - 2);
        WHEN 'mfa_enabled' THEN
            v_new_score := GREATEST(0, v_new_score - 10);
    END CASE;
    
    -- Update profile
    UPDATE auth.user_risk_profiles
    SET 
        current_score = LEAST(100, v_new_score),
        highest_score = GREATEST(highest_score, v_new_score),
        last_risk_assessment = NOW(),
        risk_factors = risk_factors || jsonb_build_object(
            p_event_type, COALESCE((risk_factors->p_event_type)::int, 0) + 1
        ),
        requires_enhanced_monitoring = (v_new_score > 70),
        updated_at = NOW()
    WHERE user_id = p_user_id;
END;
$$;


ALTER FUNCTION auth.update_user_risk_profile(p_user_id uuid, p_event_type character varying, p_event_data jsonb) OWNER TO alisaberi;

--
-- Name: FUNCTION update_user_risk_profile(p_user_id uuid, p_event_type character varying, p_event_data jsonb); Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON FUNCTION auth.update_user_risk_profile(p_user_id uuid, p_event_type character varying, p_event_data jsonb) IS 'Update user risk profile based on events';


--
-- Name: calculate_audit_risk_score(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.calculate_audit_risk_score() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    risk_score INTEGER := 0;
BEGIN
    -- Check for suspicious login patterns
    IF NEW.event_type IN ('login_failed', 'mfa_failed', 'password_reset_failed') THEN
        risk_score := risk_score + 20;
    END IF;
    
    -- Check for multiple failed attempts
    IF NEW.event_type LIKE '%_failed' THEN
        SELECT COUNT(*) INTO risk_score
        FROM audit_logs
        WHERE user_id = NEW.user_id
          AND event_type LIKE '%_failed'
          AND created_at > NOW() - INTERVAL '15 minutes';
        
        risk_score := LEAST(risk_score * 10, 50);
    END IF;
    
    -- Check for unusual location
    IF NEW.location IS NOT NULL AND NEW.user_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM audit_logs
            WHERE user_id = NEW.user_id
              AND location->>'country' = NEW.location->>'country'
              AND created_at > NOW() - INTERVAL '30 days'
        ) THEN
            risk_score := risk_score + 30;
        END IF;
    END IF;
    
    -- Check for suspicious user agent changes
    IF NEW.user_agent IS NOT NULL AND NEW.user_id IS NOT NULL THEN
        IF EXISTS (
            SELECT 1 FROM audit_logs
            WHERE user_id = NEW.user_id
              AND user_agent != NEW.user_agent
              AND created_at > NOW() - INTERVAL '1 hour'
            LIMIT 3
        ) THEN
            risk_score := risk_score + 15;
        END IF;
    END IF;
    
    NEW.risk_score := LEAST(risk_score, 100);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.calculate_audit_risk_score() OWNER TO alisaberi;

--
-- Name: cleanup_old_audit_logs(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.cleanup_old_audit_logs() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Delete logs older than 90 days, except high-risk events
    DELETE FROM audit_logs
    WHERE created_at < NOW() - INTERVAL '90 days'
      AND risk_score < 70
      AND event_category NOT IN ('security', 'admin');
    
    -- Archive high-risk events older than 1 year (in production, this would move to cold storage)
    DELETE FROM audit_logs
    WHERE created_at < NOW() - INTERVAL '365 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_audit_logs() OWNER TO alisaberi;

--
-- Name: update_invoice_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_invoice_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_updated_at() OWNER TO alisaberi;

--
-- Name: update_otp_templates_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_otp_templates_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_otp_templates_updated_at() OWNER TO alisaberi;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO alisaberi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_recovery_requests; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.account_recovery_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    recovery_type character varying(50) NOT NULL,
    search_criteria jsonb,
    matched_accounts jsonb,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verification_level integer DEFAULT 0,
    failed_attempts integer DEFAULT 0,
    risk_score numeric(3,2) DEFAULT 0.0,
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (CURRENT_TIMESTAMP + '24:00:00'::interval),
    CONSTRAINT valid_recovery_type CHECK (((recovery_type)::text = ANY ((ARRAY['password_reset'::character varying, 'account_discovery'::character varying, 'username_recovery'::character varying])::text[])))
);


ALTER TABLE auth.account_recovery_requests OWNER TO alisaberi;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    external_id character varying(255),
    email public.citext,
    phone character varying(20),
    username character varying(100),
    password_hash character varying(255),
    first_name character varying(100),
    last_name character varying(100),
    display_name character varying(255),
    avatar_url text,
    status auth.user_status DEFAULT 'active'::auth.user_status,
    email_verified boolean DEFAULT false,
    phone_verified boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    enrollment_status auth.enrollment_status DEFAULT 'pending'::auth.enrollment_status,
    enrollment_completed_at timestamp with time zone,
    enrollment_method character varying(50),
    recovery_email character varying(255),
    recovery_email_verified boolean DEFAULT false,
    recovery_phone character varying(50),
    recovery_phone_verified boolean DEFAULT false,
    security_questions_configured boolean DEFAULT false,
    password_changed_at timestamp with time zone,
    last_recovery_at timestamp with time zone,
    recovery_attempts integer DEFAULT 0,
    deleted_at timestamp with time zone,
    deletion_requested_at timestamp with time zone,
    deletion_requested_by uuid,
    deletion_reason auth.deletion_reason,
    deletion_notes text,
    disabled_at timestamp with time zone,
    disabled_by uuid,
    disabled_reason text,
    can_be_purged boolean DEFAULT false,
    purge_after timestamp with time zone,
    restoration_token character varying(255),
    last_status_before_deletion auth.user_status
);


ALTER TABLE auth.users OWNER TO alisaberi;

--
-- Name: COLUMN users.deleted_at; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON COLUMN auth.users.deleted_at IS 'Timestamp when user was soft deleted';


--
-- Name: COLUMN users.can_be_purged; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON COLUMN auth.users.can_be_purged IS 'Whether user data can be permanently deleted (never true in production)';


--
-- Name: COLUMN users.purge_after; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON COLUMN auth.users.purge_after IS 'Earliest time when data can be purged (null in production)';


--
-- Name: active_users; Type: VIEW; Schema: auth; Owner: alisaberi
--

CREATE VIEW auth.active_users AS
 SELECT id,
    tenant_id,
    external_id,
    email,
    phone,
    username,
    password_hash,
    first_name,
    last_name,
    display_name,
    avatar_url,
    status,
    email_verified,
    phone_verified,
    metadata,
    last_login_at,
    created_at,
    updated_at,
    enrollment_status,
    enrollment_completed_at,
    enrollment_method,
    recovery_email,
    recovery_email_verified,
    recovery_phone,
    recovery_phone_verified,
    security_questions_configured,
    password_changed_at,
    last_recovery_at,
    recovery_attempts,
    deleted_at,
    deletion_requested_at,
    deletion_requested_by,
    deletion_reason,
    deletion_notes,
    disabled_at,
    disabled_by,
    disabled_reason,
    can_be_purged,
    purge_after,
    restoration_token,
    last_status_before_deletion
   FROM auth.users
  WHERE ((deleted_at IS NULL) AND (status <> ALL (ARRAY['deleted'::auth.user_status, 'marked_for_deletion'::auth.user_status])));


ALTER VIEW auth.active_users OWNER TO alisaberi;

--
-- Name: VIEW active_users; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON VIEW auth.active_users IS 'View of all non-deleted users for standard queries';


--
-- Name: anomaly_detections; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.anomaly_detections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    anomaly_type character varying(50) NOT NULL,
    description text,
    confidence numeric(5,2),
    impact_score integer,
    detected_at timestamp with time zone DEFAULT now(),
    resolved boolean DEFAULT false,
    resolved_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE auth.anomaly_detections OWNER TO alisaberi;

--
-- Name: TABLE anomaly_detections; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.anomaly_detections IS 'Detected anomalies in user behavior';


--
-- Name: api_key_templates; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.api_key_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    rate_limit integer,
    ip_whitelist jsonb,
    default_expiry_days integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.api_key_templates OWNER TO alisaberi;

--
-- Name: api_keys; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    application_id uuid,
    name character varying(100) NOT NULL,
    key_hash character varying(64) NOT NULL,
    key_prefix character varying(16) NOT NULL,
    description text,
    scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    rate_limit integer,
    ip_whitelist jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_ip_whitelist CHECK (((ip_whitelist IS NULL) OR (jsonb_typeof(ip_whitelist) = 'array'::text))),
    CONSTRAINT valid_scopes CHECK ((jsonb_typeof(scopes) = 'array'::text))
);


ALTER TABLE auth.api_keys OWNER TO alisaberi;

--
-- Name: applications; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.applications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    client_id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    client_secret_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    logo_url text,
    redirect_uris text[] NOT NULL,
    allowed_origins text[],
    grant_types text[] DEFAULT ARRAY['authorization_code'::text, 'refresh_token'::text],
    response_types text[] DEFAULT ARRAY['code'::text],
    scopes text[] DEFAULT ARRAY['openid'::text, 'profile'::text, 'email'::text],
    trusted boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.applications OWNER TO alisaberi;

--
-- Name: audit_logs; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    event_type character varying(100) NOT NULL,
    event_category character varying(50),
    ip_address inet,
    user_agent text,
    device_id uuid,
    success boolean DEFAULT true NOT NULL,
    error_code character varying(50),
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.audit_logs OWNER TO alisaberi;

--
-- Name: communication_templates; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.communication_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    template_type character varying(50) NOT NULL,
    nudge_template_id integer NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.communication_templates OWNER TO alisaberi;

--
-- Name: deletion_audit; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.deletion_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    performed_by uuid,
    reason auth.deletion_reason,
    notes text,
    metadata jsonb,
    ip_address inet,
    user_agent text,
    environment character varying(20),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT deletion_audit_action_check CHECK (((action)::text = ANY ((ARRAY['disable'::character varying, 'enable'::character varying, 'mark_for_deletion'::character varying, 'soft_delete'::character varying, 'restore'::character varying, 'purge_scheduled'::character varying, 'purge_executed'::character varying])::text[])))
);


ALTER TABLE auth.deletion_audit OWNER TO alisaberi;

--
-- Name: TABLE deletion_audit; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.deletion_audit IS 'Audit trail for all user deletion and status change actions';


--
-- Name: device_fingerprints; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.device_fingerprints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    fingerprint_hash character varying(255) NOT NULL,
    user_id uuid,
    device_info jsonb NOT NULL,
    trust_score integer DEFAULT 50,
    is_trusted boolean DEFAULT false,
    last_seen timestamp with time zone DEFAULT now(),
    seen_count integer DEFAULT 1,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.device_fingerprints OWNER TO alisaberi;

--
-- Name: TABLE device_fingerprints; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.device_fingerprints IS 'Device fingerprints for trusted device management';


--
-- Name: devices; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    device_fingerprint character varying(255) NOT NULL,
    device_name character varying(255),
    device_type auth.device_type NOT NULL,
    platform character varying(100),
    browser character varying(100),
    trusted boolean DEFAULT false,
    last_ip inet,
    last_location jsonb,
    push_token text,
    metadata jsonb DEFAULT '{}'::jsonb,
    last_seen_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.devices OWNER TO alisaberi;

--
-- Name: email_queue; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.email_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    to_email character varying(255) NOT NULL,
    from_email character varying(255),
    subject character varying(500),
    template_id character varying(100),
    template_data jsonb,
    body_html text,
    body_text text,
    status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    scheduled_for timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    failed_at timestamp with time zone,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.email_queue OWNER TO alisaberi;

--
-- Name: TABLE email_queue; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.email_queue IS 'Email queue for async processing';


--
-- Name: fraud_indicators; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.fraud_indicators (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    indicator_type character varying(50) NOT NULL,
    indicator_value text NOT NULL,
    threat_level integer,
    source character varying(100),
    reported_by character varying(255),
    verified boolean DEFAULT false,
    expires_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT fraud_indicators_threat_level_check CHECK (((threat_level >= 0) AND (threat_level <= 100)))
);


ALTER TABLE auth.fraud_indicators OWNER TO alisaberi;

--
-- Name: TABLE fraud_indicators; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.fraud_indicators IS 'Known fraud indicators for detection';


--
-- Name: ip_blacklist; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.ip_blacklist (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ip_address inet NOT NULL,
    reason character varying(500),
    threat_score integer,
    blocked_at timestamp with time zone DEFAULT now(),
    blocked_until timestamp with time zone,
    blocked_by uuid,
    auto_blocked boolean DEFAULT true,
    permanent boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    unblocked_at timestamp with time zone,
    unblocked_by uuid
);


ALTER TABLE auth.ip_blacklist OWNER TO alisaberi;

--
-- Name: TABLE ip_blacklist; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.ip_blacklist IS 'Blacklisted IP addresses';


--
-- Name: ip_reputation; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.ip_reputation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ip_address inet NOT NULL,
    reputation_score integer,
    is_vpn boolean DEFAULT false,
    is_tor boolean DEFAULT false,
    is_proxy boolean DEFAULT false,
    is_datacenter boolean DEFAULT false,
    country_code character varying(2),
    risk_level character varying(20),
    last_seen timestamp with time zone DEFAULT now(),
    total_requests integer DEFAULT 1,
    failed_attempts integer DEFAULT 0,
    successful_logins integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT ip_reputation_reputation_score_check CHECK (((reputation_score >= 0) AND (reputation_score <= 100)))
);


ALTER TABLE auth.ip_reputation OWNER TO alisaberi;

--
-- Name: TABLE ip_reputation; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.ip_reputation IS 'IP address reputation and classification';


--
-- Name: ip_whitelist; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.ip_whitelist (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ip_address inet NOT NULL,
    description character varying(500),
    added_at timestamp with time zone DEFAULT now(),
    added_by uuid,
    expires_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE auth.ip_whitelist OWNER TO alisaberi;

--
-- Name: TABLE ip_whitelist; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.ip_whitelist IS 'Whitelisted IP addresses that bypass security checks';


--
-- Name: mfa_configs; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.mfa_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    mfa_type auth.mfa_type NOT NULL,
    is_primary boolean DEFAULT false,
    is_enabled boolean DEFAULT true,
    secret_encrypted text,
    backup_codes text[],
    verified boolean DEFAULT false,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.mfa_configs OWNER TO alisaberi;

--
-- Name: nudge_delivery_logs; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.nudge_delivery_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    verification_id uuid,
    nudge_id character varying(255),
    message_id character varying(255),
    channel character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.nudge_delivery_logs OWNER TO alisaberi;

--
-- Name: nudge_otp_logs; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.nudge_otp_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    verification_id uuid NOT NULL,
    nudge_id character varying(255),
    recipient character varying(255) NOT NULL,
    channel character varying(50) NOT NULL,
    purpose character varying(50),
    code character varying(100),
    status character varying(50) NOT NULL,
    message_id character varying(255),
    format character varying(20) DEFAULT 'numeric'::character varying,
    otp_config jsonb,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    echo_mode character varying(20),
    response_data jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_echo_mode CHECK (((echo_mode IS NULL) OR ((echo_mode)::text = ANY ((ARRAY['disabled'::character varying, 'echo_only'::character varying, 'send_and_echo'::character varying])::text[]))))
);


ALTER TABLE auth.nudge_otp_logs OWNER TO alisaberi;

--
-- Name: nudge_templates; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.nudge_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    nudge_id character varying(255) NOT NULL,
    channel character varying(50) NOT NULL,
    purpose character varying(50),
    description text,
    variables text[],
    sample_content text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.nudge_templates OWNER TO alisaberi;

--
-- Name: otp_codes; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.otp_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    code character varying(20) NOT NULL,
    purpose character varying(50) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    attempt_count integer DEFAULT 0,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT otp_codes_purpose_check CHECK (((purpose)::text = ANY ((ARRAY['enrollment'::character varying, 'login'::character varying, 'password_reset'::character varying, 'verification'::character varying, 'transaction'::character varying])::text[])))
);


ALTER TABLE auth.otp_codes OWNER TO alisaberi;

--
-- Name: TABLE otp_codes; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.otp_codes IS 'One-time passwords for various authentication purposes';


--
-- Name: COLUMN otp_codes.purpose; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON COLUMN auth.otp_codes.purpose IS 'Purpose of the OTP: enrollment, login, password_reset, verification, transaction';


--
-- Name: otp_templates; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.otp_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    channel character varying(50) NOT NULL,
    format character varying(20) DEFAULT 'numeric'::character varying NOT NULL,
    length integer DEFAULT 6,
    word_count integer DEFAULT 3,
    word_source character varying(20) DEFAULT 'curated'::character varying,
    word_separator character varying(5) DEFAULT '-'::character varying,
    case_sensitive boolean DEFAULT false,
    custom_words text[],
    expiry_minutes integer DEFAULT 10,
    max_attempts integer DEFAULT 3,
    description text,
    is_default boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_template_format CHECK (((format)::text = ANY ((ARRAY['numeric'::character varying, 'alphanumeric'::character varying, 'words'::character varying])::text[]))),
    CONSTRAINT check_template_word_source CHECK (((word_source IS NULL) OR ((word_source)::text = ANY ((ARRAY['curated'::character varying, 'random'::character varying, 'custom'::character varying])::text[]))))
);


ALTER TABLE auth.otp_templates OWNER TO alisaberi;

--
-- Name: TABLE otp_templates; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.otp_templates IS 'Stores OTP template configurations for different channels and formats';


--
-- Name: password_history; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.password_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.password_history OWNER TO alisaberi;

--
-- Name: password_policies; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.password_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    min_length integer DEFAULT 8,
    max_length integer DEFAULT 128,
    require_uppercase boolean DEFAULT true,
    require_lowercase boolean DEFAULT true,
    require_numbers boolean DEFAULT true,
    require_special boolean DEFAULT true,
    special_chars character varying(100) DEFAULT '!@#$%^&*()_+-=[]{}|;:,.<>?'::character varying,
    prevent_common_passwords boolean DEFAULT true,
    prevent_user_info boolean DEFAULT true,
    password_history_count integer DEFAULT 5,
    min_password_age_days integer DEFAULT 0,
    max_password_age_days integer DEFAULT 90,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.password_policies OWNER TO alisaberi;

--
-- Name: permissions; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    scope character varying(50) DEFAULT 'tenant'::character varying,
    conditions jsonb,
    display_name character varying(255),
    description text,
    is_system boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.permissions OWNER TO alisaberi;

--
-- Name: TABLE permissions; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.permissions IS 'Granular permissions for resources';


--
-- Name: rate_limit_violations; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.rate_limit_violations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier character varying(255) NOT NULL,
    endpoint character varying(500),
    window_start timestamp with time zone NOT NULL,
    request_count integer DEFAULT 1,
    limit_exceeded_at timestamp with time zone,
    blocked_until timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.rate_limit_violations OWNER TO alisaberi;

--
-- Name: TABLE rate_limit_violations; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.rate_limit_violations IS 'Track rate limit violations for analysis';


--
-- Name: rate_limits; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.rate_limits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier character varying(255) NOT NULL,
    endpoint character varying(255) NOT NULL,
    window_start timestamp with time zone NOT NULL,
    request_count integer DEFAULT 1
);


ALTER TABLE auth.rate_limits OWNER TO alisaberi;

--
-- Name: risk_assessments; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.risk_assessments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    session_id character varying(255),
    score integer NOT NULL,
    level character varying(20) NOT NULL,
    factors jsonb DEFAULT '[]'::jsonb NOT NULL,
    requires_mfa boolean DEFAULT false,
    requires_challenge boolean DEFAULT false,
    should_block boolean DEFAULT false,
    recommendations text[],
    action_taken character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT risk_assessments_level_check CHECK (((level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT risk_assessments_score_check CHECK (((score >= 0) AND (score <= 100)))
);


ALTER TABLE auth.risk_assessments OWNER TO alisaberi;

--
-- Name: TABLE risk_assessments; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.risk_assessments IS 'Risk assessment results for authentication attempts';


--
-- Name: risk_scores; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.risk_scores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid,
    user_id uuid NOT NULL,
    risk_score integer NOT NULL,
    factors jsonb NOT NULL,
    action_taken character varying(50),
    analyzed_at timestamp with time zone DEFAULT now(),
    CONSTRAINT risk_scores_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE auth.risk_scores OWNER TO alisaberi;

--
-- Name: role_permissions; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    granted boolean DEFAULT true,
    conditions jsonb,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.role_permissions OWNER TO alisaberi;

--
-- Name: TABLE role_permissions; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.role_permissions IS 'Mapping between roles and permissions';


--
-- Name: roles; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255),
    description text,
    is_system boolean DEFAULT false,
    is_default boolean DEFAULT false,
    parent_role_id uuid,
    priority integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.roles OWNER TO alisaberi;

--
-- Name: TABLE roles; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.roles IS 'Role-based access control roles';


--
-- Name: security_events; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.security_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type character varying(50) NOT NULL,
    user_id uuid,
    ip_address inet,
    path character varying(500),
    method character varying(10),
    severity character varying(20) DEFAULT 'medium'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    resolved boolean DEFAULT false,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.security_events OWNER TO alisaberi;

--
-- Name: TABLE security_events; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.security_events IS 'Security event logging for monitoring and threat detection';


--
-- Name: security_question_templates; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.security_question_templates (
    id integer NOT NULL,
    question_text text NOT NULL,
    category character varying(50) NOT NULL,
    min_answer_length integer DEFAULT 3,
    max_answer_length integer DEFAULT 50,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE auth.security_question_templates OWNER TO alisaberi;

--
-- Name: security_questions; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.security_questions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    question_id integer NOT NULL,
    answer_hash text NOT NULL,
    answer_hint text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_used_at timestamp with time zone,
    usage_count integer DEFAULT 0
);


ALTER TABLE auth.security_questions OWNER TO alisaberi;

--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    application_id uuid,
    session_token character varying(512) NOT NULL,
    refresh_token character varying(512),
    access_token_jti character varying(255),
    device_id uuid,
    ip_address inet,
    user_agent text,
    location jsonb,
    auth_method character varying(50),
    mfa_verified boolean DEFAULT false,
    expires_at timestamp with time zone NOT NULL,
    refresh_expires_at timestamp with time zone,
    last_activity_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.sessions OWNER TO alisaberi;

--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_name character varying(100) NOT NULL,
    provider_type auth.provider_type NOT NULL,
    client_id character varying(255),
    client_secret_encrypted text,
    issuer_url text,
    authorization_url text,
    token_url text,
    userinfo_url text,
    jwks_uri text,
    scopes text[],
    attribute_mapping jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.sso_providers OWNER TO alisaberi;

--
-- Name: tenant_settings; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.tenant_settings (
    tenant_id uuid NOT NULL,
    enrollment_link_expiry_days integer DEFAULT 5,
    password_reset_expiry_hours integer DEFAULT 24,
    otp_expiry_minutes integer DEFAULT 10,
    max_enrollment_attempts integer DEFAULT 3,
    require_mfa_enrollment boolean DEFAULT false,
    require_email_verification boolean DEFAULT true,
    require_phone_verification boolean DEFAULT false,
    allow_passwordless_enrollment boolean DEFAULT false,
    password_min_length integer DEFAULT 8,
    password_require_uppercase boolean DEFAULT true,
    password_require_lowercase boolean DEFAULT true,
    password_require_numbers boolean DEFAULT true,
    password_require_special boolean DEFAULT true,
    password_history_count integer DEFAULT 5,
    session_timeout_minutes integer DEFAULT 60,
    max_concurrent_sessions integer DEFAULT 5,
    enrollment_email_template_id character varying(100),
    enrollment_sms_template_id character varying(100),
    password_reset_email_template_id character varying(100),
    password_reset_sms_template_id character varying(100),
    enable_social_auth boolean DEFAULT true,
    enable_biometric_auth boolean DEFAULT true,
    enable_device_tracking boolean DEFAULT true,
    enable_risk_analysis boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid,
    CONSTRAINT tenant_settings_enrollment_link_expiry_days_check CHECK (((enrollment_link_expiry_days >= 1) AND (enrollment_link_expiry_days <= 30))),
    CONSTRAINT tenant_settings_max_concurrent_sessions_check CHECK (((max_concurrent_sessions >= 1) AND (max_concurrent_sessions <= 100))),
    CONSTRAINT tenant_settings_max_enrollment_attempts_check CHECK (((max_enrollment_attempts >= 1) AND (max_enrollment_attempts <= 10))),
    CONSTRAINT tenant_settings_otp_expiry_minutes_check CHECK (((otp_expiry_minutes >= 5) AND (otp_expiry_minutes <= 60))),
    CONSTRAINT tenant_settings_password_history_count_check CHECK (((password_history_count >= 0) AND (password_history_count <= 24))),
    CONSTRAINT tenant_settings_password_min_length_check CHECK (((password_min_length >= 6) AND (password_min_length <= 128))),
    CONSTRAINT tenant_settings_password_reset_expiry_hours_check CHECK (((password_reset_expiry_hours >= 1) AND (password_reset_expiry_hours <= 168))),
    CONSTRAINT tenant_settings_session_timeout_minutes_check CHECK (((session_timeout_minutes >= 5) AND (session_timeout_minutes <= 1440)))
);


ALTER TABLE auth.tenant_settings OWNER TO alisaberi;

--
-- Name: TABLE tenant_settings; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.tenant_settings IS 'Per-tenant configuration for authentication and enrollment settings';


--
-- Name: COLUMN tenant_settings.enrollment_link_expiry_days; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON COLUMN auth.tenant_settings.enrollment_link_expiry_days IS 'Number of days enrollment links remain valid (default 5 days)';


--
-- Name: tenants; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    domain character varying(255),
    settings jsonb DEFAULT '{}'::jsonb,
    features jsonb DEFAULT '{"mfa": true, "sso": true, "passwordless": true}'::jsonb,
    api_quota integer DEFAULT 10000,
    max_users integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.tenants OWNER TO alisaberi;

--
-- Name: traffic_patterns; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.traffic_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ip_address inet NOT NULL,
    pattern_type character varying(50),
    confidence_score numeric(5,2),
    detected_at timestamp with time zone DEFAULT now(),
    pattern_data jsonb DEFAULT '{}'::jsonb,
    action_taken character varying(50)
);


ALTER TABLE auth.traffic_patterns OWNER TO alisaberi;

--
-- Name: TABLE traffic_patterns; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.traffic_patterns IS 'Detected traffic patterns for security analysis';


--
-- Name: user_risk_profiles; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.user_risk_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    baseline_score integer DEFAULT 0,
    current_score integer DEFAULT 0,
    highest_score integer DEFAULT 0,
    risk_factors jsonb DEFAULT '{}'::jsonb,
    known_devices text[] DEFAULT '{}'::text[],
    known_locations text[] DEFAULT '{}'::text[],
    typical_behavior jsonb DEFAULT '{}'::jsonb,
    anomaly_count integer DEFAULT 0,
    last_risk_assessment timestamp with time zone,
    requires_enhanced_monitoring boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.user_risk_profiles OWNER TO alisaberi;

--
-- Name: TABLE user_risk_profiles; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.user_risk_profiles IS 'User-specific risk profiles and behavioral baselines';


--
-- Name: user_roles; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    scope character varying(50) DEFAULT 'tenant'::character varying,
    resource_id uuid,
    valid_from timestamp with time zone DEFAULT now(),
    valid_until timestamp with time zone,
    assigned_by uuid,
    assigned_at timestamp with time zone DEFAULT now(),
    assignment_reason text
);


ALTER TABLE auth.user_roles OWNER TO alisaberi;

--
-- Name: TABLE user_roles; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.user_roles IS 'User role assignments with time bounds';


--
-- Name: user_sso_connections; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.user_sso_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    external_user_id character varying(255) NOT NULL,
    access_token_encrypted text,
    refresh_token_encrypted text,
    token_expires_at timestamp with time zone,
    profile_data jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.user_sso_connections OWNER TO alisaberi;

--
-- Name: velocity_tracking; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.velocity_tracking (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    identifier character varying(255) NOT NULL,
    action_type character varying(50) NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_duration interval NOT NULL,
    action_count integer DEFAULT 1,
    threshold integer,
    exceeded boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.velocity_tracking OWNER TO alisaberi;

--
-- Name: TABLE velocity_tracking; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.velocity_tracking IS 'Track velocity of actions for rate limiting';


--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    credential_id text NOT NULL,
    public_key text NOT NULL,
    counter bigint DEFAULT 0,
    aaguid character varying(255),
    name character varying(255),
    device_type character varying(50),
    transports text[],
    backup_eligible boolean DEFAULT false,
    backup_status boolean DEFAULT false,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.webauthn_credentials OWNER TO alisaberi;

--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.webhook_delivery_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    endpoint_id uuid,
    event_id uuid,
    url text NOT NULL,
    method character varying(10) DEFAULT 'POST'::character varying,
    headers jsonb,
    payload jsonb NOT NULL,
    status_code integer,
    response_headers jsonb,
    response_body text,
    success boolean,
    error_message text,
    attempted_at timestamp with time zone DEFAULT now(),
    duration_ms integer,
    attempt_number integer DEFAULT 1,
    next_retry_at timestamp with time zone
);


ALTER TABLE auth.webhook_delivery_logs OWNER TO alisaberi;

--
-- Name: TABLE webhook_delivery_logs; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.webhook_delivery_logs IS 'Webhook delivery attempt logs';


--
-- Name: webhook_endpoints; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.webhook_endpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    url text NOT NULL,
    description text,
    auth_type character varying(50),
    auth_credentials_encrypted text,
    signing_secret character varying(255),
    events text[] NOT NULL,
    enabled boolean DEFAULT true,
    retry_enabled boolean DEFAULT true,
    max_retries integer DEFAULT 3,
    timeout_seconds integer DEFAULT 30,
    rate_limit integer,
    custom_headers jsonb,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    consecutive_failures integer DEFAULT 0,
    total_events_sent integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.webhook_endpoints OWNER TO alisaberi;

--
-- Name: TABLE webhook_endpoints; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.webhook_endpoints IS 'Webhook endpoint configurations';


--
-- Name: webhook_events; Type: TABLE; Schema: auth; Owner: alisaberi
--

CREATE TABLE auth.webhook_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    event_id character varying(255) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    payload jsonb NOT NULL,
    processed boolean DEFAULT false,
    processed_at timestamp with time zone,
    retry_count integer DEFAULT 0,
    last_error text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE auth.webhook_events OWNER TO alisaberi;

--
-- Name: TABLE webhook_events; Type: COMMENT; Schema: auth; Owner: alisaberi
--

COMMENT ON TABLE auth.webhook_events IS 'Webhook event queue';


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id character varying(50),
    user_id uuid,
    session_id uuid,
    event_type character varying(100) NOT NULL,
    event_category character varying(50) NOT NULL,
    description text NOT NULL,
    ip_address inet,
    user_agent text,
    location jsonb,
    device_info jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    risk_score integer,
    status character varying(50) DEFAULT 'success'::character varying,
    error_message text,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT audit_logs_event_category_check CHECK (((event_category)::text = ANY ((ARRAY['auth'::character varying, 'social'::character varying, 'security'::character varying, 'admin'::character varying, 'system'::character varying, 'profile'::character varying, 'custodian'::character varying, 'mfa'::character varying])::text[]))),
    CONSTRAINT audit_logs_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.audit_logs OWNER TO alisaberi;

--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.audit_logs IS 'Comprehensive audit log for all system events. Event types include:
- Authentication: login_success, login_failed, logout, password_changed, password_reset_requested
- MFA: mfa_enabled, mfa_disabled, mfa_verified, mfa_failed, backup_code_used
- Social: social_login_success, social_login_failed, social_account_linked, social_account_unlinked
- Security: suspicious_activity_detected, account_locked, account_unlocked, ip_blocked
- Profile: profile_updated, email_verified, phone_verified, avatar_uploaded
- Custodian: custodian_added, custodian_removed, recovery_requested, recovery_approved
- Admin: user_created, user_deleted, settings_changed, tenant_updated
- System: api_call, webhook_sent, email_sent, sms_sent, error_occurred';


--
-- Name: COLUMN audit_logs.user_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.audit_logs.user_id IS 'References auth.users(id) - the user who triggered this audit event';


--
-- Name: behavioral_biometric_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.behavioral_biometric_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    session_id character varying(255) NOT NULL,
    typing_pattern jsonb,
    mouse_pattern jsonb,
    touch_pattern jsonb,
    scroll_pattern jsonb,
    device_motion jsonb,
    interaction_timing jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.behavioral_biometric_profiles OWNER TO alisaberi;

--
-- Name: biometric_challenges; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.biometric_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    challenge text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.biometric_challenges OWNER TO alisaberi;

--
-- Name: biometric_enrollments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.biometric_enrollments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    enrollment_data jsonb,
    device_info jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_used_at timestamp with time zone,
    verification_count integer DEFAULT 0,
    failure_count integer DEFAULT 0
);


ALTER TABLE public.biometric_enrollments OWNER TO alisaberi;

--
-- Name: biometric_verification_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.biometric_verification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    verification_type character varying(50) NOT NULL,
    success boolean NOT NULL,
    score numeric(3,2),
    confidence numeric(3,2),
    liveness_detected boolean,
    spoofing_detected boolean,
    risk_score integer,
    additional_factor_required boolean,
    details jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.biometric_verification_logs OWNER TO alisaberi;

--
-- Name: custodian_assignments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custodian_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    custodian_id uuid NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_primary boolean DEFAULT false,
    requires_approval_from integer DEFAULT 1,
    time_delay_hours integer DEFAULT 24,
    status character varying(50) DEFAULT 'active'::character varying,
    invited_at timestamp with time zone DEFAULT now(),
    accepted_at timestamp with time zone,
    revoked_at timestamp with time zone
);


ALTER TABLE public.custodian_assignments OWNER TO alisaberi;

--
-- Name: TABLE custodian_assignments; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.custodian_assignments IS 'Links between users and their designated custodians';


--
-- Name: custodian_responses; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custodian_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recovery_request_id uuid NOT NULL,
    custodian_id uuid NOT NULL,
    response character varying(20) NOT NULL,
    reason text,
    verification_method character varying(50),
    verification_data jsonb,
    voice_verification_id uuid,
    ip_address inet,
    user_agent text,
    responded_at timestamp with time zone DEFAULT now(),
    CONSTRAINT custodian_responses_response_check CHECK (((response)::text = ANY ((ARRAY['approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.custodian_responses OWNER TO alisaberi;

--
-- Name: custodian_verification_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custodian_verification_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    custodian_id uuid NOT NULL,
    recovery_request_id uuid,
    session_type character varying(50) NOT NULL,
    session_data jsonb,
    voice_sample_url text,
    voice_match_score numeric(5,2),
    voice_liveness_score numeric(5,2),
    verification_passed boolean,
    failure_reason text,
    started_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '30 days'::interval)
);


ALTER TABLE public.custodian_verification_sessions OWNER TO alisaberi;

--
-- Name: custodians; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custodians (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    type public.custodian_type NOT NULL,
    status public.custodian_status DEFAULT 'pending'::public.custodian_status,
    verification_level public.verification_level DEFAULT 'basic'::public.verification_level,
    kyc_data jsonb,
    verification_documents jsonb,
    biometric_data jsonb,
    voice_print_id uuid,
    organization_name character varying(255),
    license_number character varying(100),
    jurisdiction character varying(100),
    insurance_coverage numeric(15,2),
    reputation_score integer DEFAULT 0,
    successful_recoveries integer DEFAULT 0,
    failed_recoveries integer DEFAULT 0,
    average_response_time interval,
    verified_at timestamp with time zone,
    last_verification_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT custodians_reputation_score_check CHECK (((reputation_score >= 0) AND (reputation_score <= 100)))
);


ALTER TABLE public.custodians OWNER TO alisaberi;

--
-- Name: TABLE custodians; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.custodians IS 'Registered custodians who can help with account recovery';


--
-- Name: email_queue; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.email_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    to_email character varying(255) NOT NULL,
    from_email character varying(255),
    subject character varying(500),
    template_id character varying(100),
    template_data jsonb,
    body_html text,
    body_text text,
    status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 5,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    scheduled_for timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone,
    failed_at timestamp with time zone,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_queue OWNER TO alisaberi;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.email_verification_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '24:00:00'::interval) NOT NULL
);


ALTER TABLE public.email_verification_tokens OWNER TO alisaberi;

--
-- Name: invoice_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid,
    mode character varying(20) NOT NULL,
    base_address character varying(42),
    solana_address character varying(44),
    quantum_public_key text,
    quantum_encrypted_private_key text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    destroyed_at timestamp with time zone,
    status character varying(20) DEFAULT 'active'::character varying,
    features jsonb DEFAULT '{}'::jsonb,
    compliance_proofs jsonb DEFAULT '{}'::jsonb,
    transformation_history jsonb DEFAULT '[]'::jsonb,
    ai_score numeric(3,2),
    ttl_seconds integer,
    created_by uuid,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT invoice_wallets_mode_check CHECK (((mode)::text = ANY ((ARRAY['ephemeral'::character varying, 'persistent'::character varying, 'adaptive'::character varying])::text[]))),
    CONSTRAINT invoice_wallets_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'pending'::character varying, 'expired'::character varying, 'destroyed'::character varying, 'transforming'::character varying])::text[])))
);


ALTER TABLE public.invoice_wallets OWNER TO alisaberi;

--
-- Name: TABLE invoice_wallets; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoice_wallets IS 'Stores Invoice-First cryptocurrency wallets with ephemeral/persistent modes';


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_number character varying(100) NOT NULL,
    user_id uuid,
    type character varying(20),
    amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    client_name character varying(255),
    vendor_name character varying(255),
    description text,
    payment_method character varying(50),
    due_date date,
    paid_date timestamp without time zone,
    is_recurring boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT amount_positive CHECK ((amount >= (0)::numeric)),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT invoices_type_check CHECK (((type)::text = ANY ((ARRAY['inbound'::character varying, 'outbound'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO alisaberi;

--
-- Name: TABLE invoices; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoices IS 'Core invoices table for Invoice-First Wallet System';


--
-- Name: COLUMN invoices.type; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoices.type IS 'Type of invoice: inbound (to be received) or outbound (to be paid)';


--
-- Name: COLUMN invoices.metadata; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoices.metadata IS 'Additional invoice data in JSON format';


--
-- Name: magic_links; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.magic_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    purpose character varying(50) NOT NULL,
    ip_address inet,
    user_agent text,
    fingerprint character varying(255),
    used boolean DEFAULT false,
    used_at timestamp with time zone,
    revoked boolean DEFAULT false,
    revoked_reason text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '00:15:00'::interval) NOT NULL,
    CONSTRAINT check_expiry CHECK ((expires_at > created_at))
);


ALTER TABLE public.magic_links OWNER TO alisaberi;

--
-- Name: nudge_credit_tracking; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.nudge_credit_tracking (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    credit_used numeric(10,2) NOT NULL,
    credit_remaining numeric(10,2),
    currency character varying(3) DEFAULT 'USD'::character varying,
    operation character varying(50) NOT NULL,
    nudge_id character varying(255),
    message_count integer DEFAULT 1,
    billing_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.nudge_credit_tracking OWNER TO alisaberi;

--
-- Name: nudge_delivery_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.nudge_delivery_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    verification_id uuid,
    nudge_id character varying(255) NOT NULL,
    message_id character varying(255),
    channel character varying(20) NOT NULL,
    recipient character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    response_data jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    delivered_at timestamp with time zone
);


ALTER TABLE public.nudge_delivery_logs OWNER TO alisaberi;

--
-- Name: nudge_notification_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.nudge_notification_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    nudge_id character varying(255) NOT NULL,
    message_id character varying(255),
    channel character varying(20) NOT NULL,
    recipient character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    context jsonb,
    created_at timestamp with time zone DEFAULT now(),
    delivered_at timestamp with time zone
);


ALTER TABLE public.nudge_notification_logs OWNER TO alisaberi;

--
-- Name: nudge_templates; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.nudge_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    nudge_id character varying(255) NOT NULL,
    channel character varying(20) NOT NULL,
    purpose character varying(50) NOT NULL,
    description text,
    variables text[],
    sample_content text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.nudge_templates OWNER TO alisaberi;

--
-- Name: oauth_states; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.oauth_states (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state character varying(255) NOT NULL,
    provider character varying(50) NOT NULL,
    tenant_id uuid NOT NULL,
    redirect_uri text,
    code_challenge character varying(255),
    code_challenge_method character varying(10),
    nonce character varying(255),
    metadata jsonb,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.oauth_states OWNER TO alisaberi;

--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.otp_codes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    identifier character varying(255) NOT NULL,
    identifier_type character varying(20) NOT NULL,
    code character varying(10) NOT NULL,
    purpose character varying(50) NOT NULL,
    delivery_method character varying(20) NOT NULL,
    delivery_provider character varying(50),
    delivery_status character varying(50),
    delivery_attempts integer DEFAULT 0,
    last_delivery_attempt timestamp with time zone,
    ip_address inet,
    user_agent text,
    verification_attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '00:10:00'::interval) NOT NULL,
    CONSTRAINT check_attempts CHECK ((verification_attempts <= max_attempts)),
    CONSTRAINT otp_codes_identifier_type_check CHECK (((identifier_type)::text = ANY ((ARRAY['email'::character varying, 'phone'::character varying])::text[])))
);


ALTER TABLE public.otp_codes OWNER TO alisaberi;

--
-- Name: otp_verifications; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.otp_verifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    code character varying(10) NOT NULL,
    recipient character varying(255) NOT NULL,
    channel character varying(20) NOT NULL,
    purpose character varying(50) NOT NULL,
    attempts integer DEFAULT 0,
    verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    metadata jsonb,
    ip_address inet,
    user_agent text,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT max_attempts CHECK ((attempts <= 5)),
    CONSTRAINT otp_verifications_channel_check CHECK (((channel)::text = ANY ((ARRAY['sms'::character varying, 'email'::character varying, 'voice'::character varying, 'whatsapp'::character varying])::text[]))),
    CONSTRAINT otp_verifications_purpose_check CHECK (((purpose)::text = ANY ((ARRAY['login'::character varying, 'signup'::character varying, 'reset_password'::character varying, 'verify'::character varying, 'mfa'::character varying])::text[])))
);


ALTER TABLE public.otp_verifications OWNER TO alisaberi;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    token character varying(255) NOT NULL,
    reset_method character varying(50) NOT NULL,
    verification_code character varying(10),
    ip_address inet,
    user_agent text,
    old_password_hash character varying(255),
    used boolean DEFAULT false,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '01:00:00'::interval) NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO alisaberi;

--
-- Name: passwordless_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.passwordless_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    session_token character varying(255) NOT NULL,
    auth_method character varying(50) NOT NULL,
    auth_identifier character varying(255),
    state character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    verification_token character varying(255),
    ip_address inet,
    user_agent text,
    device_fingerprint character varying(255),
    location jsonb,
    risk_score integer,
    initiated_at timestamp with time zone DEFAULT now(),
    verified_at timestamp with time zone,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '00:30:00'::interval) NOT NULL
);


ALTER TABLE public.passwordless_sessions OWNER TO alisaberi;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    resource character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    scope character varying(50) DEFAULT 'tenant'::character varying,
    conditions jsonb,
    display_name character varying(255),
    description text,
    is_system boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.permissions OWNER TO alisaberi;

--
-- Name: quantum_key_registry; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.quantum_key_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    algorithm character varying(50) NOT NULL,
    public_key text NOT NULL,
    key_version integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT now(),
    rotated_at timestamp with time zone,
    is_active boolean DEFAULT true,
    security_level integer DEFAULT 256,
    CONSTRAINT quantum_key_registry_algorithm_check CHECK (((algorithm)::text = ANY ((ARRAY['CRYSTALS-Kyber-1024'::character varying, 'Dilithium-3'::character varying, 'SPHINCS+'::character varying, 'RSA-3072'::character varying, 'Hybrid-RSA-Dilithium'::character varying])::text[])))
);


ALTER TABLE public.quantum_key_registry OWNER TO alisaberi;

--
-- Name: TABLE quantum_key_registry; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.quantum_key_registry IS 'Quantum-resistant cryptographic keys for wallets';


--
-- Name: recovery_requests; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.recovery_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    request_type character varying(50) NOT NULL,
    status public.recovery_status DEFAULT 'pending'::public.recovery_status,
    reason text,
    required_approvals integer DEFAULT 1,
    current_approvals integer DEFAULT 0,
    time_delay_hours integer DEFAULT 24,
    verification_code character varying(100),
    verification_method character varying(50),
    ip_address inet,
    user_agent text,
    requested_at timestamp with time zone DEFAULT now(),
    approved_at timestamp with time zone,
    executed_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '7 days'::interval),
    CONSTRAINT check_approvals CHECK ((current_approvals <= required_approvals))
);


ALTER TABLE public.recovery_requests OWNER TO alisaberi;

--
-- Name: TABLE recovery_requests; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.recovery_requests IS 'Account recovery requests initiated by users';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.role_permissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.role_permissions OWNER TO alisaberi;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255),
    description text,
    is_system boolean DEFAULT false,
    is_default boolean DEFAULT false,
    parent_role_id uuid,
    priority integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.roles OWNER TO alisaberi;

--
-- Name: social_accounts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.social_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    provider_user_id character varying(255) NOT NULL,
    email character varying(255),
    email_verified boolean DEFAULT false,
    name character varying(255),
    given_name character varying(255),
    family_name character varying(255),
    picture text,
    locale character varying(10),
    provider_data jsonb,
    access_token_encrypted text,
    refresh_token_encrypted text,
    token_expires_at timestamp with time zone,
    linked_at timestamp with time zone DEFAULT now(),
    last_login_at timestamp with time zone
);


ALTER TABLE public.social_accounts OWNER TO alisaberi;

--
-- Name: social_auth_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.social_auth_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    tenant_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    event_type character varying(50) NOT NULL,
    provider_user_id character varying(255),
    email character varying(255),
    ip_address inet,
    user_agent text,
    error_message text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.social_auth_logs OWNER TO alisaberi;

--
-- Name: social_providers; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.social_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    provider_name character varying(50) NOT NULL,
    client_id character varying(255) NOT NULL,
    client_secret_encrypted text,
    redirect_uri text NOT NULL,
    scopes text[],
    enabled boolean DEFAULT true,
    settings jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.social_providers OWNER TO alisaberi;

--
-- Name: TABLE social_providers; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.social_providers IS 'Configuration for social login providers per tenant';


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    resource_type character varying(100),
    resource_id character varying(255),
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.user_roles OWNER TO alisaberi;

--
-- Name: voice_biometric_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.voice_biometric_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    voice_print_id character varying(255) NOT NULL,
    voice_features jsonb NOT NULL,
    audio_samples jsonb,
    language_detected character varying(10),
    quality_score numeric(3,2),
    liveness_score numeric(3,2),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.voice_biometric_profiles OWNER TO alisaberi;

--
-- Name: wallet_lifecycle_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_lifecycle_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    event_type character varying(50) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    actor_id uuid,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now(),
    CONSTRAINT wallet_lifecycle_events_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['created'::character varying, 'activated'::character varying, 'payment_received'::character varying, 'payment_sent'::character varying, 'transformed'::character varying, 'extended'::character varying, 'expired'::character varying, 'destroyed'::character varying, 'error'::character varying, 'compliance_check'::character varying, 'key_rotation'::character varying])::text[])))
);


ALTER TABLE public.wallet_lifecycle_events OWNER TO alisaberi;

--
-- Name: TABLE wallet_lifecycle_events; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.wallet_lifecycle_events IS 'Audit trail for all wallet lifecycle events';


--
-- Name: wallet_mode_decisions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_mode_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid NOT NULL,
    selected_mode character varying(20) NOT NULL,
    ai_score numeric(3,2),
    decision_factors jsonb DEFAULT '{}'::jsonb,
    override_reason text,
    overridden_by uuid,
    transaction_amount numeric(20,8),
    customer_risk_score integer,
    is_recurring boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT wallet_mode_decisions_selected_mode_check CHECK (((selected_mode)::text = ANY ((ARRAY['ephemeral'::character varying, 'persistent'::character varying, 'adaptive'::character varying])::text[])))
);


ALTER TABLE public.wallet_mode_decisions OWNER TO alisaberi;

--
-- Name: TABLE wallet_mode_decisions; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.wallet_mode_decisions IS 'AI-driven wallet mode selection history';


--
-- Name: webhook_delivery_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.webhook_delivery_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id uuid NOT NULL,
    endpoint_id uuid NOT NULL,
    attempt_number integer NOT NULL,
    request_headers jsonb,
    request_body text,
    response_status integer,
    response_headers jsonb,
    response_body text,
    response_time_ms integer,
    success boolean NOT NULL,
    error_message text,
    attempted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.webhook_delivery_logs OWNER TO alisaberi;

--
-- Name: TABLE webhook_delivery_logs; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.webhook_delivery_logs IS 'Webhook delivery audit log';


--
-- Name: webhook_endpoints; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.webhook_endpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    url text NOT NULL,
    description text,
    auth_type character varying(50),
    auth_credentials_encrypted text,
    signing_secret character varying(255),
    events text[] NOT NULL,
    enabled boolean DEFAULT true,
    retry_enabled boolean DEFAULT true,
    max_retries integer DEFAULT 3,
    timeout_seconds integer DEFAULT 30,
    rate_limit integer,
    custom_headers jsonb,
    last_success_at timestamp with time zone,
    last_failure_at timestamp with time zone,
    consecutive_failures integer DEFAULT 0,
    total_events_sent integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.webhook_endpoints OWNER TO alisaberi;

--
-- Name: TABLE webhook_endpoints; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.webhook_endpoints IS 'Webhook endpoint configuration';


--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.webhook_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    endpoint_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    event_id character varying(255) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    last_response_status integer,
    last_response_body text,
    last_response_headers jsonb,
    last_error text,
    created_at timestamp with time zone DEFAULT now(),
    scheduled_for timestamp with time zone DEFAULT now(),
    sent_at timestamp with time zone,
    next_retry_at timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '7 days'::interval)
);


ALTER TABLE public.webhook_events OWNER TO alisaberi;

--
-- Name: TABLE webhook_events; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.webhook_events IS 'Webhook event queue';


--
-- Name: zk_compliance_proofs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zk_compliance_proofs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    transaction_id uuid,
    jurisdiction character varying(10) NOT NULL,
    proof_type character varying(50) NOT NULL,
    proof_data text NOT NULL,
    proof_hash character varying(64) NOT NULL,
    verifier_public_key text,
    verification_status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    verified_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT zk_compliance_proofs_proof_type_check CHECK (((proof_type)::text = ANY ((ARRAY['tax_paid'::character varying, 'vat_collected'::character varying, 'aml_cleared'::character varying, 'sanctions_checked'::character varying, 'kyc_verified'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT zk_compliance_proofs_verification_status_check CHECK (((verification_status)::text = ANY ((ARRAY['pending'::character varying, 'verified'::character varying, 'failed'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.zk_compliance_proofs OWNER TO alisaberi;

--
-- Name: TABLE zk_compliance_proofs; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.zk_compliance_proofs IS 'Zero-knowledge compliance proofs for transactions';


--
-- Data for Name: account_recovery_requests; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.account_recovery_requests (id, tenant_id, user_id, recovery_type, search_criteria, matched_accounts, verification_status, verification_level, failed_attempts, risk_score, ip_address, user_agent, device_fingerprint, created_at, updated_at, completed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: anomaly_detections; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.anomaly_detections (id, user_id, anomaly_type, description, confidence, impact_score, detected_at, resolved, resolved_at, metadata) FROM stdin;
\.


--
-- Data for Name: api_key_templates; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.api_key_templates (id, tenant_id, name, description, scopes, rate_limit, ip_whitelist, default_expiry_days, is_active, created_at, updated_at) FROM stdin;
a1b8879c-faab-46b6-9d47-48eaff964175	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	Read Only	Read-only access to all resources	["read:*"]	1000	\N	365	t	2025-09-20 15:10:29.71888-04	2025-09-20 15:10:29.71888-04
3c56d8b1-e33b-4492-b15a-7f3a2706174c	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	Full Access	Full access to all resources	["*"]	10000	\N	90	t	2025-09-20 15:10:29.721276-04	2025-09-20 15:10:29.721276-04
05295dc4-d238-44a5-a144-a6be469577f0	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	Webhook Only	Access to webhook endpoints only	["webhook:send", "webhook:status"]	5000	\N	\N	t	2025-09-20 15:10:29.721759-04	2025-09-20 15:10:29.721759-04
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.api_keys (id, tenant_id, application_id, name, key_hash, key_prefix, description, scopes, rate_limit, ip_whitelist, metadata, last_used_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.applications (id, tenant_id, client_id, client_secret_hash, name, description, logo_url, redirect_uris, allowed_origins, grant_types, response_types, scopes, trusted, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.audit_logs (id, tenant_id, user_id, event_type, event_category, ip_address, user_agent, device_id, success, error_code, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: communication_templates; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.communication_templates (id, tenant_id, template_type, nudge_template_id, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: deletion_audit; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.deletion_audit (id, user_id, action, performed_by, reason, notes, metadata, ip_address, user_agent, environment, created_at) FROM stdin;
\.


--
-- Data for Name: device_fingerprints; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.device_fingerprints (id, fingerprint_hash, user_id, device_info, trust_score, is_trusted, last_seen, seen_count, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.devices (id, user_id, device_fingerprint, device_name, device_type, platform, browser, trusted, last_ip, last_location, push_token, metadata, last_seen_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_queue; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.email_queue (id, tenant_id, to_email, from_email, subject, template_id, template_data, body_html, body_text, status, priority, attempts, max_attempts, scheduled_for, processed_at, failed_at, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: fraud_indicators; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.fraud_indicators (id, indicator_type, indicator_value, threat_level, source, reported_by, verified, expires_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ip_blacklist; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.ip_blacklist (id, ip_address, reason, threat_score, blocked_at, blocked_until, blocked_by, auto_blocked, permanent, metadata, unblocked_at, unblocked_by) FROM stdin;
\.


--
-- Data for Name: ip_reputation; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.ip_reputation (id, ip_address, reputation_score, is_vpn, is_tor, is_proxy, is_datacenter, country_code, risk_level, last_seen, total_requests, failed_attempts, successful_logins, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.ip_whitelist (id, ip_address, description, added_at, added_by, expires_at, metadata) FROM stdin;
\.


--
-- Data for Name: mfa_configs; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.mfa_configs (id, user_id, mfa_type, is_primary, is_enabled, secret_encrypted, backup_codes, verified, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: nudge_delivery_logs; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.nudge_delivery_logs (id, tenant_id, verification_id, nudge_id, message_id, channel, status, created_at) FROM stdin;
\.


--
-- Data for Name: nudge_otp_logs; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.nudge_otp_logs (id, tenant_id, verification_id, nudge_id, recipient, channel, purpose, code, status, message_id, format, otp_config, attempts, max_attempts, echo_mode, response_data, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: nudge_templates; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.nudge_templates (id, tenant_id, name, nudge_id, channel, purpose, description, variables, sample_content, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.otp_codes (id, user_id, code, purpose, expires_at, used_at, attempt_count, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: otp_templates; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.otp_templates (id, tenant_id, name, channel, format, length, word_count, word_source, word_separator, case_sensitive, custom_words, expiry_minutes, max_attempts, description, is_default, created_at, updated_at) FROM stdin;
531c0ad9-f3ca-4a31-b98a-53a925697946	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	default_sms	sms	numeric	6	3	curated	-	f	\N	10	3	Default SMS OTP template with 6-digit numeric code	t	2025-09-20 15:10:39.760208-04	2025-09-20 15:10:39.760208-04
74331e6c-cb55-4b69-b10d-4dc8b4865482	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	default_email	email	alphanumeric	8	3	curated	-	f	\N	15	5	Default email OTP template with 8-character alphanumeric code	t	2025-09-20 15:10:39.762443-04	2025-09-20 15:10:39.762443-04
2bf6cbcc-04bf-4ced-8b4f-87e8af3c4952	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	default_voice	voice	words	6	3	curated	-	f	\N	10	3	Default voice OTP template with 3 easy-to-pronounce words	t	2025-09-20 15:10:39.763094-04	2025-09-20 15:10:39.763094-04
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.password_history (id, user_id, password_hash, created_at) FROM stdin;
\.


--
-- Data for Name: password_policies; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.password_policies (id, tenant_id, min_length, max_length, require_uppercase, require_lowercase, require_numbers, require_special, special_chars, prevent_common_passwords, prevent_user_info, password_history_count, min_password_age_days, max_password_age_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.permissions (id, tenant_id, name, resource, action, scope, conditions, display_name, description, is_system, metadata, created_at, updated_at) FROM stdin;
3877ed67-981a-4c73-b5ce-727f16b1671b	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	users.create	users	create	tenant	\N	Create Users	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
24b08dca-6c5e-4a40-868b-1f9d6f16d497	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	users.read	users	read	tenant	\N	View Users	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
3f970433-76cb-45f5-a25f-62a5ddc4fbc9	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	users.update	users	update	tenant	\N	Update Users	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
548cf503-04ff-4086-a479-029c0985f25c	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	users.delete	users	delete	tenant	\N	Delete Users	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
10c91983-e374-41d9-955d-6b07ab4178af	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	roles.manage	roles	manage	tenant	\N	Manage Roles	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
5a321db7-e3bf-4921-b3b0-66daa04eefd3	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	audit.read	audit	read	tenant	\N	View Audit Logs	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
375a5520-a5f4-40b3-b7a5-8868a8d44af8	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	webhooks.manage	webhooks	manage	tenant	\N	Manage Webhooks	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
583e5b70-850b-4e33-a98a-76e016493cc3	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	api_keys.manage	api_keys	manage	tenant	\N	Manage API Keys	\N	t	{}	2025-09-20 15:21:18.795123-04	2025-09-20 15:21:18.795123-04
\.


--
-- Data for Name: rate_limit_violations; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.rate_limit_violations (id, identifier, endpoint, window_start, request_count, limit_exceeded_at, blocked_until, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: rate_limits; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.rate_limits (id, identifier, endpoint, window_start, request_count) FROM stdin;
\.


--
-- Data for Name: risk_assessments; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.risk_assessments (id, user_id, session_id, score, level, factors, requires_mfa, requires_challenge, should_block, recommendations, action_taken, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: risk_scores; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.risk_scores (id, session_id, user_id, risk_score, factors, action_taken, analyzed_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.role_permissions (id, role_id, permission_id, granted, conditions, granted_by, granted_at) FROM stdin;
8545eb39-53ab-44c8-815d-99db68dc54a8	5e3c33cb-105c-4e01-8279-795ac759270c	3877ed67-981a-4c73-b5ce-727f16b1671b	t	\N	\N	2025-09-20 15:21:18.796715-04
8c26eefd-8983-4dfc-895a-963ee48d2ab2	5e3c33cb-105c-4e01-8279-795ac759270c	24b08dca-6c5e-4a40-868b-1f9d6f16d497	t	\N	\N	2025-09-20 15:21:18.796715-04
436f7408-5c4a-481a-a542-864c1671a08b	5e3c33cb-105c-4e01-8279-795ac759270c	3f970433-76cb-45f5-a25f-62a5ddc4fbc9	t	\N	\N	2025-09-20 15:21:18.796715-04
04e45658-b500-4830-b4a1-ee321f6e18bb	5e3c33cb-105c-4e01-8279-795ac759270c	548cf503-04ff-4086-a479-029c0985f25c	t	\N	\N	2025-09-20 15:21:18.796715-04
79ec0f4e-8617-4346-97d8-15e80709d891	5e3c33cb-105c-4e01-8279-795ac759270c	10c91983-e374-41d9-955d-6b07ab4178af	t	\N	\N	2025-09-20 15:21:18.796715-04
c9f6fc3d-b8a7-4cf8-9537-eeab0bc75428	5e3c33cb-105c-4e01-8279-795ac759270c	5a321db7-e3bf-4921-b3b0-66daa04eefd3	t	\N	\N	2025-09-20 15:21:18.796715-04
3a5815ae-de87-401d-9427-e645d99d1cab	5e3c33cb-105c-4e01-8279-795ac759270c	375a5520-a5f4-40b3-b7a5-8868a8d44af8	t	\N	\N	2025-09-20 15:21:18.796715-04
36c98bcd-a87c-44d7-b413-78b43c6d3c8b	5e3c33cb-105c-4e01-8279-795ac759270c	583e5b70-850b-4e33-a98a-76e016493cc3	t	\N	\N	2025-09-20 15:21:18.796715-04
4ebfef20-3f10-4aa7-92d0-92cd98cbd65d	70997d81-b6f2-43b7-ab1c-684876a6ea85	3877ed67-981a-4c73-b5ce-727f16b1671b	t	\N	\N	2025-09-20 15:21:18.79774-04
d1f87014-48ac-436b-a0ff-49d498ad721b	70997d81-b6f2-43b7-ab1c-684876a6ea85	24b08dca-6c5e-4a40-868b-1f9d6f16d497	t	\N	\N	2025-09-20 15:21:18.79774-04
aa0c43b5-7b8e-45f4-86b2-bf16a12be5c0	70997d81-b6f2-43b7-ab1c-684876a6ea85	3f970433-76cb-45f5-a25f-62a5ddc4fbc9	t	\N	\N	2025-09-20 15:21:18.79774-04
3eb912f2-06fe-4224-94a2-cfca68e43001	70997d81-b6f2-43b7-ab1c-684876a6ea85	10c91983-e374-41d9-955d-6b07ab4178af	t	\N	\N	2025-09-20 15:21:18.79774-04
7b634f29-e42c-4b08-ad3b-231b73c4fa54	70997d81-b6f2-43b7-ab1c-684876a6ea85	5a321db7-e3bf-4921-b3b0-66daa04eefd3	t	\N	\N	2025-09-20 15:21:18.79774-04
6041d804-ac43-4e60-9dc0-72030dfd47de	4b3f08f6-9643-425c-8390-4a3eea5c5727	24b08dca-6c5e-4a40-868b-1f9d6f16d497	t	\N	\N	2025-09-20 15:21:18.798098-04
810e8025-288a-4d4e-9724-f7fbb48b2383	4b3f08f6-9643-425c-8390-4a3eea5c5727	5a321db7-e3bf-4921-b3b0-66daa04eefd3	t	\N	\N	2025-09-20 15:21:18.798098-04
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.roles (id, tenant_id, name, display_name, description, is_system, is_default, parent_role_id, priority, metadata, created_at, updated_at) FROM stdin;
5e3c33cb-105c-4e01-8279-795ac759270c	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	super_admin	Super Admin	Full system access	t	f	\N	1000	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
70997d81-b6f2-43b7-ab1c-684876a6ea85	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	admin	Administrator	Tenant administration	t	f	\N	900	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
deaabb6e-a37f-4168-a7aa-2c7237e25ae8	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	user_manager	User Manager	Manage users and roles	t	f	\N	800	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
4b3f08f6-9643-425c-8390-4a3eea5c5727	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	auditor	Auditor	View audit logs and reports	t	f	\N	700	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
d8ffcad7-1ff4-4439-936b-fdf2dec86d99	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	developer	Developer	API and webhook management	t	f	\N	600	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
b2e26961-507e-4fe7-bece-0fe7df2cb81f	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	support	Support	User support and assistance	t	f	\N	500	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
df056889-2c8c-4370-8fbc-88c7cb0ba2c0	1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	user	User	Standard user access	t	f	\N	100	{}	2025-09-20 15:21:18.794023-04	2025-09-20 15:21:18.794023-04
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.security_events (id, event_type, user_id, ip_address, path, method, severity, metadata, resolved, resolved_at, resolved_by, created_at) FROM stdin;
\.


--
-- Data for Name: security_question_templates; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.security_question_templates (id, question_text, category, min_answer_length, max_answer_length, is_active, created_at) FROM stdin;
1	What was the name of your first pet?	personal	3	50	t	2025-09-20 15:10:49.977634-04
2	In what city were you born?	location	3	50	t	2025-09-20 15:10:49.977634-04
3	What is your mother's maiden name?	family	3	50	t	2025-09-20 15:10:49.977634-04
4	What was the make of your first car?	personal	3	50	t	2025-09-20 15:10:49.977634-04
5	What elementary school did you attend?	education	3	50	t	2025-09-20 15:10:49.977634-04
6	What is your favorite movie?	preference	3	50	t	2025-09-20 15:10:49.977634-04
7	What was your childhood nickname?	personal	3	50	t	2025-09-20 15:10:49.977634-04
8	In what city did you meet your spouse/significant other?	location	3	50	t	2025-09-20 15:10:49.977634-04
9	What is the name of your favorite childhood friend?	personal	3	50	t	2025-09-20 15:10:49.977634-04
10	What street did you live on in third grade?	location	3	50	t	2025-09-20 15:10:49.977634-04
11	What is your oldest sibling's middle name?	family	3	50	t	2025-09-20 15:10:49.977634-04
12	What school did you attend for sixth grade?	education	3	50	t	2025-09-20 15:10:49.977634-04
13	What was your childhood phone number?	personal	3	50	t	2025-09-20 15:10:49.977634-04
14	What is your favorite team?	preference	3	50	t	2025-09-20 15:10:49.977634-04
15	What is your father's middle name?	family	3	50	t	2025-09-20 15:10:49.977634-04
\.


--
-- Data for Name: security_questions; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.security_questions (id, user_id, question_id, answer_hash, answer_hint, created_at, updated_at, last_used_at, usage_count) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.sessions (id, tenant_id, user_id, application_id, session_token, refresh_token, access_token_jti, device_id, ip_address, user_agent, location, auth_method, mfa_verified, expires_at, refresh_expires_at, last_activity_at, revoked_at, created_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.sso_providers (id, tenant_id, provider_name, provider_type, client_id, client_secret_encrypted, issuer_url, authorization_url, token_url, userinfo_url, jwks_uri, scopes, attribute_mapping, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.tenant_settings (tenant_id, enrollment_link_expiry_days, password_reset_expiry_hours, otp_expiry_minutes, max_enrollment_attempts, require_mfa_enrollment, require_email_verification, require_phone_verification, allow_passwordless_enrollment, password_min_length, password_require_uppercase, password_require_lowercase, password_require_numbers, password_require_special, password_history_count, session_timeout_minutes, max_concurrent_sessions, enrollment_email_template_id, enrollment_sms_template_id, password_reset_email_template_id, password_reset_sms_template_id, enable_social_auth, enable_biometric_auth, enable_device_tracking, enable_risk_analysis, created_at, updated_at, created_by, updated_by) FROM stdin;
1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	5	24	10	3	f	t	f	f	8	t	t	t	t	5	60	5	\N	\N	\N	\N	t	t	t	t	2025-09-20 15:10:44.661001-04	2025-09-20 15:10:44.661001-04	\N	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.tenants (id, name, slug, domain, settings, features, api_quota, max_users, is_active, created_at, updated_at) FROM stdin;
1d2bb6e9-dc38-4c5c-9eeb-cba56e18bc56	Saberi Co	saberi	www.saberi.us	{"plan": "Startup", "limits": {"max_users": 10, "max_api_calls": 10000, "max_applications": 1}, "billing": {"plan": "Startup", "status": "active", "trial_ends_at": "2025-09-30T13:42:05.882Z"}, "contact": {"name": "Ali Saberi", "email": "ali@saberi.us"}, "features": {"mfa_enabled": true, "sso_enabled": true, "webhooks_enabled": true, "biometric_enabled": true, "advanced_rbac_enabled": true, "custom_domain_enabled": true}}	{"mfa": true, "sso": true, "passwordless": true}	10000	\N	t	2025-09-16 09:42:05.891649-04	2025-09-16 09:42:05.891649-04
3115c66d-3867-41c8-8c7c-5f08a9bf377c	Monay	monay	monay.com	{"plan": "Startup", "limits": {"max_users": 10, "max_api_calls": 10000, "max_applications": 1}, "billing": {"plan": "Startup", "status": "active", "trial_ends_at": "2025-10-05T06:09:08.967Z"}, "contact": {"name": "Ali Saberi", "email": "ali@monay.com"}, "features": {"mfa_enabled": true, "sso_enabled": true, "webhooks_enabled": true, "biometric_enabled": true, "advanced_rbac_enabled": true, "custom_domain_enabled": true}}	{"mfa": true, "sso": true, "passwordless": true}	10000	\N	t	2025-09-21 02:09:08.972896-04	2025-09-21 02:09:08.972896-04
\.


--
-- Data for Name: traffic_patterns; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.traffic_patterns (id, ip_address, pattern_type, confidence_score, detected_at, pattern_data, action_taken) FROM stdin;
\.


--
-- Data for Name: user_risk_profiles; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.user_risk_profiles (id, user_id, baseline_score, current_score, highest_score, risk_factors, known_devices, known_locations, typical_behavior, anomaly_count, last_risk_assessment, requires_enhanced_monitoring, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.user_roles (id, user_id, role_id, tenant_id, scope, resource_id, valid_from, valid_until, assigned_by, assigned_at, assignment_reason) FROM stdin;
\.


--
-- Data for Name: user_sso_connections; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.user_sso_connections (id, user_id, provider_id, external_user_id, access_token_encrypted, refresh_token_encrypted, token_expires_at, profile_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.users (id, tenant_id, external_id, email, phone, username, password_hash, first_name, last_name, display_name, avatar_url, status, email_verified, phone_verified, metadata, last_login_at, created_at, updated_at, enrollment_status, enrollment_completed_at, enrollment_method, recovery_email, recovery_email_verified, recovery_phone, recovery_phone_verified, security_questions_configured, password_changed_at, last_recovery_at, recovery_attempts, deleted_at, deletion_requested_at, deletion_requested_by, deletion_reason, deletion_notes, disabled_at, disabled_by, disabled_reason, can_be_purged, purge_after, restoration_token, last_status_before_deletion) FROM stdin;
\.


--
-- Data for Name: velocity_tracking; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.velocity_tracking (id, identifier, action_type, window_start, window_duration, action_count, threshold, exceeded, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.webauthn_credentials (id, user_id, credential_id, public_key, counter, aaguid, name, device_type, transports, backup_eligible, backup_status, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.webhook_delivery_logs (id, endpoint_id, event_id, url, method, headers, payload, status_code, response_headers, response_body, success, error_message, attempted_at, duration_ms, attempt_number, next_retry_at) FROM stdin;
\.


--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.webhook_endpoints (id, tenant_id, url, description, auth_type, auth_credentials_encrypted, signing_secret, events, enabled, retry_enabled, max_retries, timeout_seconds, rate_limit, custom_headers, last_success_at, last_failure_at, consecutive_failures, total_events_sent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: auth; Owner: alisaberi
--

COPY auth.webhook_events (id, tenant_id, event_type, event_id, resource_type, resource_id, payload, processed, processed_at, retry_count, last_error, created_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.audit_logs (id, tenant_id, user_id, session_id, event_type, event_category, description, ip_address, user_agent, location, device_info, metadata, risk_score, status, error_message, duration_ms, created_at) FROM stdin;
\.


--
-- Data for Name: behavioral_biometric_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.behavioral_biometric_profiles (id, enrollment_id, user_id, tenant_id, session_id, typing_pattern, mouse_pattern, touch_pattern, scroll_pattern, device_motion, interaction_timing, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: biometric_challenges; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.biometric_challenges (id, user_id, tenant_id, type, challenge, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: biometric_enrollments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.biometric_enrollments (id, user_id, tenant_id, type, status, enrollment_data, device_info, created_at, updated_at, last_used_at, verification_count, failure_count) FROM stdin;
\.


--
-- Data for Name: biometric_verification_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.biometric_verification_logs (id, enrollment_id, user_id, tenant_id, verification_type, success, score, confidence, liveness_detected, spoofing_detected, risk_score, additional_factor_required, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: custodian_assignments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custodian_assignments (id, tenant_id, user_id, custodian_id, permissions, is_primary, requires_approval_from, time_delay_hours, status, invited_at, accepted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: custodian_responses; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custodian_responses (id, recovery_request_id, custodian_id, response, reason, verification_method, verification_data, voice_verification_id, ip_address, user_agent, responded_at) FROM stdin;
\.


--
-- Data for Name: custodian_verification_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custodian_verification_sessions (id, custodian_id, recovery_request_id, session_type, session_data, voice_sample_url, voice_match_score, voice_liveness_score, verification_passed, failure_reason, started_at, completed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: custodians; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custodians (id, tenant_id, user_id, email, name, type, status, verification_level, kyc_data, verification_documents, biometric_data, voice_print_id, organization_name, license_number, jurisdiction, insurance_coverage, reputation_score, successful_recoveries, failed_recoveries, average_response_time, verified_at, last_verification_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_queue; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.email_queue (id, tenant_id, to_email, from_email, subject, template_id, template_data, body_html, body_text, status, priority, attempts, max_attempts, scheduled_for, processed_at, failed_at, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.email_verification_tokens (id, tenant_id, user_id, email, token, verified, verified_at, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: invoice_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_wallets (id, invoice_id, mode, base_address, solana_address, quantum_public_key, quantum_encrypted_private_key, created_at, expires_at, destroyed_at, status, features, compliance_proofs, transformation_history, ai_score, ttl_seconds, created_by, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoices (id, invoice_number, user_id, type, amount, currency, status, client_name, vendor_name, description, payment_method, due_date, paid_date, is_recurring, metadata, created_at, updated_at) FROM stdin;
aa649e2d-f135-463d-b2ad-bddc26a5effd	TEST-INV-001	\N	outbound	50000.00	USD	pending	Test Client Corp	\N	Test Invoice for Wallet Generation	USDM	2025-02-01	\N	f	{}	2025-09-20 02:50:36.848672	2025-09-20 02:50:36.848672
\.


--
-- Data for Name: magic_links; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.magic_links (id, tenant_id, user_id, email, token, purpose, ip_address, user_agent, fingerprint, used, used_at, revoked, revoked_reason, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: nudge_credit_tracking; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.nudge_credit_tracking (id, tenant_id, credit_used, credit_remaining, currency, operation, nudge_id, message_count, billing_tier, created_at) FROM stdin;
\.


--
-- Data for Name: nudge_delivery_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.nudge_delivery_logs (id, tenant_id, verification_id, nudge_id, message_id, channel, recipient, status, response_data, error_message, created_at, delivered_at) FROM stdin;
\.


--
-- Data for Name: nudge_notification_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.nudge_notification_logs (id, tenant_id, user_id, nudge_id, message_id, channel, recipient, status, context, created_at, delivered_at) FROM stdin;
\.


--
-- Data for Name: nudge_templates; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.nudge_templates (id, tenant_id, name, nudge_id, channel, purpose, description, variables, sample_content, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.oauth_states (id, state, provider, tenant_id, redirect_uri, code_challenge, code_challenge_method, nonce, metadata, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.otp_codes (id, tenant_id, user_id, identifier, identifier_type, code, purpose, delivery_method, delivery_provider, delivery_status, delivery_attempts, last_delivery_attempt, ip_address, user_agent, verification_attempts, max_attempts, verified, verified_at, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: otp_verifications; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.otp_verifications (id, tenant_id, user_id, code, recipient, channel, purpose, attempts, verified, verified_at, metadata, ip_address, user_agent, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.password_reset_tokens (id, tenant_id, user_id, token, reset_method, verification_code, ip_address, user_agent, old_password_hash, used, used_at, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: passwordless_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.passwordless_sessions (id, tenant_id, user_id, session_token, auth_method, auth_identifier, state, verification_token, ip_address, user_agent, device_fingerprint, location, risk_score, initiated_at, verified_at, completed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.permissions (id, tenant_id, name, resource, action, scope, conditions, display_name, description, is_system, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quantum_key_registry; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.quantum_key_registry (id, wallet_id, algorithm, public_key, key_version, created_at, rotated_at, is_active, security_level) FROM stdin;
\.


--
-- Data for Name: recovery_requests; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.recovery_requests (id, tenant_id, user_id, request_type, status, reason, required_approvals, current_approvals, time_delay_hours, verification_code, verification_method, ip_address, user_agent, requested_at, approved_at, executed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.role_permissions (id, role_id, permission_id, granted_by, granted_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.roles (id, tenant_id, name, display_name, description, is_system, is_default, parent_role_id, priority, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: social_accounts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.social_accounts (id, user_id, tenant_id, provider, provider_user_id, email, email_verified, name, given_name, family_name, picture, locale, provider_data, access_token_encrypted, refresh_token_encrypted, token_expires_at, linked_at, last_login_at) FROM stdin;
\.


--
-- Data for Name: social_auth_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.social_auth_logs (id, user_id, tenant_id, provider, event_type, provider_user_id, email, ip_address, user_agent, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: social_providers; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.social_providers (id, tenant_id, provider_name, client_id, client_secret_encrypted, redirect_uri, scopes, enabled, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_roles (id, user_id, role_id, tenant_id, resource_type, resource_id, granted_by, granted_at, expires_at, is_active) FROM stdin;
\.


--
-- Data for Name: voice_biometric_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.voice_biometric_profiles (id, enrollment_id, user_id, tenant_id, voice_print_id, voice_features, audio_samples, language_detected, quality_score, liveness_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wallet_lifecycle_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_lifecycle_events (id, wallet_id, event_type, event_data, actor_id, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- Data for Name: wallet_mode_decisions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_mode_decisions (id, invoice_id, selected_mode, ai_score, decision_factors, override_reason, overridden_by, transaction_amount, customer_risk_score, is_recurring, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_delivery_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.webhook_delivery_logs (id, event_id, endpoint_id, attempt_number, request_headers, request_body, response_status, response_headers, response_body, response_time_ms, success, error_message, attempted_at) FROM stdin;
\.


--
-- Data for Name: webhook_endpoints; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.webhook_endpoints (id, tenant_id, url, description, auth_type, auth_credentials_encrypted, signing_secret, events, enabled, retry_enabled, max_retries, timeout_seconds, rate_limit, custom_headers, last_success_at, last_failure_at, consecutive_failures, total_events_sent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.webhook_events (id, tenant_id, endpoint_id, event_type, event_id, payload, status, attempts, last_response_status, last_response_body, last_response_headers, last_error, created_at, scheduled_for, sent_at, next_retry_at, expires_at) FROM stdin;
\.


--
-- Data for Name: zk_compliance_proofs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zk_compliance_proofs (id, wallet_id, transaction_id, jurisdiction, proof_type, proof_data, proof_hash, verifier_public_key, verification_status, created_at, expires_at, verified_at, metadata) FROM stdin;
\.


--
-- Name: account_recovery_requests account_recovery_requests_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.account_recovery_requests
    ADD CONSTRAINT account_recovery_requests_pkey PRIMARY KEY (id);


--
-- Name: anomaly_detections anomaly_detections_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.anomaly_detections
    ADD CONSTRAINT anomaly_detections_pkey PRIMARY KEY (id);


--
-- Name: api_key_templates api_key_templates_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_key_templates
    ADD CONSTRAINT api_key_templates_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: applications applications_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.applications
    ADD CONSTRAINT applications_client_id_key UNIQUE (client_id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- Name: communication_templates communication_templates_tenant_id_template_type_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.communication_templates
    ADD CONSTRAINT communication_templates_tenant_id_template_type_key UNIQUE (tenant_id, template_type);


--
-- Name: deletion_audit deletion_audit_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.deletion_audit
    ADD CONSTRAINT deletion_audit_pkey PRIMARY KEY (id);


--
-- Name: device_fingerprints device_fingerprints_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.device_fingerprints
    ADD CONSTRAINT device_fingerprints_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: devices devices_user_id_device_fingerprint_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.devices
    ADD CONSTRAINT devices_user_id_device_fingerprint_key UNIQUE (user_id, device_fingerprint);


--
-- Name: email_queue email_queue_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.email_queue
    ADD CONSTRAINT email_queue_pkey PRIMARY KEY (id);


--
-- Name: fraud_indicators fraud_indicators_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.fraud_indicators
    ADD CONSTRAINT fraud_indicators_pkey PRIMARY KEY (id);


--
-- Name: ip_blacklist ip_blacklist_ip_address_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_blacklist
    ADD CONSTRAINT ip_blacklist_ip_address_key UNIQUE (ip_address);


--
-- Name: ip_blacklist ip_blacklist_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_blacklist
    ADD CONSTRAINT ip_blacklist_pkey PRIMARY KEY (id);


--
-- Name: ip_reputation ip_reputation_ip_address_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_reputation
    ADD CONSTRAINT ip_reputation_ip_address_key UNIQUE (ip_address);


--
-- Name: ip_reputation ip_reputation_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_reputation
    ADD CONSTRAINT ip_reputation_pkey PRIMARY KEY (id);


--
-- Name: ip_whitelist ip_whitelist_ip_address_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_whitelist
    ADD CONSTRAINT ip_whitelist_ip_address_key UNIQUE (ip_address);


--
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- Name: mfa_configs mfa_configs_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.mfa_configs
    ADD CONSTRAINT mfa_configs_pkey PRIMARY KEY (id);


--
-- Name: mfa_configs mfa_configs_user_id_mfa_type_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.mfa_configs
    ADD CONSTRAINT mfa_configs_user_id_mfa_type_key UNIQUE (user_id, mfa_type);


--
-- Name: nudge_delivery_logs nudge_delivery_logs_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_delivery_logs
    ADD CONSTRAINT nudge_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: nudge_otp_logs nudge_otp_logs_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_otp_logs
    ADD CONSTRAINT nudge_otp_logs_pkey PRIMARY KEY (id);


--
-- Name: nudge_templates nudge_templates_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_templates
    ADD CONSTRAINT nudge_templates_pkey PRIMARY KEY (id);


--
-- Name: nudge_templates nudge_templates_tenant_id_name_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_templates
    ADD CONSTRAINT nudge_templates_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- Name: otp_templates otp_templates_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_templates
    ADD CONSTRAINT otp_templates_pkey PRIMARY KEY (id);


--
-- Name: otp_templates otp_templates_tenant_id_name_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_templates
    ADD CONSTRAINT otp_templates_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: password_policies password_policies_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.password_policies
    ADD CONSTRAINT password_policies_pkey PRIMARY KEY (id);


--
-- Name: password_policies password_policies_tenant_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.password_policies
    ADD CONSTRAINT password_policies_tenant_id_key UNIQUE (tenant_id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: rate_limit_violations rate_limit_violations_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.rate_limit_violations
    ADD CONSTRAINT rate_limit_violations_pkey PRIMARY KEY (id);


--
-- Name: rate_limits rate_limits_identifier_endpoint_window_start_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.rate_limits
    ADD CONSTRAINT rate_limits_identifier_endpoint_window_start_key UNIQUE (identifier, endpoint, window_start);


--
-- Name: rate_limits rate_limits_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.rate_limits
    ADD CONSTRAINT rate_limits_pkey PRIMARY KEY (id);


--
-- Name: risk_assessments risk_assessments_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.risk_assessments
    ADD CONSTRAINT risk_assessments_pkey PRIMARY KEY (id);


--
-- Name: risk_scores risk_scores_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.risk_scores
    ADD CONSTRAINT risk_scores_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: security_question_templates security_question_templates_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_question_templates
    ADD CONSTRAINT security_question_templates_pkey PRIMARY KEY (id);


--
-- Name: security_questions security_questions_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_questions
    ADD CONSTRAINT security_questions_pkey PRIMARY KEY (id);


--
-- Name: security_questions security_questions_user_id_question_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_questions
    ADD CONSTRAINT security_questions_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: sessions sessions_access_token_jti_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_access_token_jti_key UNIQUE (access_token_jti);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_refresh_token_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: sessions sessions_session_token_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_session_token_key UNIQUE (session_token);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_tenant_id_provider_name_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_tenant_id_provider_name_key UNIQUE (tenant_id, provider_name);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: traffic_patterns traffic_patterns_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.traffic_patterns
    ADD CONSTRAINT traffic_patterns_pkey PRIMARY KEY (id);


--
-- Name: otp_codes unique_active_otp; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_codes
    ADD CONSTRAINT unique_active_otp UNIQUE (user_id, purpose, used_at);


--
-- Name: fraud_indicators unique_fraud_indicator; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.fraud_indicators
    ADD CONSTRAINT unique_fraud_indicator UNIQUE (indicator_type, indicator_value);


--
-- Name: api_keys unique_key_hash; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_keys
    ADD CONSTRAINT unique_key_hash UNIQUE (key_hash);


--
-- Name: permissions unique_permission; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.permissions
    ADD CONSTRAINT unique_permission UNIQUE (tenant_id, name);


--
-- Name: rate_limit_violations unique_rate_window; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.rate_limit_violations
    ADD CONSTRAINT unique_rate_window UNIQUE (identifier, endpoint, window_start);


--
-- Name: permissions unique_resource_action; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.permissions
    ADD CONSTRAINT unique_resource_action UNIQUE (tenant_id, resource, action, scope);


--
-- Name: role_permissions unique_role_permission; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.role_permissions
    ADD CONSTRAINT unique_role_permission UNIQUE (role_id, permission_id);


--
-- Name: api_key_templates unique_template_name; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_key_templates
    ADD CONSTRAINT unique_template_name UNIQUE (tenant_id, name);


--
-- Name: roles unique_tenant_role_name; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.roles
    ADD CONSTRAINT unique_tenant_role_name UNIQUE (tenant_id, name);


--
-- Name: webhook_endpoints unique_tenant_url; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_endpoints
    ADD CONSTRAINT unique_tenant_url UNIQUE (tenant_id, url);


--
-- Name: device_fingerprints unique_user_fingerprint; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.device_fingerprints
    ADD CONSTRAINT unique_user_fingerprint UNIQUE (user_id, fingerprint_hash);


--
-- Name: user_roles unique_user_role; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT unique_user_role UNIQUE (user_id, role_id, tenant_id, scope, resource_id);


--
-- Name: velocity_tracking unique_velocity_window; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.velocity_tracking
    ADD CONSTRAINT unique_velocity_window UNIQUE (identifier, action_type, window_start);


--
-- Name: user_risk_profiles user_risk_profiles_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_risk_profiles
    ADD CONSTRAINT user_risk_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_risk_profiles user_risk_profiles_user_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_risk_profiles
    ADD CONSTRAINT user_risk_profiles_user_id_key UNIQUE (user_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sso_connections user_sso_connections_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_sso_connections
    ADD CONSTRAINT user_sso_connections_pkey PRIMARY KEY (id);


--
-- Name: user_sso_connections user_sso_connections_provider_id_external_user_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_external_user_id_key UNIQUE (provider_id, external_user_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: users users_tenant_id_external_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_tenant_id_external_id_key UNIQUE (tenant_id, external_id);


--
-- Name: users users_tenant_id_phone_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_tenant_id_phone_key UNIQUE (tenant_id, phone);


--
-- Name: users users_tenant_id_username_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_tenant_id_username_key UNIQUE (tenant_id, username);


--
-- Name: velocity_tracking velocity_tracking_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.velocity_tracking
    ADD CONSTRAINT velocity_tracking_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_credential_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_event_id_key; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_events
    ADD CONSTRAINT webhook_events_event_id_key UNIQUE (event_id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: behavioral_biometric_profiles behavioral_biometric_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.behavioral_biometric_profiles
    ADD CONSTRAINT behavioral_biometric_profiles_pkey PRIMARY KEY (id);


--
-- Name: biometric_challenges biometric_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_challenges
    ADD CONSTRAINT biometric_challenges_pkey PRIMARY KEY (id);


--
-- Name: biometric_enrollments biometric_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_enrollments
    ADD CONSTRAINT biometric_enrollments_pkey PRIMARY KEY (id);


--
-- Name: biometric_verification_logs biometric_verification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_verification_logs
    ADD CONSTRAINT biometric_verification_logs_pkey PRIMARY KEY (id);


--
-- Name: custodian_assignments custodian_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_assignments
    ADD CONSTRAINT custodian_assignments_pkey PRIMARY KEY (id);


--
-- Name: custodian_responses custodian_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_responses
    ADD CONSTRAINT custodian_responses_pkey PRIMARY KEY (id);


--
-- Name: custodian_verification_sessions custodian_verification_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_verification_sessions
    ADD CONSTRAINT custodian_verification_sessions_pkey PRIMARY KEY (id);


--
-- Name: custodians custodians_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodians
    ADD CONSTRAINT custodians_pkey PRIMARY KEY (id);


--
-- Name: email_queue email_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_queue
    ADD CONSTRAINT email_queue_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_key UNIQUE (token);


--
-- Name: invoice_wallets invoice_wallets_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_invoice_id_key UNIQUE (invoice_id);


--
-- Name: invoice_wallets invoice_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_token_key UNIQUE (token);


--
-- Name: nudge_credit_tracking nudge_credit_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_credit_tracking
    ADD CONSTRAINT nudge_credit_tracking_pkey PRIMARY KEY (id);


--
-- Name: nudge_delivery_logs nudge_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_delivery_logs
    ADD CONSTRAINT nudge_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: nudge_notification_logs nudge_notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_notification_logs
    ADD CONSTRAINT nudge_notification_logs_pkey PRIMARY KEY (id);


--
-- Name: nudge_templates nudge_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_templates
    ADD CONSTRAINT nudge_templates_pkey PRIMARY KEY (id);


--
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (id);


--
-- Name: oauth_states oauth_states_state_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_state_key UNIQUE (state);


--
-- Name: otp_codes otp_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_pkey PRIMARY KEY (id);


--
-- Name: otp_verifications otp_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_key UNIQUE (token);


--
-- Name: passwordless_sessions passwordless_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.passwordless_sessions
    ADD CONSTRAINT passwordless_sessions_pkey PRIMARY KEY (id);


--
-- Name: passwordless_sessions passwordless_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.passwordless_sessions
    ADD CONSTRAINT passwordless_sessions_session_token_key UNIQUE (session_token);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: quantum_key_registry quantum_key_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_pkey PRIMARY KEY (id);


--
-- Name: quantum_key_registry quantum_key_registry_wallet_id_key_version_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_wallet_id_key_version_key UNIQUE (wallet_id, key_version);


--
-- Name: recovery_requests recovery_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recovery_requests
    ADD CONSTRAINT recovery_requests_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: social_accounts social_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_pkey PRIMARY KEY (id);


--
-- Name: social_auth_logs social_auth_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_auth_logs
    ADD CONSTRAINT social_auth_logs_pkey PRIMARY KEY (id);


--
-- Name: social_providers social_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_providers
    ADD CONSTRAINT social_providers_pkey PRIMARY KEY (id);


--
-- Name: custodian_responses unique_custodian_response; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_responses
    ADD CONSTRAINT unique_custodian_response UNIQUE (recovery_request_id, custodian_id);


--
-- Name: permissions unique_permission; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT unique_permission UNIQUE (tenant_id, resource, action, scope);


--
-- Name: social_accounts unique_provider_account; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT unique_provider_account UNIQUE (provider, provider_user_id);


--
-- Name: role_permissions unique_role_permission; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT unique_role_permission UNIQUE (role_id, permission_id);


--
-- Name: custodians unique_tenant_email; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodians
    ADD CONSTRAINT unique_tenant_email UNIQUE (tenant_id, email);


--
-- Name: social_providers unique_tenant_provider; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_providers
    ADD CONSTRAINT unique_tenant_provider UNIQUE (tenant_id, provider_name);


--
-- Name: roles unique_tenant_role_name; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT unique_tenant_role_name UNIQUE (tenant_id, name);


--
-- Name: nudge_templates unique_tenant_template; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_templates
    ADD CONSTRAINT unique_tenant_template UNIQUE (tenant_id, name);


--
-- Name: biometric_enrollments unique_user_biometric_type; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_enrollments
    ADD CONSTRAINT unique_user_biometric_type UNIQUE (user_id, tenant_id, type, status);


--
-- Name: custodian_assignments unique_user_custodian; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_assignments
    ADD CONSTRAINT unique_user_custodian UNIQUE (user_id, custodian_id);


--
-- Name: social_accounts unique_user_provider; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT unique_user_provider UNIQUE (user_id, provider);


--
-- Name: user_roles unique_user_role; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT unique_user_role UNIQUE (user_id, role_id, tenant_id, resource_type, resource_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: voice_biometric_profiles voice_biometric_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.voice_biometric_profiles
    ADD CONSTRAINT voice_biometric_profiles_pkey PRIMARY KEY (id);


--
-- Name: voice_biometric_profiles voice_biometric_profiles_voice_print_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.voice_biometric_profiles
    ADD CONSTRAINT voice_biometric_profiles_voice_print_id_key UNIQUE (voice_print_id);


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_pkey PRIMARY KEY (id);


--
-- Name: wallet_mode_decisions wallet_mode_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_mode_decisions
    ADD CONSTRAINT wallet_mode_decisions_pkey PRIMARY KEY (id);


--
-- Name: webhook_delivery_logs webhook_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_pkey PRIMARY KEY (id);


--
-- Name: webhook_endpoints webhook_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_event_id_key UNIQUE (event_id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: zk_compliance_proofs zk_compliance_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_pkey PRIMARY KEY (id);


--
-- Name: idx_account_recovery_requests_expires; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_account_recovery_requests_expires ON auth.account_recovery_requests USING btree (expires_at);


--
-- Name: idx_account_recovery_requests_status; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_account_recovery_requests_status ON auth.account_recovery_requests USING btree (verification_status);


--
-- Name: idx_account_recovery_requests_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_account_recovery_requests_user_id ON auth.account_recovery_requests USING btree (user_id);


--
-- Name: idx_anomaly_detections_detected; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_anomaly_detections_detected ON auth.anomaly_detections USING btree (detected_at DESC);


--
-- Name: idx_anomaly_detections_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_anomaly_detections_type ON auth.anomaly_detections USING btree (anomaly_type);


--
-- Name: idx_anomaly_detections_unresolved; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_anomaly_detections_unresolved ON auth.anomaly_detections USING btree (resolved) WHERE (resolved = false);


--
-- Name: idx_anomaly_detections_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_anomaly_detections_user ON auth.anomaly_detections USING btree (user_id);


--
-- Name: idx_api_keys_application_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_application_id ON auth.api_keys USING btree (application_id);


--
-- Name: idx_api_keys_expires_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_expires_at ON auth.api_keys USING btree (expires_at);


--
-- Name: idx_api_keys_is_active; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_is_active ON auth.api_keys USING btree (is_active);


--
-- Name: idx_api_keys_key_prefix; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_key_prefix ON auth.api_keys USING btree (key_prefix);


--
-- Name: idx_api_keys_last_used_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_last_used_at ON auth.api_keys USING btree (last_used_at);


--
-- Name: idx_api_keys_tenant_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_api_keys_tenant_id ON auth.api_keys USING btree (tenant_id);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_created_at ON auth.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_tenant_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_tenant_id ON auth.audit_logs USING btree (tenant_id);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_user_id ON auth.audit_logs USING btree (user_id);


--
-- Name: idx_deletion_audit_action; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_deletion_audit_action ON auth.deletion_audit USING btree (action);


--
-- Name: idx_deletion_audit_created_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_deletion_audit_created_at ON auth.deletion_audit USING btree (created_at);


--
-- Name: idx_deletion_audit_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_deletion_audit_user_id ON auth.deletion_audit USING btree (user_id);


--
-- Name: idx_device_fingerprints_hash; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_device_fingerprints_hash ON auth.device_fingerprints USING btree (fingerprint_hash);


--
-- Name: idx_device_fingerprints_trusted; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_device_fingerprints_trusted ON auth.device_fingerprints USING btree (is_trusted) WHERE (is_trusted = true);


--
-- Name: idx_device_fingerprints_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_device_fingerprints_user ON auth.device_fingerprints USING btree (user_id);


--
-- Name: idx_devices_fingerprint; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_devices_fingerprint ON auth.devices USING btree (device_fingerprint);


--
-- Name: idx_devices_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_devices_user_id ON auth.devices USING btree (user_id);


--
-- Name: idx_email_queue_priority; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_email_queue_priority ON auth.email_queue USING btree (priority, scheduled_for) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_email_queue_scheduled; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_email_queue_scheduled ON auth.email_queue USING btree (scheduled_for) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_email_queue_status; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_email_queue_status ON auth.email_queue USING btree (status);


--
-- Name: idx_email_queue_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_email_queue_tenant ON auth.email_queue USING btree (tenant_id);


--
-- Name: idx_fraud_indicators_expires; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_fraud_indicators_expires ON auth.fraud_indicators USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_fraud_indicators_threat; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_fraud_indicators_threat ON auth.fraud_indicators USING btree (threat_level);


--
-- Name: idx_fraud_indicators_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_fraud_indicators_type ON auth.fraud_indicators USING btree (indicator_type);


--
-- Name: idx_fraud_indicators_value; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_fraud_indicators_value ON auth.fraud_indicators USING btree (indicator_value);


--
-- Name: idx_ip_blacklist_blocked_until; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_blacklist_blocked_until ON auth.ip_blacklist USING btree (blocked_until) WHERE (blocked_until IS NOT NULL);


--
-- Name: idx_ip_blacklist_ip; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_blacklist_ip ON auth.ip_blacklist USING btree (ip_address);


--
-- Name: idx_ip_blacklist_permanent; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_blacklist_permanent ON auth.ip_blacklist USING btree (permanent) WHERE (permanent = true);


--
-- Name: idx_ip_reputation_ip; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_reputation_ip ON auth.ip_reputation USING btree (ip_address);


--
-- Name: idx_ip_reputation_risk; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_reputation_risk ON auth.ip_reputation USING btree (risk_level);


--
-- Name: idx_ip_reputation_score; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_reputation_score ON auth.ip_reputation USING btree (reputation_score);


--
-- Name: idx_ip_reputation_tor; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_reputation_tor ON auth.ip_reputation USING btree (is_tor) WHERE (is_tor = true);


--
-- Name: idx_ip_reputation_vpn; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_reputation_vpn ON auth.ip_reputation USING btree (is_vpn) WHERE (is_vpn = true);


--
-- Name: idx_ip_whitelist_expires; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_whitelist_expires ON auth.ip_whitelist USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_ip_whitelist_ip; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_ip_whitelist_ip ON auth.ip_whitelist USING btree (ip_address);


--
-- Name: idx_nudge_otp_logs_channel; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_channel ON auth.nudge_otp_logs USING btree (channel);


--
-- Name: idx_nudge_otp_logs_created_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_created_at ON auth.nudge_otp_logs USING btree (created_at);


--
-- Name: idx_nudge_otp_logs_echo_mode; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_echo_mode ON auth.nudge_otp_logs USING btree (echo_mode) WHERE (echo_mode IS NOT NULL);


--
-- Name: idx_nudge_otp_logs_recipient; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_recipient ON auth.nudge_otp_logs USING btree (recipient);


--
-- Name: idx_nudge_otp_logs_status; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_status ON auth.nudge_otp_logs USING btree (status);


--
-- Name: idx_nudge_otp_logs_tenant_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_tenant_id ON auth.nudge_otp_logs USING btree (tenant_id);


--
-- Name: idx_nudge_otp_logs_verification_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_otp_logs_verification_id ON auth.nudge_otp_logs USING btree (verification_id);


--
-- Name: idx_nudge_templates_active; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_active ON auth.nudge_templates USING btree (active);


--
-- Name: idx_nudge_templates_channel; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_channel ON auth.nudge_templates USING btree (channel);


--
-- Name: idx_nudge_templates_tenant_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_tenant_id ON auth.nudge_templates USING btree (tenant_id);


--
-- Name: idx_otp_codes_expires_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_expires_at ON auth.otp_codes USING btree (expires_at);


--
-- Name: idx_otp_codes_purpose; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_purpose ON auth.otp_codes USING btree (purpose);


--
-- Name: idx_otp_codes_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_user_id ON auth.otp_codes USING btree (user_id);


--
-- Name: idx_otp_templates_default; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_otp_templates_default ON auth.otp_templates USING btree (tenant_id, is_default) WHERE (is_default = true);


--
-- Name: idx_otp_templates_tenant_channel; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_otp_templates_tenant_channel ON auth.otp_templates USING btree (tenant_id, channel);


--
-- Name: idx_password_history_user_created; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_password_history_user_created ON auth.password_history USING btree (user_id, created_at DESC);


--
-- Name: idx_permissions_resource; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_permissions_resource ON auth.permissions USING btree (resource);


--
-- Name: idx_permissions_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_permissions_tenant ON auth.permissions USING btree (tenant_id);


--
-- Name: idx_rate_limit_blocked; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_rate_limit_blocked ON auth.rate_limit_violations USING btree (blocked_until) WHERE (blocked_until IS NOT NULL);


--
-- Name: idx_rate_limit_identifier; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_rate_limit_identifier ON auth.rate_limit_violations USING btree (identifier);


--
-- Name: idx_rate_limit_window; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_rate_limit_window ON auth.rate_limit_violations USING btree (window_start);


--
-- Name: idx_rate_limits_identifier; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_rate_limits_identifier ON auth.rate_limits USING btree (identifier, window_start);


--
-- Name: idx_risk_assessments_created; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_risk_assessments_created ON auth.risk_assessments USING btree (created_at DESC);


--
-- Name: idx_risk_assessments_level; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_risk_assessments_level ON auth.risk_assessments USING btree (level);


--
-- Name: idx_risk_assessments_score; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_risk_assessments_score ON auth.risk_assessments USING btree (score);


--
-- Name: idx_risk_assessments_session; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_risk_assessments_session ON auth.risk_assessments USING btree (session_id);


--
-- Name: idx_risk_assessments_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_risk_assessments_user ON auth.risk_assessments USING btree (user_id);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_role_permissions_permission ON auth.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_role_permissions_role ON auth.role_permissions USING btree (role_id);


--
-- Name: idx_roles_parent; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_roles_parent ON auth.roles USING btree (parent_role_id);


--
-- Name: idx_roles_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_roles_tenant ON auth.roles USING btree (tenant_id);


--
-- Name: idx_security_events_created; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_created ON auth.security_events USING btree (created_at DESC);


--
-- Name: idx_security_events_ip; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_ip ON auth.security_events USING btree (ip_address);


--
-- Name: idx_security_events_resolved; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_resolved ON auth.security_events USING btree (resolved) WHERE (NOT resolved);


--
-- Name: idx_security_events_severity; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_severity ON auth.security_events USING btree (severity);


--
-- Name: idx_security_events_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_type ON auth.security_events USING btree (event_type);


--
-- Name: idx_security_events_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_events_user ON auth.security_events USING btree (user_id);


--
-- Name: idx_security_questions_last_used; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_questions_last_used ON auth.security_questions USING btree (last_used_at);


--
-- Name: idx_security_questions_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_security_questions_user_id ON auth.security_questions USING btree (user_id);


--
-- Name: idx_sessions_expires; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_sessions_expires ON auth.sessions USING btree (expires_at);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_sessions_token ON auth.sessions USING btree (session_token);


--
-- Name: idx_sessions_user_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_sessions_user_id ON auth.sessions USING btree (user_id);


--
-- Name: idx_tenant_settings_created_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_tenant_settings_created_at ON auth.tenant_settings USING btree (created_at);


--
-- Name: idx_tenant_settings_updated_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_tenant_settings_updated_at ON auth.tenant_settings USING btree (updated_at);


--
-- Name: idx_traffic_patterns_detected; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_traffic_patterns_detected ON auth.traffic_patterns USING btree (detected_at DESC);


--
-- Name: idx_traffic_patterns_ip; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_traffic_patterns_ip ON auth.traffic_patterns USING btree (ip_address);


--
-- Name: idx_traffic_patterns_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_traffic_patterns_type ON auth.traffic_patterns USING btree (pattern_type);


--
-- Name: idx_user_risk_profiles_monitoring; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_risk_profiles_monitoring ON auth.user_risk_profiles USING btree (requires_enhanced_monitoring) WHERE (requires_enhanced_monitoring = true);


--
-- Name: idx_user_risk_profiles_score; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_risk_profiles_score ON auth.user_risk_profiles USING btree (current_score);


--
-- Name: idx_user_risk_profiles_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_risk_profiles_user ON auth.user_risk_profiles USING btree (user_id);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_roles_role ON auth.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_roles_tenant ON auth.user_roles USING btree (tenant_id);


--
-- Name: idx_user_roles_user; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_roles_user ON auth.user_roles USING btree (user_id);


--
-- Name: idx_user_roles_valid; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_user_roles_valid ON auth.user_roles USING btree (valid_from, valid_until);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_created_at ON auth.users USING btree (created_at);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_deleted_at ON auth.users USING btree (deleted_at);


--
-- Name: idx_users_deletion_requested_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_deletion_requested_at ON auth.users USING btree (deletion_requested_at);


--
-- Name: idx_users_disabled_at; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_disabled_at ON auth.users USING btree (disabled_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_users_external_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_external_id ON auth.users USING btree (external_id) WHERE (external_id IS NOT NULL);


--
-- Name: idx_users_purge_after; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_purge_after ON auth.users USING btree (purge_after);


--
-- Name: idx_users_status; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_status ON auth.users USING btree (status);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_users_tenant_id ON auth.users USING btree (tenant_id);


--
-- Name: idx_velocity_tracking_exceeded; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_velocity_tracking_exceeded ON auth.velocity_tracking USING btree (exceeded) WHERE (exceeded = true);


--
-- Name: idx_velocity_tracking_identifier; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_velocity_tracking_identifier ON auth.velocity_tracking USING btree (identifier);


--
-- Name: idx_velocity_tracking_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_velocity_tracking_type ON auth.velocity_tracking USING btree (action_type);


--
-- Name: idx_velocity_tracking_window; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_velocity_tracking_window ON auth.velocity_tracking USING btree (window_start);


--
-- Name: idx_webhook_delivery_logs_attempted; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_attempted ON auth.webhook_delivery_logs USING btree (attempted_at DESC);


--
-- Name: idx_webhook_delivery_logs_endpoint; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_endpoint ON auth.webhook_delivery_logs USING btree (endpoint_id);


--
-- Name: idx_webhook_delivery_logs_event; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_event ON auth.webhook_delivery_logs USING btree (event_id);


--
-- Name: idx_webhook_delivery_logs_success; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_success ON auth.webhook_delivery_logs USING btree (success);


--
-- Name: idx_webhook_endpoints_enabled; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_endpoints_enabled ON auth.webhook_endpoints USING btree (enabled);


--
-- Name: idx_webhook_endpoints_events; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_endpoints_events ON auth.webhook_endpoints USING gin (events);


--
-- Name: idx_webhook_endpoints_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_endpoints_tenant ON auth.webhook_endpoints USING btree (tenant_id);


--
-- Name: idx_webhook_events_created; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_created ON auth.webhook_events USING btree (created_at DESC);


--
-- Name: idx_webhook_events_processed; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_processed ON auth.webhook_events USING btree (processed);


--
-- Name: idx_webhook_events_tenant; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_tenant ON auth.webhook_events USING btree (tenant_id);


--
-- Name: idx_webhook_events_type; Type: INDEX; Schema: auth; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_type ON auth.webhook_events USING btree (event_type);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_event_category; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_event_category ON public.audit_logs USING btree (event_category);


--
-- Name: idx_audit_logs_event_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_event_type ON public.audit_logs USING btree (event_type);


--
-- Name: idx_audit_logs_risk_score; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_risk_score ON public.audit_logs USING btree (risk_score) WHERE (risk_score > 50);


--
-- Name: idx_audit_logs_session_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_session_id ON public.audit_logs USING btree (session_id);


--
-- Name: idx_audit_logs_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_status ON public.audit_logs USING btree (status);


--
-- Name: idx_audit_logs_tenant_event; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_tenant_event ON public.audit_logs USING btree (tenant_id, event_type, created_at DESC);


--
-- Name: idx_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_tenant_id ON public.audit_logs USING btree (tenant_id);


--
-- Name: idx_audit_logs_tenant_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_tenant_user ON public.audit_logs USING btree (tenant_id, user_id, created_at DESC);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_behavioral_biometric_profiles_enrollment; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_behavioral_biometric_profiles_enrollment ON public.behavioral_biometric_profiles USING btree (enrollment_id);


--
-- Name: idx_behavioral_biometric_profiles_session; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_behavioral_biometric_profiles_session ON public.behavioral_biometric_profiles USING btree (session_id);


--
-- Name: idx_biometric_challenges_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_challenges_expires ON public.biometric_challenges USING btree (expires_at);


--
-- Name: idx_biometric_challenges_user_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_challenges_user_tenant ON public.biometric_challenges USING btree (user_id, tenant_id);


--
-- Name: idx_biometric_enrollments_last_used; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_enrollments_last_used ON public.biometric_enrollments USING btree (last_used_at);


--
-- Name: idx_biometric_enrollments_type_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_enrollments_type_status ON public.biometric_enrollments USING btree (type, status);


--
-- Name: idx_biometric_enrollments_user_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_enrollments_user_tenant ON public.biometric_enrollments USING btree (user_id, tenant_id);


--
-- Name: idx_biometric_verification_logs_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_verification_logs_created ON public.biometric_verification_logs USING btree (created_at);


--
-- Name: idx_biometric_verification_logs_enrollment; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_biometric_verification_logs_enrollment ON public.biometric_verification_logs USING btree (enrollment_id);


--
-- Name: idx_compliance_proofs_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_proofs_expires ON public.zk_compliance_proofs USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_compliance_proofs_jurisdiction; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_proofs_jurisdiction ON public.zk_compliance_proofs USING btree (jurisdiction);


--
-- Name: idx_compliance_proofs_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_proofs_status ON public.zk_compliance_proofs USING btree (verification_status);


--
-- Name: idx_compliance_proofs_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_proofs_wallet ON public.zk_compliance_proofs USING btree (wallet_id);


--
-- Name: idx_custodian_assignments_custodian; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodian_assignments_custodian ON public.custodian_assignments USING btree (custodian_id);


--
-- Name: idx_custodian_assignments_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodian_assignments_status ON public.custodian_assignments USING btree (status);


--
-- Name: idx_custodian_assignments_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodian_assignments_user ON public.custodian_assignments USING btree (user_id);


--
-- Name: idx_custodian_responses_custodian; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodian_responses_custodian ON public.custodian_responses USING btree (custodian_id);


--
-- Name: idx_custodian_responses_request; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodian_responses_request ON public.custodian_responses USING btree (recovery_request_id);


--
-- Name: idx_custodians_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodians_email ON public.custodians USING btree (email);


--
-- Name: idx_custodians_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodians_status ON public.custodians USING btree (status);


--
-- Name: idx_custodians_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodians_tenant ON public.custodians USING btree (tenant_id);


--
-- Name: idx_custodians_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custodians_type ON public.custodians USING btree (type);


--
-- Name: idx_email_verification_tokens_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_email_verification_tokens_token ON public.email_verification_tokens USING btree (token);


--
-- Name: idx_invoice_wallets_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_created_at ON public.invoice_wallets USING btree (created_at);


--
-- Name: idx_invoice_wallets_expires_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_expires_at ON public.invoice_wallets USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_invoice_wallets_mode; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_mode ON public.invoice_wallets USING btree (mode);


--
-- Name: idx_invoice_wallets_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_status ON public.invoice_wallets USING btree (status);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_invoice_number; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status);


--
-- Name: idx_invoices_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_type ON public.invoices USING btree (type);


--
-- Name: idx_invoices_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_user_id ON public.invoices USING btree (user_id);


--
-- Name: idx_magic_links_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_email ON public.magic_links USING btree (email);


--
-- Name: idx_magic_links_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_expires ON public.magic_links USING btree (expires_at);


--
-- Name: idx_magic_links_tenant_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_tenant_email ON public.magic_links USING btree (tenant_id, email);


--
-- Name: idx_magic_links_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_token ON public.magic_links USING btree (token);


--
-- Name: idx_mode_decisions_ai_score; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_ai_score ON public.wallet_mode_decisions USING btree (ai_score);


--
-- Name: idx_mode_decisions_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_created ON public.wallet_mode_decisions USING btree (created_at);


--
-- Name: idx_mode_decisions_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_invoice ON public.wallet_mode_decisions USING btree (invoice_id);


--
-- Name: idx_mode_decisions_mode; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_mode ON public.wallet_mode_decisions USING btree (selected_mode);


--
-- Name: idx_nudge_credit_tracking_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_credit_tracking_tenant ON public.nudge_credit_tracking USING btree (tenant_id);


--
-- Name: idx_nudge_delivery_logs_message; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_delivery_logs_message ON public.nudge_delivery_logs USING btree (message_id);


--
-- Name: idx_nudge_delivery_logs_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_delivery_logs_status ON public.nudge_delivery_logs USING btree (status);


--
-- Name: idx_nudge_delivery_logs_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_delivery_logs_tenant ON public.nudge_delivery_logs USING btree (tenant_id);


--
-- Name: idx_nudge_delivery_logs_verification; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_delivery_logs_verification ON public.nudge_delivery_logs USING btree (verification_id);


--
-- Name: idx_nudge_notification_logs_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_notification_logs_status ON public.nudge_notification_logs USING btree (status);


--
-- Name: idx_nudge_notification_logs_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_notification_logs_tenant ON public.nudge_notification_logs USING btree (tenant_id);


--
-- Name: idx_nudge_notification_logs_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_notification_logs_user ON public.nudge_notification_logs USING btree (user_id);


--
-- Name: idx_nudge_templates_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_active ON public.nudge_templates USING btree (active);


--
-- Name: idx_nudge_templates_channel_purpose; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_channel_purpose ON public.nudge_templates USING btree (channel, purpose);


--
-- Name: idx_nudge_templates_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_nudge_templates_tenant ON public.nudge_templates USING btree (tenant_id);


--
-- Name: idx_oauth_states_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_oauth_states_expires ON public.oauth_states USING btree (expires_at);


--
-- Name: idx_oauth_states_state; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_oauth_states_state ON public.oauth_states USING btree (state);


--
-- Name: idx_otp_codes_code; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_code ON public.otp_codes USING btree (code);


--
-- Name: idx_otp_codes_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_expires ON public.otp_codes USING btree (expires_at);


--
-- Name: idx_otp_codes_identifier; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_identifier ON public.otp_codes USING btree (identifier, identifier_type);


--
-- Name: idx_otp_codes_tenant_identifier; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_codes_tenant_identifier ON public.otp_codes USING btree (tenant_id, identifier);


--
-- Name: idx_otp_verifications_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_verifications_expires ON public.otp_verifications USING btree (expires_at);


--
-- Name: idx_otp_verifications_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_verifications_recipient ON public.otp_verifications USING btree (recipient);


--
-- Name: idx_otp_verifications_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_verifications_tenant ON public.otp_verifications USING btree (tenant_id);


--
-- Name: idx_otp_verifications_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_verifications_user ON public.otp_verifications USING btree (user_id);


--
-- Name: idx_otp_verifications_verified; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_otp_verifications_verified ON public.otp_verifications USING btree (verified);


--
-- Name: idx_password_reset_tokens_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_password_reset_tokens_expires ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: idx_password_reset_tokens_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_password_reset_tokens_token ON public.password_reset_tokens USING btree (token);


--
-- Name: idx_password_reset_tokens_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_password_reset_tokens_user ON public.password_reset_tokens USING btree (user_id);


--
-- Name: idx_passwordless_sessions_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_passwordless_sessions_expires ON public.passwordless_sessions USING btree (expires_at);


--
-- Name: idx_passwordless_sessions_state; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_passwordless_sessions_state ON public.passwordless_sessions USING btree (state);


--
-- Name: idx_passwordless_sessions_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_passwordless_sessions_token ON public.passwordless_sessions USING btree (session_token);


--
-- Name: idx_passwordless_sessions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_passwordless_sessions_user ON public.passwordless_sessions USING btree (user_id);


--
-- Name: idx_permissions_resource; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_permissions_resource ON public.permissions USING btree (resource);


--
-- Name: idx_permissions_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_permissions_tenant ON public.permissions USING btree (tenant_id);


--
-- Name: idx_quantum_keys_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_quantum_keys_active ON public.quantum_key_registry USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_quantum_keys_wallet_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_quantum_keys_wallet_id ON public.quantum_key_registry USING btree (wallet_id);


--
-- Name: idx_recovery_requests_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recovery_requests_expires ON public.recovery_requests USING btree (expires_at);


--
-- Name: idx_recovery_requests_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recovery_requests_status ON public.recovery_requests USING btree (status);


--
-- Name: idx_recovery_requests_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recovery_requests_user ON public.recovery_requests USING btree (user_id);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_roles_parent; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_roles_parent ON public.roles USING btree (parent_role_id);


--
-- Name: idx_roles_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_roles_tenant ON public.roles USING btree (tenant_id);


--
-- Name: idx_social_accounts_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_accounts_email ON public.social_accounts USING btree (email);


--
-- Name: idx_social_accounts_provider; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_accounts_provider ON public.social_accounts USING btree (provider, provider_user_id);


--
-- Name: idx_social_accounts_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_accounts_user ON public.social_accounts USING btree (user_id);


--
-- Name: idx_social_auth_logs_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_auth_logs_created ON public.social_auth_logs USING btree (created_at);


--
-- Name: idx_social_auth_logs_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_auth_logs_user ON public.social_auth_logs USING btree (user_id);


--
-- Name: idx_social_providers_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_social_providers_tenant ON public.social_providers USING btree (tenant_id);


--
-- Name: idx_user_roles_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_roles_expires ON public.user_roles USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_roles_role ON public.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_roles_tenant ON public.user_roles USING btree (tenant_id);


--
-- Name: idx_user_roles_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_roles_user ON public.user_roles USING btree (user_id);


--
-- Name: idx_voice_biometric_profiles_enrollment; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_voice_biometric_profiles_enrollment ON public.voice_biometric_profiles USING btree (enrollment_id);


--
-- Name: idx_wallet_events_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_timestamp ON public.wallet_lifecycle_events USING btree ("timestamp");


--
-- Name: idx_wallet_events_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_type ON public.wallet_lifecycle_events USING btree (event_type);


--
-- Name: idx_wallet_events_wallet_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_wallet_id ON public.wallet_lifecycle_events USING btree (wallet_id);


--
-- Name: idx_webhook_delivery_logs_attempted; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_attempted ON public.webhook_delivery_logs USING btree (attempted_at DESC);


--
-- Name: idx_webhook_delivery_logs_endpoint; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_endpoint ON public.webhook_delivery_logs USING btree (endpoint_id);


--
-- Name: idx_webhook_delivery_logs_event; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_delivery_logs_event ON public.webhook_delivery_logs USING btree (event_id);


--
-- Name: idx_webhook_endpoints_enabled; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_endpoints_enabled ON public.webhook_endpoints USING btree (enabled);


--
-- Name: idx_webhook_endpoints_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_endpoints_tenant ON public.webhook_endpoints USING btree (tenant_id);


--
-- Name: idx_webhook_events_endpoint; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_endpoint ON public.webhook_events USING btree (endpoint_id);


--
-- Name: idx_webhook_events_event_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_event_id ON public.webhook_events USING btree (event_id);


--
-- Name: idx_webhook_events_scheduled; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_scheduled ON public.webhook_events USING btree (scheduled_for);


--
-- Name: idx_webhook_events_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_status ON public.webhook_events USING btree (status);


--
-- Name: idx_webhook_events_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webhook_events_tenant ON public.webhook_events USING btree (tenant_id);


--
-- Name: applications update_applications_updated_at; Type: TRIGGER; Schema: auth; Owner: alisaberi
--

CREATE TRIGGER update_applications_updated_at BEFORE UPDATE ON auth.applications FOR EACH ROW EXECUTE FUNCTION auth.update_updated_at();


--
-- Name: otp_templates update_otp_templates_timestamp; Type: TRIGGER; Schema: auth; Owner: alisaberi
--

CREATE TRIGGER update_otp_templates_timestamp BEFORE UPDATE ON auth.otp_templates FOR EACH ROW EXECUTE FUNCTION public.update_otp_templates_updated_at();


--
-- Name: tenant_settings update_tenant_settings_updated_at; Type: TRIGGER; Schema: auth; Owner: alisaberi
--

CREATE TRIGGER update_tenant_settings_updated_at BEFORE UPDATE ON auth.tenant_settings FOR EACH ROW EXECUTE FUNCTION auth.update_tenant_settings_updated_at();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: auth; Owner: alisaberi
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON auth.tenants FOR EACH ROW EXECUTE FUNCTION auth.update_updated_at();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: auth; Owner: alisaberi
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON auth.users FOR EACH ROW EXECUTE FUNCTION auth.update_updated_at();


--
-- Name: audit_logs audit_logs_risk_score_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER audit_logs_risk_score_trigger BEFORE INSERT ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.calculate_audit_risk_score();


--
-- Name: invoice_wallets update_invoice_wallets_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_invoice_wallets_updated_at BEFORE UPDATE ON public.invoice_wallets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices update_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_invoice_updated_at();


--
-- Name: account_recovery_requests account_recovery_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.account_recovery_requests
    ADD CONSTRAINT account_recovery_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: account_recovery_requests account_recovery_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.account_recovery_requests
    ADD CONSTRAINT account_recovery_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: anomaly_detections anomaly_detections_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.anomaly_detections
    ADD CONSTRAINT anomaly_detections_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: api_key_templates api_key_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_key_templates
    ADD CONSTRAINT api_key_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_application_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_keys
    ADD CONSTRAINT api_keys_application_id_fkey FOREIGN KEY (application_id) REFERENCES auth.applications(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: applications applications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.applications
    ADD CONSTRAINT applications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_device_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.audit_logs
    ADD CONSTRAINT audit_logs_device_id_fkey FOREIGN KEY (device_id) REFERENCES auth.devices(id) ON DELETE SET NULL;


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: communication_templates communication_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.communication_templates
    ADD CONSTRAINT communication_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: deletion_audit deletion_audit_performed_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.deletion_audit
    ADD CONSTRAINT deletion_audit_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES auth.users(id);


--
-- Name: deletion_audit deletion_audit_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.deletion_audit
    ADD CONSTRAINT deletion_audit_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: device_fingerprints device_fingerprints_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.device_fingerprints
    ADD CONSTRAINT device_fingerprints_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: email_queue email_queue_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.email_queue
    ADD CONSTRAINT email_queue_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: ip_blacklist ip_blacklist_blocked_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_blacklist
    ADD CONSTRAINT ip_blacklist_blocked_by_fkey FOREIGN KEY (blocked_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: ip_blacklist ip_blacklist_unblocked_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_blacklist
    ADD CONSTRAINT ip_blacklist_unblocked_by_fkey FOREIGN KEY (unblocked_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: ip_whitelist ip_whitelist_added_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.ip_whitelist
    ADD CONSTRAINT ip_whitelist_added_by_fkey FOREIGN KEY (added_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: mfa_configs mfa_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.mfa_configs
    ADD CONSTRAINT mfa_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: nudge_delivery_logs nudge_delivery_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_delivery_logs
    ADD CONSTRAINT nudge_delivery_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: nudge_otp_logs nudge_otp_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_otp_logs
    ADD CONSTRAINT nudge_otp_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: nudge_templates nudge_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.nudge_templates
    ADD CONSTRAINT nudge_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: otp_codes otp_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_codes
    ADD CONSTRAINT otp_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: otp_templates otp_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.otp_templates
    ADD CONSTRAINT otp_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: password_history password_history_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.password_history
    ADD CONSTRAINT password_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: password_policies password_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.password_policies
    ADD CONSTRAINT password_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: permissions permissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.permissions
    ADD CONSTRAINT permissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: risk_assessments risk_assessments_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.risk_assessments
    ADD CONSTRAINT risk_assessments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: risk_scores risk_scores_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.risk_scores
    ADD CONSTRAINT risk_scores_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- Name: risk_scores risk_scores_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.risk_scores
    ADD CONSTRAINT risk_scores_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.role_permissions
    ADD CONSTRAINT role_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES auth.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES auth.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.roles
    ADD CONSTRAINT roles_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES auth.roles(id) ON DELETE SET NULL;


--
-- Name: roles roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.roles
    ADD CONSTRAINT roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_resolved_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_events
    ADD CONSTRAINT security_events_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: security_questions security_questions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.security_questions
    ADD CONSTRAINT security_questions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_application_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_application_id_fkey FOREIGN KEY (application_id) REFERENCES auth.applications(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: sso_providers sso_providers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_created_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenant_settings
    ADD CONSTRAINT tenant_settings_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.tenant_settings
    ADD CONSTRAINT tenant_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES auth.users(id);


--
-- Name: user_risk_profiles user_risk_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_risk_profiles
    ADD CONSTRAINT user_risk_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_assigned_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT user_roles_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES auth.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES auth.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT user_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_sso_connections user_sso_connections_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- Name: user_sso_connections user_sso_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.user_sso_connections
    ADD CONSTRAINT user_sso_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users users_deletion_requested_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_deletion_requested_by_fkey FOREIGN KEY (deletion_requested_by) REFERENCES auth.users(id);


--
-- Name: users users_disabled_by_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_disabled_by_fkey FOREIGN KEY (disabled_by) REFERENCES auth.users(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: webhook_delivery_logs webhook_delivery_logs_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES auth.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_delivery_logs webhook_delivery_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES auth.webhook_events(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: alisaberi
--

ALTER TABLE ONLY auth.webhook_events
    ADD CONSTRAINT webhook_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: behavioral_biometric_profiles behavioral_biometric_profiles_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.behavioral_biometric_profiles
    ADD CONSTRAINT behavioral_biometric_profiles_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.biometric_enrollments(id) ON DELETE CASCADE;


--
-- Name: behavioral_biometric_profiles behavioral_biometric_profiles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.behavioral_biometric_profiles
    ADD CONSTRAINT behavioral_biometric_profiles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: behavioral_biometric_profiles behavioral_biometric_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.behavioral_biometric_profiles
    ADD CONSTRAINT behavioral_biometric_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: biometric_challenges biometric_challenges_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_challenges
    ADD CONSTRAINT biometric_challenges_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: biometric_challenges biometric_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_challenges
    ADD CONSTRAINT biometric_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: biometric_enrollments biometric_enrollments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_enrollments
    ADD CONSTRAINT biometric_enrollments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: biometric_enrollments biometric_enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_enrollments
    ADD CONSTRAINT biometric_enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: biometric_verification_logs biometric_verification_logs_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_verification_logs
    ADD CONSTRAINT biometric_verification_logs_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.biometric_enrollments(id) ON DELETE CASCADE;


--
-- Name: biometric_verification_logs biometric_verification_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_verification_logs
    ADD CONSTRAINT biometric_verification_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: biometric_verification_logs biometric_verification_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.biometric_verification_logs
    ADD CONSTRAINT biometric_verification_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: custodian_assignments custodian_assignments_custodian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_assignments
    ADD CONSTRAINT custodian_assignments_custodian_id_fkey FOREIGN KEY (custodian_id) REFERENCES public.custodians(id) ON DELETE CASCADE;


--
-- Name: custodian_assignments custodian_assignments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_assignments
    ADD CONSTRAINT custodian_assignments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: custodian_assignments custodian_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_assignments
    ADD CONSTRAINT custodian_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: custodian_responses custodian_responses_custodian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_responses
    ADD CONSTRAINT custodian_responses_custodian_id_fkey FOREIGN KEY (custodian_id) REFERENCES public.custodians(id) ON DELETE CASCADE;


--
-- Name: custodian_responses custodian_responses_recovery_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_responses
    ADD CONSTRAINT custodian_responses_recovery_request_id_fkey FOREIGN KEY (recovery_request_id) REFERENCES public.recovery_requests(id) ON DELETE CASCADE;


--
-- Name: custodian_verification_sessions custodian_verification_sessions_custodian_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_verification_sessions
    ADD CONSTRAINT custodian_verification_sessions_custodian_id_fkey FOREIGN KEY (custodian_id) REFERENCES public.custodians(id) ON DELETE CASCADE;


--
-- Name: custodian_verification_sessions custodian_verification_sessions_recovery_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodian_verification_sessions
    ADD CONSTRAINT custodian_verification_sessions_recovery_request_id_fkey FOREIGN KEY (recovery_request_id) REFERENCES public.recovery_requests(id) ON DELETE CASCADE;


--
-- Name: custodians custodians_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodians
    ADD CONSTRAINT custodians_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: custodians custodians_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custodians
    ADD CONSTRAINT custodians_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: email_queue email_queue_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_queue
    ADD CONSTRAINT email_queue_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs fk_audit_logs_user_id; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: invoice_wallets invoice_wallets_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: magic_links magic_links_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: magic_links magic_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: nudge_credit_tracking nudge_credit_tracking_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_credit_tracking
    ADD CONSTRAINT nudge_credit_tracking_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: nudge_delivery_logs nudge_delivery_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_delivery_logs
    ADD CONSTRAINT nudge_delivery_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: nudge_delivery_logs nudge_delivery_logs_verification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_delivery_logs
    ADD CONSTRAINT nudge_delivery_logs_verification_id_fkey FOREIGN KEY (verification_id) REFERENCES public.otp_verifications(id) ON DELETE CASCADE;


--
-- Name: nudge_notification_logs nudge_notification_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_notification_logs
    ADD CONSTRAINT nudge_notification_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: nudge_notification_logs nudge_notification_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_notification_logs
    ADD CONSTRAINT nudge_notification_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: nudge_templates nudge_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.nudge_templates
    ADD CONSTRAINT nudge_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: oauth_states oauth_states_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.oauth_states
    ADD CONSTRAINT oauth_states_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: otp_codes otp_codes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: otp_codes otp_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT otp_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: otp_verifications otp_verifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: otp_verifications otp_verifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: passwordless_sessions passwordless_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.passwordless_sessions
    ADD CONSTRAINT passwordless_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: passwordless_sessions passwordless_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.passwordless_sessions
    ADD CONSTRAINT passwordless_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: permissions permissions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: quantum_key_registry quantum_key_registry_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id) ON DELETE CASCADE;


--
-- Name: recovery_requests recovery_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recovery_requests
    ADD CONSTRAINT recovery_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: recovery_requests recovery_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recovery_requests
    ADD CONSTRAINT recovery_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: roles roles_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: roles roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: social_accounts social_accounts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: social_accounts social_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_accounts
    ADD CONSTRAINT social_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: social_auth_logs social_auth_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_auth_logs
    ADD CONSTRAINT social_auth_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: social_auth_logs social_auth_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_auth_logs
    ADD CONSTRAINT social_auth_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: social_providers social_providers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.social_providers
    ADD CONSTRAINT social_providers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: voice_biometric_profiles voice_biometric_profiles_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.voice_biometric_profiles
    ADD CONSTRAINT voice_biometric_profiles_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.biometric_enrollments(id) ON DELETE CASCADE;


--
-- Name: voice_biometric_profiles voice_biometric_profiles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.voice_biometric_profiles
    ADD CONSTRAINT voice_biometric_profiles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: voice_biometric_profiles voice_biometric_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.voice_biometric_profiles
    ADD CONSTRAINT voice_biometric_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id) ON DELETE CASCADE;


--
-- Name: webhook_delivery_logs webhook_delivery_logs_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_delivery_logs webhook_delivery_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_delivery_logs
    ADD CONSTRAINT webhook_delivery_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.webhook_events(id) ON DELETE CASCADE;


--
-- Name: webhook_endpoints webhook_endpoints_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_endpoints
    ADD CONSTRAINT webhook_endpoints_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.webhook_endpoints(id) ON DELETE CASCADE;


--
-- Name: webhook_events webhook_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES auth.tenants(id) ON DELETE CASCADE;


--
-- Name: zk_compliance_proofs zk_compliance_proofs_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id) ON DELETE CASCADE;


--
-- Name: api_keys; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: applications; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.applications ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: devices; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.devices ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: alisaberi
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: custodian_assignments assignments_tenant_isolation; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY assignments_tenant_isolation ON public.custodian_assignments USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY audit_logs_tenant_isolation ON public.audit_logs USING (((tenant_id)::text = ((current_setting('app.tenant_id'::text, true))::character varying)::text));


--
-- Name: audit_logs audit_logs_user_read; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY audit_logs_user_read ON public.audit_logs FOR SELECT USING (((user_id = (current_setting('app.user_id'::text, true))::uuid) OR ((current_setting('app.is_admin'::text, true))::boolean = true)));


--
-- Name: behavioral_biometric_profiles; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.behavioral_biometric_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: biometric_challenges; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.biometric_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: biometric_enrollments; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.biometric_enrollments ENABLE ROW LEVEL SECURITY;

--
-- Name: biometric_verification_logs; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.biometric_verification_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: custodian_assignments; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.custodian_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: custodian_responses; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.custodian_responses ENABLE ROW LEVEL SECURITY;

--
-- Name: custodian_verification_sessions; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.custodian_verification_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: custodians; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.custodians ENABLE ROW LEVEL SECURITY;

--
-- Name: custodians custodians_tenant_isolation; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY custodians_tenant_isolation ON public.custodians USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: oauth_states; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.oauth_states ENABLE ROW LEVEL SECURITY;

--
-- Name: recovery_requests; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.recovery_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: recovery_requests requests_tenant_isolation; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY requests_tenant_isolation ON public.recovery_requests USING ((tenant_id = (current_setting('app.tenant_id'::text, true))::uuid));


--
-- Name: social_accounts; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.social_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: social_auth_logs; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.social_auth_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: social_providers; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.social_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: biometric_enrollments tenant_isolation_biometric_enrollments; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_biometric_enrollments ON public.biometric_enrollments USING ((tenant_id = (current_setting('app.current_tenant'::text))::uuid));


--
-- Name: oauth_states tenant_isolation_oauth_states; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_oauth_states ON public.oauth_states USING ((tenant_id = (current_setting('app.current_tenant'::text))::uuid));


--
-- Name: social_accounts tenant_isolation_social_accounts; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_social_accounts ON public.social_accounts USING ((tenant_id = (current_setting('app.current_tenant'::text))::uuid));


--
-- Name: social_auth_logs tenant_isolation_social_auth_logs; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_social_auth_logs ON public.social_auth_logs USING ((tenant_id = (current_setting('app.current_tenant'::text))::uuid));


--
-- Name: social_providers tenant_isolation_social_providers; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_social_providers ON public.social_providers USING ((tenant_id = (current_setting('app.current_tenant'::text))::uuid));


--
-- Name: voice_biometric_profiles; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.voice_biometric_profiles ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict JCdsKm7Spy8Yc6FkjIlGyLd53f5dc39GvsKPVlYaouJXYOMutRd6dKVbXTmPoEl

