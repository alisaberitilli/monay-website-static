--
-- PostgreSQL database dump
--

\restrict 1AKhmaxtcgm3vzNvsOR7g0JZMQ2LiTeAjTnp9EuTDSzPSQhjsU6Kgek045EOSHi

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: attestation_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.attestation_type AS ENUM (
    'identity',
    'compliance',
    'transfer',
    'cross_rail',
    'batch_operation'
);


ALTER TYPE public.attestation_type OWNER TO alisaberi;

--
-- Name: auth_level; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.auth_level AS ENUM (
    'basic',
    'verified',
    'mfa_required',
    'biometric_required',
    'high_security'
);


ALTER TYPE public.auth_level OWNER TO alisaberi;

--
-- Name: auth_method; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.auth_method AS ENUM (
    'password',
    'biometric',
    'mfa_totp',
    'mfa_sms',
    'mfa_email',
    'webauthn',
    'magic_link',
    'sso',
    'api_key'
);


ALTER TYPE public.auth_method OWNER TO alisaberi;

--
-- Name: biometric_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.biometric_type AS ENUM (
    'face_id',
    'touch_id',
    'fingerprint',
    'iris',
    'voice'
);


ALTER TYPE public.biometric_type OWNER TO alisaberi;

--
-- Name: blockchain_network; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.blockchain_network AS ENUM (
    'base_mainnet',
    'base_testnet',
    'polygon_zkevm_mainnet',
    'polygon_zkevm_testnet',
    'solana_mainnet',
    'solana_devnet'
);


ALTER TYPE public.blockchain_network OWNER TO alisaberi;

--
-- Name: card_network; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.card_network AS ENUM (
    'visa',
    'mastercard',
    'amex',
    'discover'
);


ALTER TYPE public.card_network OWNER TO alisaberi;

--
-- Name: card_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.card_type AS ENUM (
    'physical',
    'virtual'
);


ALTER TYPE public.card_type OWNER TO alisaberi;

--
-- Name: claim_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.claim_status AS ENUM (
    'pending',
    'verified',
    'rejected',
    'expired',
    'revoked'
);


ALTER TYPE public.claim_status OWNER TO alisaberi;

--
-- Name: claim_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.claim_type AS ENUM (
    'kyc_verified',
    'aml_cleared',
    'accredited_investor',
    'qualified_purchaser',
    'institutional',
    'geographic_restriction',
    'age_verification',
    'source_of_funds'
);


ALTER TYPE public.claim_type OWNER TO alisaberi;

--
-- Name: crypto_asset_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.crypto_asset_type AS ENUM (
    'stablecoin',
    'volatile',
    'cbdc',
    'wrapped',
    'synthetic',
    'governance',
    'utility',
    'security',
    'commodity'
);


ALTER TYPE public.crypto_asset_type OWNER TO alisaberi;

--
-- Name: custody_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.custody_type AS ENUM (
    'self',
    'hybrid',
    'managed',
    'institutional'
);


ALTER TYPE public.custody_type OWNER TO alisaberi;

--
-- Name: device_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.device_type AS ENUM (
    'WEB',
    'DESKTOP',
    'IOS',
    'ANDROID'
);


ALTER TYPE public.device_type OWNER TO alisaberi;

--
-- Name: kyc_provider; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.kyc_provider AS ENUM (
    'persona',
    'alloy',
    'onfido',
    'internal'
);


ALTER TYPE public.kyc_provider OWNER TO alisaberi;

--
-- Name: kyc_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.kyc_status AS ENUM (
    'not_started',
    'pending',
    'in_review',
    'approved',
    'rejected',
    'expired'
);


ALTER TYPE public.kyc_status OWNER TO alisaberi;

--
-- Name: mfa_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.mfa_type AS ENUM (
    'totp',
    'sms',
    'email',
    'webauthn',
    'backup_codes',
    'push'
);


ALTER TYPE public.mfa_type OWNER TO alisaberi;

--
-- Name: multi_sig_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.multi_sig_status AS ENUM (
    'pending',
    'partially_signed',
    'executed',
    'cancelled',
    'expired'
);


ALTER TYPE public.multi_sig_status OWNER TO alisaberi;

--
-- Name: oracle_source; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.oracle_source AS ENUM (
    'chainlink',
    'pyth',
    'band_protocol',
    'dia',
    'uma',
    'api3',
    'tellor',
    'redstone',
    'flux',
    'umbrella',
    'internal'
);


ALTER TYPE public.oracle_source OWNER TO alisaberi;

--
-- Name: org_feature_tier; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_feature_tier AS ENUM (
    'basic',
    'standard',
    'premium',
    'enterprise'
);


ALTER TYPE public.org_feature_tier OWNER TO alisaberi;

--
-- Name: org_user_role; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_user_role AS ENUM (
    'owner',
    'admin',
    'manager',
    'member',
    'viewer',
    'finance',
    'developer'
);


ALTER TYPE public.org_user_role OWNER TO alisaberi;

--
-- Name: org_wallet_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_wallet_type AS ENUM (
    'consumer',
    'enterprise'
);


ALTER TYPE public.org_wallet_type OWNER TO alisaberi;

--
-- Name: payment_method_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.payment_method_type AS ENUM (
    'card',
    'ach',
    'wire',
    'wallet',
    'crypto_stable',
    'crypto_unstable',
    'bank_account',
    'invoice',
    'crypto_defi',
    'crypto_cbdc'
);


ALTER TYPE public.payment_method_type OWNER TO alisaberi;

--
-- Name: reconciliation_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.reconciliation_status AS ENUM (
    'pending',
    'matched',
    'mismatched',
    'investigating',
    'resolved'
);


ALTER TYPE public.reconciliation_status OWNER TO alisaberi;

--
-- Name: restriction_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.restriction_type AS ENUM (
    'country_based',
    'time_based',
    'amount_based',
    'recipient_based',
    'token_based'
);


ALTER TYPE public.restriction_type OWNER TO alisaberi;

--
-- Name: risk_level; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.risk_level AS ENUM (
    'low',
    'medium',
    'high',
    'critical',
    'blocked'
);


ALTER TYPE public.risk_level OWNER TO alisaberi;

--
-- Name: rule_action; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.rule_action AS ENUM (
    'block',
    'review',
    'approve',
    'notify',
    'report'
);


ALTER TYPE public.rule_action OWNER TO alisaberi;

--
-- Name: rule_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.rule_type AS ENUM (
    'transaction_limit',
    'velocity_limit',
    'kyc_requirement',
    'geographic_restriction',
    'token_restriction',
    'compliance_check'
);


ALTER TYPE public.rule_type OWNER TO alisaberi;

--
-- Name: solana_program_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.solana_program_type AS ENUM (
    'native',
    'spl_token',
    'token_2022',
    'anchor',
    'custom'
);


ALTER TYPE public.solana_program_type OWNER TO alisaberi;

--
-- Name: sso_provider_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.sso_provider_type AS ENUM (
    'oauth2',
    'saml',
    'oidc',
    'custom'
);


ALTER TYPE public.sso_provider_type OWNER TO alisaberi;

--
-- Name: stablecoin_backing; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.stablecoin_backing AS ENUM (
    'fiat_collateralized',
    'crypto_collateralized',
    'algorithmic',
    'commodity_backed',
    'hybrid'
);


ALTER TYPE public.stablecoin_backing OWNER TO alisaberi;

--
-- Name: stablecoin_peg; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.stablecoin_peg AS ENUM (
    'USD',
    'EUR',
    'GBP',
    'JPY',
    'CHF',
    'AUD',
    'CAD',
    'SGD',
    'GOLD',
    'SILVER',
    'BASKET'
);


ALTER TYPE public.stablecoin_peg OWNER TO alisaberi;

--
-- Name: token_extension_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.token_extension_type AS ENUM (
    'transfer_hook',
    'permanent_delegate',
    'transfer_fee',
    'interest_bearing',
    'confidential_transfer',
    'metadata',
    'memo_required'
);


ALTER TYPE public.token_extension_type OWNER TO alisaberi;

--
-- Name: token_standard; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.token_standard AS ENUM (
    'ERC20',
    'ERC3643',
    'TOKEN2022',
    'SPL'
);


ALTER TYPE public.token_standard OWNER TO alisaberi;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.transaction_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'cancelled',
    'reversed'
);


ALTER TYPE public.transaction_status OWNER TO alisaberi;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.transaction_type AS ENUM (
    'deposit',
    'withdrawal',
    'transfer',
    'swap',
    'mint',
    'burn',
    'cross_rail',
    'payment',
    'refund',
    'invoice_payment',
    'crypto_exchange',
    'staking',
    'yield_farming',
    'liquidity_provision',
    'collateralization'
);


ALTER TYPE public.transaction_type OWNER TO alisaberi;

--
-- Name: user_role_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_role_type AS ENUM (
    'platform_admin',
    'compliance_officer',
    'treasury_manager',
    'support_agent',
    'enterprise_admin',
    'enterprise_finance',
    'enterprise_developer',
    'premium_consumer',
    'verified_consumer',
    'basic_consumer',
    'secondary_user',
    'merchant',
    'payment_processor'
);


ALTER TYPE public.user_role_type OWNER TO alisaberi;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'deleted',
    'pending_verification'
);


ALTER TYPE public.user_status OWNER TO alisaberi;

--
-- Name: user_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_type AS ENUM (
    'individual',
    'organization'
);


ALTER TYPE public.user_type OWNER TO alisaberi;

--
-- Name: check_overdue_invoices(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.check_overdue_invoices() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE invoices
    SET status = 'OVERDUE'
    WHERE status IN ('PENDING', 'PARTIALLY_PAID')
    AND due_date < NOW();
END;
$$;


ALTER FUNCTION public.check_overdue_invoices() OWNER TO alisaberi;

--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE auth_sessions
    SET is_active = false, revoked_at = NOW(), revoked_reason = 'expired'
    WHERE expires_at < NOW() AND is_active = true;

    DELETE FROM magic_links WHERE expires_at < NOW() - INTERVAL '7 days';
    DELETE FROM auth_sessions WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO alisaberi;

--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN current_setting('app.current_tenant_id', TRUE)::UUID;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;


ALTER FUNCTION public.current_tenant_id() OWNER TO alisaberi;

--
-- Name: ensure_user_consistency(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.ensure_user_consistency() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- If user_type is 'organization', they should have at least one organization
    IF NEW.user_type = 'organization' THEN
        -- Allow the update/insert but schedule a check
        -- The actual organization assignment can happen after user creation
        NULL;
    END IF;

    -- If user_type is 'individual', clear primary organization
    IF NEW.user_type = 'individual' THEN
        NEW.primary_organization_id := NULL;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.ensure_user_consistency() OWNER TO alisaberi;

--
-- Name: get_next_invoice_number(uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.get_next_invoice_number(ent_id uuid) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    next_number BIGINT;
BEGIN
    UPDATE enterprise_treasuries
    SET invoices_created = invoices_created + 1
    WHERE enterprise_id = ent_id
    RETURNING invoices_created INTO next_number;

    RETURN next_number;
END;
$$;


ALTER FUNCTION public.get_next_invoice_number(ent_id uuid) OWNER TO alisaberi;

--
-- Name: invite_user_to_organization(uuid, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role character varying, p_invited_by uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id UUID;
    v_invitation_id UUID;
BEGIN
    -- Check if user exists
    SELECT id INTO v_user_id FROM users WHERE email = p_email;

    IF v_user_id IS NULL THEN
        -- Create a placeholder user if doesn't exist
        INSERT INTO users (email, username, user_type, is_active, is_verified)
        VALUES (p_email, split_part(p_email, '@', 1), 'organization', false, false)
        RETURNING id INTO v_user_id;
    END IF;

    -- Create or update organization_user record
    INSERT INTO organization_users (
        organization_id, user_id, role, invited_by, invitation_status
    ) VALUES (
        p_organization_id, v_user_id, p_role, p_invited_by, 'pending'
    )
    ON CONFLICT (organization_id, user_id)
    DO UPDATE SET
        role = EXCLUDED.role,
        invitation_status = 'pending',
        updated_at = NOW()
    RETURNING id INTO v_invitation_id;

    RETURN v_invitation_id;
END;
$$;


ALTER FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role character varying, p_invited_by uuid) OWNER TO alisaberi;

--
-- Name: invite_user_to_organization(uuid, character varying, public.org_user_role, character varying); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role public.org_user_role, p_invited_by character varying) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id VARCHAR(255);
    v_invitation_id UUID;
BEGIN
    -- Check if user exists
    SELECT id INTO v_user_id FROM users WHERE email = p_email;

    IF v_user_id IS NULL THEN
        -- Create a placeholder user if doesn't exist
        v_user_id := 'usr_' || substr(md5(random()::text), 1, 16);
        INSERT INTO users (id, email, username, user_type, is_active, is_verified)
        VALUES (v_user_id, p_email, split_part(p_email, '@', 1), 'organization', false, false);
    ELSE
        -- Update existing user to organization type if they were individual
        UPDATE users SET user_type = 'organization' WHERE id = v_user_id AND user_type = 'individual';
    END IF;

    -- Create or update organization_user record
    INSERT INTO organization_users (
        organization_id, user_id, role, invited_by, invitation_status
    ) VALUES (
        p_organization_id, v_user_id, p_role, p_invited_by, 'pending'
    )
    ON CONFLICT (organization_id, user_id)
    DO UPDATE SET
        role = EXCLUDED.role,
        invitation_status = 'pending',
        updated_at = NOW()
    RETURNING id INTO v_invitation_id;

    RETURN v_invitation_id;
END;
$$;


ALTER FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role public.org_user_role, p_invited_by character varying) OWNER TO alisaberi;

--
-- Name: update_invoice_status_on_payment(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_invoice_status_on_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.status = 'COMPLETED' THEN
        UPDATE invoices
        SET
            paid_amount = paid_amount + NEW.amount,
            last_payment_at = NEW.created_at,
            status = CASE
                WHEN (paid_amount + NEW.amount) >= amount THEN 'PAID'
                WHEN (paid_amount + NEW.amount) > 0 THEN 'PARTIALLY_PAID'
                ELSE status
            END,
            paid_at = CASE
                WHEN (paid_amount + NEW.amount) >= amount THEN NEW.created_at
                ELSE paid_at
            END
        WHERE id = NEW.invoice_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_status_on_payment() OWNER TO alisaberi;

--
-- Name: update_invoice_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_invoice_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_updated_at() OWNER TO alisaberi;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO alisaberi;

--
-- Name: update_user_risk_profile(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_user_risk_profile() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    avg_risk INTEGER;
    new_risk_level risk_level;
BEGIN
    -- Calculate average risk from recent sessions
    SELECT AVG(risk_score) INTO avg_risk
    FROM auth_risk_analysis
    WHERE user_id = NEW.user_id
    AND analyzed_at > NOW() - INTERVAL '30 days';

    -- Determine risk level
    IF avg_risk IS NULL OR avg_risk < 25 THEN
        new_risk_level := 'low';
    ELSIF avg_risk < 50 THEN
        new_risk_level := 'medium';
    ELSIF avg_risk < 75 THEN
        new_risk_level := 'high';
    ELSE
        new_risk_level := 'critical';
    END IF;

    -- Update user risk profile
    UPDATE users
    SET risk_profile = new_risk_level,
        last_risk_assessment = NOW()
    WHERE id = NEW.user_id;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_risk_profile() OWNER TO alisaberi;

--
-- Name: upgrade_organization_to_enterprise(uuid, public.org_feature_tier); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.upgrade_organization_to_enterprise(p_organization_id uuid, p_feature_tier public.org_feature_tier DEFAULT 'standard'::public.org_feature_tier) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE organizations
    SET
        wallet_type = 'enterprise',
        feature_tier = p_feature_tier,
        upgraded_from_consumer = TRUE,
        consumer_limits = NULL,
        updated_at = NOW()
    WHERE
        id = p_organization_id
        AND wallet_type = 'consumer'
        AND can_upgrade = TRUE;

    RETURN FOUND;
END;
$$;


ALTER FUNCTION public.upgrade_organization_to_enterprise(p_organization_id uuid, p_feature_tier public.org_feature_tier) OWNER TO alisaberi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_financial_insights; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.ai_financial_insights (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    insight_type character varying(50) NOT NULL,
    category character varying(100),
    title character varying(255),
    description text,
    recommendations jsonb DEFAULT '[]'::jsonb,
    potential_savings numeric(20,2),
    confidence_score numeric(5,4),
    is_read boolean DEFAULT false,
    is_acted_upon boolean DEFAULT false,
    user_feedback character varying(50),
    valid_from timestamp with time zone DEFAULT now(),
    valid_until timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_financial_insights OWNER TO alisaberi;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(10) NOT NULL,
    name character varying(255),
    permissions jsonb,
    rate_limit integer DEFAULT 1000,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO alisaberi;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255),
    action character varying(100) NOT NULL,
    actor_id character varying(255),
    actor_role character varying(50),
    changes jsonb,
    ip_address inet,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO alisaberi;

--
-- Name: auth_audit_log; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    event_type character varying(100) NOT NULL,
    auth_method public.auth_method,
    device_id uuid,
    session_id uuid,
    ip_address inet,
    location jsonb,
    success boolean NOT NULL,
    failure_reason character varying(255),
    risk_score integer,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_audit_log OWNER TO alisaberi;

--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_key character varying(255) NOT NULL,
    challenge text NOT NULL,
    challenge_type character varying(50) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auth_challenges OWNER TO alisaberi;

--
-- Name: auth_risk_analysis; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_risk_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    session_id uuid,
    risk_score integer NOT NULL,
    risk_level public.risk_level NOT NULL,
    risk_factors jsonb NOT NULL,
    location_risk integer,
    device_risk integer,
    behavior_risk integer,
    velocity_risk integer,
    required_auth_level public.auth_level,
    is_blocked boolean DEFAULT false,
    analyzed_at timestamp with time zone DEFAULT now(),
    CONSTRAINT auth_risk_analysis_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.auth_risk_analysis OWNER TO alisaberi;

--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    session_token character varying(512) NOT NULL,
    refresh_token character varying(512),
    device_id uuid,
    ip_address inet,
    user_agent text,
    location jsonb,
    risk_score integer DEFAULT 0,
    is_active boolean DEFAULT true,
    last_activity timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone,
    revoked_reason character varying(255),
    CONSTRAINT auth_sessions_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.auth_sessions OWNER TO alisaberi;

--
-- Name: auto_topup_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auto_topup_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    trigger_threshold numeric(20,2) NOT NULL,
    topup_amount numeric(20,2) NOT NULL,
    max_monthly_amount numeric(20,2),
    source_payment_method_id uuid,
    is_active boolean DEFAULT true,
    last_triggered_at timestamp with time zone,
    next_check_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auto_topup_rules OWNER TO alisaberi;

--
-- Name: bill_payments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bill_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bill_id uuid,
    user_id character varying(255),
    amount numeric(20,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method_id uuid,
    transaction_id character varying(255),
    status character varying(50) DEFAULT 'completed'::character varying,
    confirmation_number character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bill_payments OWNER TO alisaberi;

--
-- Name: bills; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    biller_name character varying(255) NOT NULL,
    biller_category character varying(100),
    account_number character varying(100),
    amount_due numeric(20,2),
    due_date date,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    auto_pay_enabled boolean DEFAULT false,
    auto_pay_amount numeric(20,2),
    payment_method_id uuid,
    status character varying(50) DEFAULT 'pending'::character varying,
    last_paid_date date,
    next_due_date date,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bills OWNER TO alisaberi;

--
-- Name: blockchain_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.blockchain_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    chain character varying(50) NOT NULL,
    transaction_hash character varying(255),
    from_address character varying(255),
    to_address character varying(255),
    value numeric(40,18),
    token_address character varying(255),
    token_symbol character varying(20),
    gas_used bigint,
    gas_price numeric(40,18),
    nonce integer,
    block_number bigint,
    status public.transaction_status,
    type public.transaction_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    confirmed_at timestamp with time zone
);


ALTER TABLE public.blockchain_transactions OWNER TO alisaberi;

--
-- Name: blockchain_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.blockchain_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_type character varying(50) NOT NULL,
    chain_id integer,
    network public.blockchain_network,
    address character varying(255) NOT NULL,
    public_key text,
    encrypted_private_key text,
    derivation_path character varying(255),
    is_primary boolean DEFAULT false,
    is_imported boolean DEFAULT false,
    custody_type character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.blockchain_wallets OWNER TO alisaberi;

--
-- Name: bridge_swaps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bridge_swaps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    swap_id character varying(255) NOT NULL,
    user_id character varying(255),
    from_chain public.blockchain_network NOT NULL,
    to_chain public.blockchain_network NOT NULL,
    from_token_address character varying(255),
    to_token_address character varying(255),
    from_amount numeric(40,18) NOT NULL,
    to_amount numeric(40,18),
    fee_amount numeric(40,18),
    from_tx_hash character varying(255),
    to_tx_hash character varying(255),
    status public.transaction_status,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.bridge_swaps OWNER TO alisaberi;

--
-- Name: business_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.business_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_name character varying(255) NOT NULL,
    rule_type public.rule_type,
    entity_type character varying(50),
    entity_id character varying(255),
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.business_rules OWNER TO alisaberi;

--
-- Name: businesses; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.businesses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid,
    business_name character varying(255) NOT NULL,
    business_type character varying(100),
    industry character varying(100),
    annual_revenue numeric(20,2),
    employee_count integer,
    founded_date date,
    description text,
    logo_url text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.businesses OWNER TO alisaberi;

--
-- Name: charity_donations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.charity_donations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    charity_id uuid,
    amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    transaction_id character varying(255),
    receipt_url text,
    tax_receipt_sent boolean DEFAULT false,
    tax_year integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.charity_donations OWNER TO alisaberi;

--
-- Name: charity_organizations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.charity_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    ein character varying(20),
    category character varying(100),
    cause character varying(255),
    description text,
    website character varying(255),
    logo_url text,
    is_verified boolean DEFAULT false,
    tax_deductible boolean DEFAULT false,
    verification_date date,
    impact_metrics jsonb DEFAULT '{}'::jsonb,
    transparency_score numeric(5,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.charity_organizations OWNER TO alisaberi;

--
-- Name: child_parents; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.child_parents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_id character varying(255),
    child_id character varying(255),
    relationship character varying(50),
    daily_limit numeric(20,2),
    monthly_limit numeric(20,2),
    auto_topup_enabled boolean DEFAULT false,
    auto_topup_threshold numeric(20,2),
    auto_topup_amount numeric(20,2),
    permissions jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.child_parents OWNER TO alisaberi;

--
-- Name: compliance_checks; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.compliance_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    transaction_id character varying(255),
    check_type character varying(50),
    check_status character varying(50),
    risk_score integer,
    risk_factors jsonb,
    reviewed_by character varying(255),
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    reviewed_at timestamp with time zone
);


ALTER TABLE public.compliance_checks OWNER TO alisaberi;

--
-- Name: contract_interactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.contract_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contract_id uuid,
    user_id character varying(255),
    function_name character varying(255),
    parameters jsonb,
    transaction_hash character varying(255),
    gas_used bigint,
    status public.transaction_status,
    result jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.contract_interactions OWNER TO alisaberi;

--
-- Name: custody_configurations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custody_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    custody_type public.custody_type NOT NULL,
    key_shares integer DEFAULT 2,
    threshold integer DEFAULT 2,
    user_shard_encrypted text,
    server_shard_location character varying(50),
    recovery_method character varying(50),
    recovery_shares jsonb,
    backup_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT custody_configurations_key_shares_check CHECK (((key_shares >= 1) AND (key_shares <= 5)))
);


ALTER TABLE public.custody_configurations OWNER TO alisaberi;

--
-- Name: customer_credits; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.customer_credits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id character varying(255),
    organization_id uuid,
    amount numeric(20,2) NOT NULL,
    source_invoice_id uuid,
    applied_to_invoice_id uuid,
    status character varying(50) DEFAULT 'AVAILABLE'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    applied_at timestamp without time zone,
    expires_at timestamp without time zone,
    CONSTRAINT chk_credit_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_credit_status CHECK (((status)::text = ANY ((ARRAY['AVAILABLE'::character varying, 'APPLIED'::character varying, 'EXPIRED'::character varying, 'REFUNDED'::character varying])::text[])))
);


ALTER TABLE public.customer_credits OWNER TO alisaberi;

--
-- Name: TABLE customer_credits; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.customer_credits IS 'Customer credit balances from invoice overpayments';


--
-- Name: enterprise_ramps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.enterprise_ramps (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    type character varying(10) NOT NULL,
    amount numeric(20,2) NOT NULL,
    method character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    reference_id character varying(255),
    bank_account_id uuid,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    metadata jsonb,
    CONSTRAINT chk_ramp_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_ramp_method CHECK (((method)::text = ANY ((ARRAY['ACH'::character varying, 'WIRE'::character varying, 'CARD'::character varying, 'CHECK'::character varying])::text[]))),
    CONSTRAINT chk_ramp_provider CHECK (((provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying, 'tillipay'::character varying])::text[]))),
    CONSTRAINT chk_ramp_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT chk_ramp_type CHECK (((type)::text = ANY ((ARRAY['ONRAMP'::character varying, 'OFFRAMP'::character varying])::text[])))
);


ALTER TABLE public.enterprise_ramps OWNER TO alisaberi;

--
-- Name: enterprise_treasuries; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.enterprise_treasuries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    wallet_address character varying(255) NOT NULL,
    solana_tree_address character varying(255),
    tree_capacity integer DEFAULT 1048576,
    invoices_created integer DEFAULT 0,
    tempo_balance numeric(20,2) DEFAULT 0.00,
    circle_balance numeric(20,2) DEFAULT 0.00,
    tempo_wallet_id character varying(255),
    circle_wallet_id character varying(255),
    total_minted numeric(20,2) DEFAULT 0.00,
    total_burned numeric(20,2) DEFAULT 0.00,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_treasury_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'SUSPENDED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.enterprise_treasuries OWNER TO alisaberi;

--
-- Name: TABLE enterprise_treasuries; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.enterprise_treasuries IS 'Enterprise treasury management with Solana integration for tokenized invoices';


--
-- Name: gift_cards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.gift_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    initial_value numeric(20,2) NOT NULL,
    current_balance numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    purchaser_id character varying(255),
    recipient_id character varying(255),
    recipient_email character varying(255),
    is_activated boolean DEFAULT false,
    is_redeemed boolean DEFAULT false,
    expires_at timestamp with time zone,
    design_template character varying(100),
    personal_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    redeemed_at timestamp with time zone
);


ALTER TABLE public.gift_cards OWNER TO alisaberi;

--
-- Name: invoice_attachments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_attachments (
    id integer NOT NULL,
    invoice_id character varying(50),
    file_name character varying(255) NOT NULL,
    file_type character varying(50),
    file_size integer,
    storage_url text,
    ipfs_hash character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_attachments OWNER TO alisaberi;

--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_attachments_id_seq OWNER TO alisaberi;

--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_attachments_id_seq OWNED BY public.invoice_attachments.id;


--
-- Name: invoice_batch_items; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_batch_items (
    id integer NOT NULL,
    batch_id character varying(50),
    invoice_id character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_batch_items OWNER TO alisaberi;

--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_batch_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_batch_items_id_seq OWNER TO alisaberi;

--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_batch_items_id_seq OWNED BY public.invoice_batch_items.id;


--
-- Name: invoice_batches; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_batches (
    id integer NOT NULL,
    batch_id character varying(50) NOT NULL,
    user_id character varying(255),
    total_invoices integer NOT NULL,
    total_amount numeric(20,8),
    currency character varying(10),
    status character varying(20) DEFAULT 'processing'::character varying,
    blockchain_tx_hash character varying(255),
    processed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_batches OWNER TO alisaberi;

--
-- Name: invoice_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_batches_id_seq OWNER TO alisaberi;

--
-- Name: invoice_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_batches_id_seq OWNED BY public.invoice_batches.id;


--
-- Name: invoice_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    event_type character varying(50) NOT NULL,
    event_data jsonb,
    user_id character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_event_type CHECK (((event_type)::text = ANY ((ARRAY['CREATED'::character varying, 'SENT'::character varying, 'VIEWED'::character varying, 'PAYMENT_RECEIVED'::character varying, 'PAYMENT_FAILED'::character varying, 'REMINDER_SENT'::character varying, 'OVERDUE_NOTICE'::character varying, 'CANCELLED'::character varying, 'REFUNDED'::character varying, 'CREDIT_APPLIED'::character varying])::text[])))
);


ALTER TABLE public.invoice_events OWNER TO alisaberi;

--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid,
    line_number integer NOT NULL,
    description text,
    quantity numeric(20,4) DEFAULT 1,
    unit_price numeric(20,4),
    tax_rate numeric(5,2) DEFAULT 0,
    tax_amount numeric(20,2) DEFAULT 0,
    discount_rate numeric(5,2) DEFAULT 0,
    discount_amount numeric(20,2) DEFAULT 0,
    line_total numeric(20,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.invoice_line_items OWNER TO alisaberi;

--
-- Name: invoice_payment_methods; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_payment_methods (
    id integer NOT NULL,
    invoice_id character varying(50),
    method_type character varying(20) NOT NULL,
    is_enabled boolean DEFAULT true,
    fee_percentage numeric(5,4),
    fee_fixed numeric(10,2),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT invoice_payment_methods_method_type_check CHECK (((method_type)::text = ANY ((ARRAY['wallet'::character varying, 'card'::character varying, 'bank'::character varying, 'crypto'::character varying])::text[])))
);


ALTER TABLE public.invoice_payment_methods OWNER TO alisaberi;

--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_payment_methods_id_seq OWNER TO alisaberi;

--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_payment_methods_id_seq OWNED BY public.invoice_payment_methods.id;


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    payer_id character varying(255),
    amount numeric(20,2) NOT NULL,
    payment_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    transaction_hash character varying(255),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    CONSTRAINT chk_payment_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_payment_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying, 'REVERSED'::character varying])::text[]))),
    CONSTRAINT chk_payment_type CHECK (((payment_type)::text = ANY ((ARRAY['EXACT'::character varying, 'PARTIAL'::character varying, 'OVERPAYMENT'::character varying, 'CREDIT'::character varying])::text[]))),
    CONSTRAINT chk_provider CHECK (((provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying, 'credit'::character varying])::text[])))
);


ALTER TABLE public.invoice_payments OWNER TO alisaberi;

--
-- Name: TABLE invoice_payments; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoice_payments IS 'Payment records for invoices with support for partial and overpayments';


--
-- Name: invoice_templates; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    description text,
    default_terms text,
    default_notes text,
    line_items_template jsonb,
    tax_rate numeric(5,2) DEFAULT 0.00,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_recurrence_pattern CHECK (((recurrence_pattern IS NULL) OR ((recurrence_pattern)::text = ANY ((ARRAY['DAILY'::character varying, 'WEEKLY'::character varying, 'BIWEEKLY'::character varying, 'MONTHLY'::character varying, 'QUARTERLY'::character varying, 'ANNUALLY'::character varying])::text[]))))
);


ALTER TABLE public.invoice_templates OWNER TO alisaberi;

--
-- Name: invoice_tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_tokens (
    id integer NOT NULL,
    invoice_id character varying(50) NOT NULL,
    token_id character varying(255),
    chain character varying(20) NOT NULL,
    tx_hash character varying(255),
    from_user_id character varying(255),
    to_user_id character varying(255),
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    description text,
    due_date timestamp without time zone,
    ipfs_hash character varying(255),
    smart_contract_address character varying(255),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    paid_at timestamp without time zone,
    payment_tx_hash character varying(255),
    paid_by_user_id character varying(255),
    line_items jsonb,
    metadata jsonb,
    tags character varying[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT invoice_tokens_chain_check CHECK (((chain)::text = ANY ((ARRAY['evm'::character varying, 'solana'::character varying])::text[]))),
    CONSTRAINT invoice_tokens_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'cancelled'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.invoice_tokens OWNER TO alisaberi;

--
-- Name: TABLE invoice_tokens; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoice_tokens IS 'Main table for tokenized invoices - foundation of invoice-first payment model';


--
-- Name: COLUMN invoice_tokens.invoice_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.invoice_id IS 'Unique invoice identifier (e.g., INV-1234567890-ABCD)';


--
-- Name: COLUMN invoice_tokens.token_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.token_id IS 'Blockchain token ID (NFT or SPL token)';


--
-- Name: COLUMN invoice_tokens.chain; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.chain IS 'Blockchain network: evm (Base L2) or solana';


--
-- Name: COLUMN invoice_tokens.ipfs_hash; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.ipfs_hash IS 'IPFS hash for invoice metadata storage';


--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_tokens_id_seq OWNER TO alisaberi;

--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_tokens_id_seq OWNED BY public.invoice_tokens.id;


--
-- Name: invoice_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid,
    wallet_address character varying(255) NOT NULL,
    blockchain character varying(50) DEFAULT 'polygon'::character varying,
    mode character varying(20) DEFAULT 'ephemeral'::character varying,
    is_ephemeral boolean DEFAULT true,
    persistence_threshold numeric(20,2),
    auto_sweep_enabled boolean DEFAULT true,
    quantum_resistant boolean DEFAULT false,
    quantum_key_id uuid,
    quantum_algorithm character varying(50),
    status character varying(50) DEFAULT 'active'::character varying,
    activated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    swept_at timestamp with time zone,
    transaction_count integer DEFAULT 0,
    total_received numeric(20,2) DEFAULT 0,
    total_swept numeric(20,2) DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.invoice_wallets OWNER TO alisaberi;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_number character varying(100) NOT NULL,
    user_id character varying(255),
    organization_id uuid,
    type character varying(50),
    amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    client_name character varying(255),
    vendor_name character varying(255),
    description text,
    payment_method character varying(50),
    due_date date,
    paid_date date,
    is_recurring boolean DEFAULT false,
    create_ephemeral_wallet boolean DEFAULT false,
    ephemeral_wallet_created boolean DEFAULT false,
    wallet_mode character varying(20),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    solana_address character varying(255),
    recipient_id character varying(255),
    paid_amount numeric(20,2) DEFAULT 0.00,
    invoice_type character varying(50) DEFAULT 'ENTERPRISE'::character varying,
    metadata_uri text,
    paid_at timestamp without time zone,
    last_payment_at timestamp without time zone
);


ALTER TABLE public.invoices OWNER TO alisaberi;

--
-- Name: TABLE invoices; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoices IS 'Tokenized invoices stored as compressed NFTs on Solana blockchain';


--
-- Name: kyc_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.kyc_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    provider public.kyc_provider,
    session_id character varying(255),
    inquiry_id character varying(255),
    status public.kyc_status,
    verification_level character varying(50),
    risk_score integer,
    checks_completed jsonb,
    documents_submitted jsonb,
    rejection_reasons jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.kyc_sessions OWNER TO alisaberi;

--
-- Name: loyalty_rewards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.loyalty_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_name character varying(255) NOT NULL,
    program_type character varying(50),
    tiers jsonb DEFAULT '[]'::jsonb,
    point_value numeric(10,4) DEFAULT 0.01,
    earning_rules jsonb DEFAULT '{}'::jsonb,
    redemption_rules jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.loyalty_rewards OWNER TO alisaberi;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.loyalty_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    reward_program_id uuid,
    transaction_type character varying(50) NOT NULL,
    points_earned integer DEFAULT 0,
    points_redeemed integer DEFAULT 0,
    points_balance integer NOT NULL,
    reference_transaction_id character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.loyalty_transactions OWNER TO alisaberi;

--
-- Name: magic_links; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.magic_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    token character varying(512) NOT NULL,
    email character varying(255),
    purpose character varying(50) DEFAULT 'login'::character varying,
    used boolean DEFAULT false,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    used_at timestamp with time zone,
    ip_address inet
);


ALTER TABLE public.magic_links OWNER TO alisaberi;

--
-- Name: multi_sig_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.multi_sig_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    transaction_data jsonb NOT NULL,
    signatures jsonb DEFAULT '[]'::jsonb,
    status public.multi_sig_status,
    executed_tx_hash character varying(255),
    created_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    executed_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.multi_sig_transactions OWNER TO alisaberi;

--
-- Name: multi_sig_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.multi_sig_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_name character varying(255) NOT NULL,
    enterprise_id character varying(255),
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    threshold integer NOT NULL,
    signers jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.multi_sig_wallets OWNER TO alisaberi;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    legal_name character varying(255),
    tax_id character varying(50),
    registration_number character varying(100),
    parent_id uuid,
    org_type character varying(50) DEFAULT 'standalone'::character varying,
    path_ids uuid[],
    hierarchy_level integer DEFAULT 0,
    email character varying(255),
    phone character varying(50),
    website character varying(255),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(50),
    postal_code character varying(20),
    country character varying(2),
    kyb_status public.kyc_status DEFAULT 'not_started'::public.kyc_status,
    aml_risk_score integer,
    compliance_status character varying(50),
    verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    erp_customer_id character varying(100),
    erp_vendor_id character varying(100),
    erp_cost_center character varying(50),
    erp_sync_enabled boolean DEFAULT false,
    erp_last_sync timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    wallet_type character varying(50) DEFAULT 'enterprise'::character varying,
    feature_tier character varying(50) DEFAULT 'basic'::character varying,
    can_upgrade boolean DEFAULT true,
    upgraded_from_consumer boolean DEFAULT false,
    consumer_limits jsonb DEFAULT '{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}'::jsonb,
    parent_organization_id uuid,
    organization_type character varying(50) DEFAULT 'standalone'::character varying,
    email_verified boolean DEFAULT false,
    phone_verified boolean DEFAULT false,
    mfa_enabled boolean DEFAULT true,
    mfa_methods jsonb DEFAULT '["email", "sms"]'::jsonb,
    type character varying(100),
    industry character varying(100),
    status character varying(50) DEFAULT 'active'::character varying,
    kyc_status character varying(50) DEFAULT 'not_started'::character varying,
    compliance_score integer DEFAULT 75,
    description text
);


ALTER TABLE public.organizations OWNER TO alisaberi;

--
-- Name: organization_hierarchy_view; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.organization_hierarchy_view AS
 WITH RECURSIVE org_tree AS (
         SELECT organizations.id,
            organizations.name,
            organizations.parent_organization_id,
            organizations.organization_type,
            organizations.wallet_type,
            organizations.feature_tier,
            0 AS level,
            ARRAY[organizations.id] AS path
           FROM public.organizations
          WHERE (organizations.parent_organization_id IS NULL)
        UNION ALL
         SELECT o.id,
            o.name,
            o.parent_organization_id,
            o.organization_type,
            o.wallet_type,
            o.feature_tier,
            (ot.level + 1),
            (ot.path || o.id)
           FROM (public.organizations o
             JOIN org_tree ot ON ((o.parent_organization_id = ot.id)))
        )
 SELECT id,
    name,
    parent_organization_id,
    organization_type,
    wallet_type,
    feature_tier,
    level,
    path
   FROM org_tree
  ORDER BY path;


ALTER VIEW public.organization_hierarchy_view OWNER TO alisaberi;

--
-- Name: organization_users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.organization_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id character varying(255) NOT NULL,
    role public.org_user_role DEFAULT 'member'::public.org_user_role NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    is_primary boolean DEFAULT false,
    joined_at timestamp with time zone DEFAULT now(),
    invited_by character varying(255),
    invitation_status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_users OWNER TO alisaberi;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.payment_methods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    method_type public.payment_method_type NOT NULL,
    card_last_four character varying(4),
    card_brand character varying(50),
    exp_month integer,
    exp_year integer,
    bank_name character varying(255),
    account_last_four character varying(4),
    routing_number character varying(20),
    wallet_address character varying(255),
    blockchain_network character varying(50),
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    verified boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payment_methods OWNER TO alisaberi;

--
-- Name: payment_requests; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.payment_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    requester_id character varying(255),
    payer_id character varying(255),
    amount numeric(20,2) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    qr_code text,
    solana_address character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone,
    declined_at timestamp without time zone,
    decline_reason text,
    expires_at timestamp without time zone,
    CONSTRAINT chk_request_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_request_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'PAID'::character varying, 'DECLINED'::character varying, 'EXPIRED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.payment_requests OWNER TO alisaberi;

--
-- Name: TABLE payment_requests; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.payment_requests IS 'P2P payment requests between consumers';


--
-- Name: price_feeds; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.price_feeds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_symbol character varying(20) NOT NULL,
    base_currency character varying(10) NOT NULL,
    price numeric(40,18) NOT NULL,
    source public.oracle_source,
    confidence numeric(5,2),
    volume_24h numeric(40,18),
    market_cap numeric(40,18),
    metadata jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.price_feeds OWNER TO alisaberi;

--
-- Name: quantum_key_registry; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.quantum_key_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    algorithm character varying(50) NOT NULL,
    public_key text NOT NULL,
    key_hash character varying(255) NOT NULL,
    lattice_params jsonb,
    security_level integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    rotated_at timestamp with time zone
);


ALTER TABLE public.quantum_key_registry OWNER TO alisaberi;

--
-- Name: ready_cash_loans; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.ready_cash_loans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    loan_amount numeric(20,2) NOT NULL,
    interest_rate numeric(5,4) NOT NULL,
    term_days integer NOT NULL,
    total_repayment numeric(20,2) NOT NULL,
    amount_paid numeric(20,2) DEFAULT 0,
    next_payment_date date,
    status character varying(50) DEFAULT 'pending'::character varying,
    approved_at timestamp with time zone,
    disbursed_at timestamp with time zone,
    fully_paid_at timestamp with time zone,
    credit_score integer,
    risk_assessment jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ready_cash_loans OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.recurring_invoice_templates (
    id integer NOT NULL,
    user_id character varying(255),
    template_name character varying(255),
    to_user_id character varying(255),
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    description text,
    frequency character varying(20),
    interval_count integer DEFAULT 1,
    next_invoice_date date,
    end_date date,
    is_active boolean DEFAULT true,
    auto_send boolean DEFAULT true,
    auto_charge boolean DEFAULT false,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT recurring_invoice_templates_frequency_check CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'yearly'::character varying])::text[])))
);


ALTER TABLE public.recurring_invoice_templates OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.recurring_invoice_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_invoice_templates_id_seq OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.recurring_invoice_templates_id_seq OWNED BY public.recurring_invoice_templates.id;


--
-- Name: sage_bank_reconciliations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_bank_reconciliations (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    bank_account_id character varying(255) NOT NULL,
    statement_date date NOT NULL,
    statement_balance numeric(15,2),
    reconciled_balance numeric(15,2),
    difference numeric(15,2),
    status character varying(20),
    reconciled_items jsonb DEFAULT '[]'::jsonb,
    outstanding_items jsonb DEFAULT '[]'::jsonb,
    reconciled_by character varying(255),
    reconciled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_bank_reconciliations OWNER TO alisaberi;

--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_bank_reconciliations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_bank_reconciliations_id_seq OWNER TO alisaberi;

--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_bank_reconciliations_id_seq OWNED BY public.sage_bank_reconciliations.id;


--
-- Name: sage_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_connections (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    company_id character varying(255),
    company_name character varying(255),
    access_token text,
    refresh_token text,
    token_expiry timestamp without time zone,
    subscription_type character varying(50),
    region character varying(10),
    features jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_connections OWNER TO alisaberi;

--
-- Name: sage_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_connections_id_seq OWNER TO alisaberi;

--
-- Name: sage_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_connections_id_seq OWNED BY public.sage_connections.id;


--
-- Name: sage_entities; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_entities (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    sage_id character varying(255) NOT NULL,
    data jsonb NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb,
    audit_trail jsonb DEFAULT '[]'::jsonb,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version integer DEFAULT 1
);


ALTER TABLE public.sage_entities OWNER TO alisaberi;

--
-- Name: sage_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_entities_id_seq OWNER TO alisaberi;

--
-- Name: sage_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_entities_id_seq OWNED BY public.sage_entities.id;


--
-- Name: sage_journal_entries; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_journal_entries (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    journal_id character varying(255) NOT NULL,
    reference character varying(100),
    date date NOT NULL,
    description text,
    total_amount numeric(15,2),
    currency_code character varying(3),
    journal_lines jsonb NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb,
    posted boolean DEFAULT false,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_journal_entries OWNER TO alisaberi;

--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_journal_entries_id_seq OWNER TO alisaberi;

--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_journal_entries_id_seq OWNED BY public.sage_journal_entries.id;


--
-- Name: sage_ledger_accounts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_ledger_accounts (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    ledger_account_id character varying(255) NOT NULL,
    display_id character varying(50),
    nominal_code integer,
    name character varying(255),
    account_type character varying(50),
    category character varying(100),
    tax_rate_id character varying(255),
    is_control boolean DEFAULT false,
    is_active boolean DEFAULT true,
    balance numeric(15,2),
    currency_code character varying(3),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_ledger_accounts OWNER TO alisaberi;

--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_ledger_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_ledger_accounts_id_seq OWNER TO alisaberi;

--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_ledger_accounts_id_seq OWNED BY public.sage_ledger_accounts.id;


--
-- Name: sage_sync_queue; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_sync_queue (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    operation character varying(20) NOT NULL,
    data jsonb NOT NULL,
    priority integer DEFAULT 5,
    status character varying(20) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    error_message text,
    scheduled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone
);


ALTER TABLE public.sage_sync_queue OWNER TO alisaberi;

--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_sync_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_sync_queue_id_seq OWNER TO alisaberi;

--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_sync_queue_id_seq OWNED BY public.sage_sync_queue.id;


--
-- Name: sage_tax_returns; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_tax_returns (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    return_id character varying(255) NOT NULL,
    tax_type character varying(50),
    period_start date,
    period_end date,
    status character varying(20),
    total_sales numeric(15,2),
    total_purchases numeric(15,2),
    tax_due numeric(15,2),
    submission_date date,
    reference_number character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_tax_returns OWNER TO alisaberi;

--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_tax_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_tax_returns_id_seq OWNER TO alisaberi;

--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_tax_returns_id_seq OWNED BY public.sage_tax_returns.id;


--
-- Name: smart_contracts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.smart_contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying(255),
    contract_name character varying(255) NOT NULL,
    contract_type character varying(50),
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    abi jsonb,
    bytecode text,
    source_code text,
    compiler_version character varying(50),
    optimization_enabled boolean,
    is_verified boolean DEFAULT false,
    is_upgradeable boolean DEFAULT false,
    solana_program_type public.solana_program_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    deployed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.smart_contracts OWNER TO alisaberi;

--
-- Name: split_bill_participants; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.split_bill_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    split_bill_id uuid,
    user_id character varying(255),
    email character varying(255),
    phone character varying(50),
    name character varying(255),
    amount_owed numeric(20,2) NOT NULL,
    amount_paid numeric(20,2) DEFAULT 0,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_date timestamp with time zone,
    transaction_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.split_bill_participants OWNER TO alisaberi;

--
-- Name: split_bills; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.split_bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    creator_id character varying(255),
    title character varying(255) NOT NULL,
    total_amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    split_method character varying(50) DEFAULT 'equal'::character varying,
    custom_splits jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    settled_at timestamp with time zone,
    category character varying(100),
    description text,
    receipt_url text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.split_bills OWNER TO alisaberi;

--
-- Name: sso_providers; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_name character varying(100) NOT NULL,
    provider_type public.sso_provider_type NOT NULL,
    client_id character varying(255),
    client_secret_encrypted text,
    authorization_url text,
    token_url text,
    user_info_url text,
    jwks_url text,
    scopes text[],
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sso_providers OWNER TO alisaberi;

--
-- Name: super_app_bookings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.super_app_bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    booking_type character varying(50) NOT NULL,
    service_provider character varying(255),
    booking_reference character varying(100),
    booking_date timestamp with time zone NOT NULL,
    service_date timestamp with time zone,
    total_amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    booking_details jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'confirmed'::character varying,
    cancellation_policy jsonb DEFAULT '{}'::jsonb,
    cancelled_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.super_app_bookings OWNER TO alisaberi;

--
-- Name: tenant_audit_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id character varying(255),
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    ip_address inet,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_audit_logs OWNER TO alisaberi;

--
-- Name: tenant_billing; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_billing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    billing_period_start date NOT NULL,
    billing_period_end date NOT NULL,
    subscription_fee numeric(10,2) DEFAULT 0,
    transaction_fees numeric(10,2) DEFAULT 0,
    api_usage_fees numeric(10,2) DEFAULT 0,
    storage_fees numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    invoice_url text,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_billing_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.tenant_billing OWNER TO alisaberi;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    setting_type character varying(50) DEFAULT 'string'::character varying,
    is_encrypted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_settings OWNER TO alisaberi;

--
-- Name: tenant_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    wallet_id uuid,
    transaction_type character varying(50) NOT NULL,
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    external_reference character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_transactions OWNER TO alisaberi;

--
-- Name: tenant_users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    is_primary boolean DEFAULT false,
    status character varying(50) DEFAULT 'active'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    removed_at timestamp without time zone,
    CONSTRAINT tenant_users_role_check CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'manager'::character varying, 'member'::character varying, 'viewer'::character varying])::text[]))),
    CONSTRAINT tenant_users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'removed'::character varying])::text[])))
);


ALTER TABLE public.tenant_users OWNER TO alisaberi;

--
-- Name: tenant_vault_keys; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_vault_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    key_type character varying(50) NOT NULL,
    public_key text,
    encrypted_private_key text,
    key_metadata jsonb DEFAULT '{}'::jsonb,
    rotation_date timestamp without time zone,
    expiration_date timestamp without time zone,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_vault_keys_key_type_check CHECK (((key_type)::text = ANY ((ARRAY['master'::character varying, 'encryption'::character varying, 'signing'::character varying, 'api'::character varying])::text[]))),
    CONSTRAINT tenant_vault_keys_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'rotating'::character varying, 'expired'::character varying, 'revoked'::character varying])::text[])))
);


ALTER TABLE public.tenant_vault_keys OWNER TO alisaberi;

--
-- Name: tenant_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    wallet_type character varying(50) NOT NULL,
    currency character varying(10) NOT NULL,
    balance numeric(20,8) DEFAULT 0,
    available_balance numeric(20,8) DEFAULT 0,
    pending_balance numeric(20,8) DEFAULT 0,
    blockchain_address character varying(255),
    circle_wallet_id character varying(255),
    tempo_wallet_id character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_wallets_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'frozen'::character varying, 'closed'::character varying])::text[]))),
    CONSTRAINT tenant_wallets_wallet_type_check CHECK (((wallet_type)::text = ANY ((ARRAY['fiat'::character varying, 'crypto'::character varying, 'stablecoin'::character varying, 'treasury'::character varying])::text[])))
);


ALTER TABLE public.tenant_wallets OWNER TO alisaberi;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    isolation_level character varying(50) DEFAULT 'row'::character varying NOT NULL,
    billing_tier character varying(50) DEFAULT 'free'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    wallet_derivation_path character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    gross_margin_percent numeric(5,2) DEFAULT 0,
    subscription_expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenants_billing_tier_check CHECK (((billing_tier)::text = ANY ((ARRAY['free'::character varying, 'small_business'::character varying, 'enterprise'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT tenants_isolation_level_check CHECK (((isolation_level)::text = ANY ((ARRAY['row'::character varying, 'schema'::character varying, 'database'::character varying])::text[]))),
    CONSTRAINT tenants_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'suspended'::character varying, 'terminated'::character varying])::text[]))),
    CONSTRAINT tenants_type_check CHECK (((type)::text = ANY ((ARRAY['individual'::character varying, 'household_member'::character varying, 'small_business'::character varying, 'enterprise'::character varying, 'holding_company'::character varying])::text[])))
);


ALTER TABLE public.tenants OWNER TO alisaberi;

--
-- Name: tillipay_cards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tillipay_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    tillipay_card_id character varying(255),
    card_number_masked character varying(20),
    card_type public.card_type,
    card_network public.card_network,
    card_status character varying(50),
    expiry_month integer,
    expiry_year integer,
    billing_address jsonb,
    spending_limits jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    deactivated_at timestamp with time zone
);


ALTER TABLE public.tillipay_cards OWNER TO alisaberi;

--
-- Name: tillipay_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tillipay_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    card_id uuid,
    tillipay_tx_id character varying(255),
    transaction_type public.transaction_type,
    amount numeric(20,2),
    currency character varying(10),
    merchant_name character varying(255),
    merchant_category character varying(50),
    status public.transaction_status,
    authorization_code character varying(50),
    decline_reason character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tillipay_transactions OWNER TO alisaberi;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id character varying(255),
    token_name character varying(255) NOT NULL,
    token_symbol character varying(20) NOT NULL,
    token_type public.token_standard,
    chain public.blockchain_network NOT NULL,
    contract_address character varying(255),
    mint_address character varying(255),
    decimals integer DEFAULT 18,
    total_supply numeric(40,18),
    max_supply numeric(40,18),
    is_paused boolean DEFAULT false,
    is_compliant boolean DEFAULT true,
    compliance_standard character varying(50),
    stablecoin_type public.stablecoin_backing,
    stablecoin_peg public.stablecoin_peg,
    asset_type public.crypto_asset_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deployed_at timestamp with time zone
);


ALTER TABLE public.tokens OWNER TO alisaberi;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.transactions (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    type public.transaction_type NOT NULL,
    amount numeric(40,18) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    from_address character varying(255),
    to_address character varying(255),
    from_user_id character varying(255),
    to_user_id character varying(255),
    blockchain_network character varying(50),
    transaction_hash character varying(255),
    block_number bigint,
    gas_used bigint,
    gas_price numeric(40,18),
    status public.transaction_status DEFAULT 'pending'::public.transaction_status,
    status_message text,
    compliance_checked boolean DEFAULT false,
    compliance_status character varying(50),
    risk_score integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.transactions OWNER TO alisaberi;

--
-- Name: treasury_accounts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id character varying(255),
    account_name character varying(255) NOT NULL,
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    balance numeric(40,18) DEFAULT 0,
    locked_balance numeric(40,18) DEFAULT 0,
    reserve_ratio numeric(5,2),
    account_type character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.treasury_accounts OWNER TO alisaberi;

--
-- Name: treasury_swaps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_swaps (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    amount numeric(20,2) NOT NULL,
    from_provider character varying(50) NOT NULL,
    to_provider character varying(50) NOT NULL,
    from_balance_before numeric(20,2),
    from_balance_after numeric(20,2),
    to_balance_before numeric(20,2),
    to_balance_after numeric(20,2),
    swap_reason text,
    transaction_hash character varying(255),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    CONSTRAINT chk_different_providers CHECK (((from_provider)::text <> (to_provider)::text)),
    CONSTRAINT chk_swap_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_swap_providers CHECK ((((from_provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying])::text[])) AND ((to_provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying])::text[])))),
    CONSTRAINT chk_swap_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.treasury_swaps OWNER TO alisaberi;

--
-- Name: TABLE treasury_swaps; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.treasury_swaps IS 'Audit trail for treasury swaps between Tempo and Circle';


--
-- Name: treasury_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    treasury_account_id uuid,
    transaction_type public.transaction_type,
    amount numeric(40,18) NOT NULL,
    token_id uuid,
    from_address character varying(255),
    to_address character varying(255),
    blockchain_tx_id uuid,
    status public.transaction_status,
    executed_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    executed_at timestamp with time zone
);


ALTER TABLE public.treasury_transactions OWNER TO alisaberi;

--
-- Name: user_biometrics; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_biometrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    device_id uuid,
    biometric_type public.biometric_type NOT NULL,
    biometric_hash text NOT NULL,
    salt character varying(255) NOT NULL,
    algorithm character varying(50) DEFAULT 'PBKDF2'::character varying,
    is_active boolean DEFAULT true,
    enrolled_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone,
    failed_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


ALTER TABLE public.user_biometrics OWNER TO alisaberi;

--
-- Name: user_devices_enhanced; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_devices_enhanced (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    device_id character varying(255) NOT NULL,
    device_name character varying(255),
    device_type public.device_type NOT NULL,
    device_model character varying(255),
    os_version character varying(50),
    app_version character varying(50),
    push_token text,
    biometric_enabled boolean DEFAULT false,
    biometric_type public.biometric_type,
    device_fingerprint jsonb,
    trust_level integer DEFAULT 0,
    is_trusted boolean DEFAULT false,
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    blocked_at timestamp with time zone,
    blocked_reason character varying(255),
    CONSTRAINT user_devices_enhanced_trust_level_check CHECK (((trust_level >= 0) AND (trust_level <= 100)))
);


ALTER TABLE public.user_devices_enhanced OWNER TO alisaberi;

--
-- Name: user_mfa_settings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_mfa_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    mfa_type public.mfa_type NOT NULL,
    is_primary boolean DEFAULT false,
    is_enabled boolean DEFAULT true,
    secret_encrypted text,
    phone_number character varying(50),
    email character varying(255),
    backup_codes text[],
    last_used_at timestamp with time zone,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_mfa_settings OWNER TO alisaberi;

--
-- Name: users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.users (
    id character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    phone character varying(50),
    password_hash text,
    profile_image text,
    date_of_birth date,
    auth_level public.auth_level DEFAULT 'basic'::public.auth_level,
    require_mfa boolean DEFAULT false,
    mfa_grace_period_until timestamp with time zone,
    biometric_enabled boolean DEFAULT false,
    custody_type public.custody_type DEFAULT 'self'::public.custody_type,
    risk_profile public.risk_level DEFAULT 'low'::public.risk_level,
    last_risk_assessment timestamp with time zone,
    passwordless_enabled boolean DEFAULT false,
    recovery_email character varying(255),
    recovery_phone character varying(50),
    security_questions jsonb,
    trusted_ips inet[],
    allowed_countries character varying(2)[],
    blocked_countries character varying(2)[],
    failed_login_attempts integer DEFAULT 0,
    last_failed_login timestamp with time zone,
    account_locked_until timestamp with time zone,
    password_changed_at timestamp with time zone DEFAULT now(),
    password_history text[],
    session_timeout_minutes integer DEFAULT 30,
    is_verified boolean DEFAULT false,
    is_active boolean DEFAULT true,
    kyc_verified boolean DEFAULT false,
    kyc_level character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    user_type character varying(50) DEFAULT 'individual'::character varying,
    primary_organization_id uuid
);


ALTER TABLE public.users OWNER TO alisaberi;

--
-- Name: COLUMN users.user_type; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.user_type IS 'Type of user: individual (direct consumer) or organization (business user)';


--
-- Name: COLUMN users.primary_organization_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.primary_organization_id IS 'Primary organization ID for business users, NULL for individuals';


--
-- Name: user_organization_view; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.user_organization_view AS
 SELECT u.id AS user_id,
    u.email,
    u.username,
    u.first_name,
    u.last_name,
    u.user_type,
    u.primary_organization_id,
    o.id AS organization_id,
    o.name AS organization_name,
    o.wallet_type,
    o.feature_tier,
    ou.role AS user_role,
    ou.is_primary,
    ou.joined_at,
        CASE
            WHEN ((u.user_type)::text = 'individual'::text) THEN 'Individual Consumer'::text
            WHEN (((u.user_type)::text = 'organization'::text) AND ((o.wallet_type)::text = 'consumer'::text)) THEN 'Small Business User'::text
            WHEN (((u.user_type)::text = 'organization'::text) AND ((o.wallet_type)::text = 'enterprise'::text)) THEN 'Enterprise User'::text
            ELSE 'Unknown'::text
        END AS user_category
   FROM ((public.users u
     LEFT JOIN public.organization_users ou ON ((((u.id)::text = (ou.user_id)::text) AND ((ou.invitation_status)::text = 'active'::text))))
     LEFT JOIN public.organizations o ON ((ou.organization_id = o.id)));


ALTER VIEW public.user_organization_view OWNER TO alisaberi;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    profile_type character varying(50) NOT NULL,
    date_of_birth date,
    ssn_last_four character varying(4),
    personal_address jsonb,
    emergency_contact jsonb,
    job_title character varying(255),
    department character varying(255),
    employee_id character varying(100),
    business_email character varying(255),
    business_phone character varying(50),
    profile_picture_url text,
    preferences jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO alisaberi;

--
-- Name: user_sso_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_sso_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    provider_id uuid,
    external_user_id character varying(255) NOT NULL,
    access_token_encrypted text,
    refresh_token_encrypted text,
    token_expires_at timestamp with time zone,
    profile_data jsonb,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_sso_connections OWNER TO alisaberi;

--
-- Name: wallet_lifecycle_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_lifecycle_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    event_type character varying(50) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    blockchain_tx_hash character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallet_lifecycle_events OWNER TO alisaberi;

--
-- Name: wallet_mode_decisions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_mode_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    decision_type character varying(50) NOT NULL,
    from_mode character varying(20),
    to_mode character varying(20),
    confidence_score numeric(5,4),
    factors jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallet_mode_decisions OWNER TO alisaberi;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    organization_id uuid,
    wallet_name character varying(255),
    wallet_type character varying(50) NOT NULL,
    wallet_address character varying(255),
    public_key text,
    blockchain character varying(50) DEFAULT 'base'::character varying,
    chain_id integer,
    is_smart_wallet boolean DEFAULT false,
    contract_address character varying(255),
    balance numeric(40,18) DEFAULT 0,
    locked_balance numeric(40,18) DEFAULT 0,
    kyc_status public.kyc_status DEFAULT 'not_started'::public.kyc_status,
    aml_verified boolean DEFAULT false,
    sanctions_checked boolean DEFAULT false,
    is_active boolean DEFAULT true,
    is_primary boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallets OWNER TO alisaberi;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    credential_id text NOT NULL,
    public_key text NOT NULL,
    counter bigint DEFAULT 0,
    device_type character varying(50),
    name character varying(255),
    transports text[],
    backup_eligible boolean DEFAULT false,
    backup_state boolean DEFAULT false,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.webauthn_credentials OWNER TO alisaberi;

--
-- Name: zk_compliance_proofs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zk_compliance_proofs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    proof_type character varying(50) NOT NULL,
    proof_data text NOT NULL,
    verification_key text,
    is_valid boolean,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.zk_compliance_proofs OWNER TO alisaberi;

--
-- Name: zoho_automation_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_automation_rules (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    rule_name character varying(255) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    enabled boolean DEFAULT true,
    priority integer DEFAULT 0,
    last_triggered timestamp without time zone,
    execution_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_automation_rules OWNER TO alisaberi;

--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_automation_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_automation_rules_id_seq OWNER TO alisaberi;

--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_automation_rules_id_seq OWNED BY public.zoho_automation_rules.id;


--
-- Name: zoho_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_connections (
    id integer NOT NULL,
    organization_id character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    organization_name character varying(255),
    access_token text,
    refresh_token text,
    token_expiry timestamp without time zone,
    scope text,
    region character varying(10),
    features jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_connections OWNER TO alisaberi;

--
-- Name: zoho_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_connections_id_seq OWNER TO alisaberi;

--
-- Name: zoho_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_connections_id_seq OWNED BY public.zoho_connections.id;


--
-- Name: zoho_entities; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_entities (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    data jsonb NOT NULL,
    custom_fields jsonb DEFAULT '{}'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    attachments jsonb DEFAULT '[]'::jsonb,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_entities OWNER TO alisaberi;

--
-- Name: zoho_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_entities_id_seq OWNER TO alisaberi;

--
-- Name: zoho_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_entities_id_seq OWNED BY public.zoho_entities.id;


--
-- Name: zoho_recurring_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_recurring_profiles (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    profile_id character varying(255) NOT NULL,
    profile_type character varying(50) NOT NULL,
    customer_id character varying(255),
    frequency character varying(20),
    start_date date,
    end_date date,
    next_invoice_date date,
    total_amount numeric(15,2),
    currency_code character varying(3),
    status character varying(20),
    line_items jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_recurring_profiles OWNER TO alisaberi;

--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_recurring_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_recurring_profiles_id_seq OWNER TO alisaberi;

--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_recurring_profiles_id_seq OWNED BY public.zoho_recurring_profiles.id;


--
-- Name: zoho_sync_history; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_sync_history (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    sync_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    records_synced integer DEFAULT 0,
    errors integer DEFAULT 0,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_details jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.zoho_sync_history OWNER TO alisaberi;

--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_sync_history_id_seq OWNER TO alisaberi;

--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_sync_history_id_seq OWNED BY public.zoho_sync_history.id;


--
-- Name: zoho_tax_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_tax_rules (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    tax_id character varying(255) NOT NULL,
    tax_name character varying(255),
    tax_percentage numeric(10,4),
    tax_type character varying(50),
    is_compound boolean DEFAULT false,
    is_inclusive boolean DEFAULT false,
    region_codes jsonb DEFAULT '[]'::jsonb,
    product_categories jsonb DEFAULT '[]'::jsonb,
    exemptions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_tax_rules OWNER TO alisaberi;

--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_tax_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_tax_rules_id_seq OWNER TO alisaberi;

--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_tax_rules_id_seq OWNED BY public.zoho_tax_rules.id;


--
-- Name: invoice_attachments id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments ALTER COLUMN id SET DEFAULT nextval('public.invoice_attachments_id_seq'::regclass);


--
-- Name: invoice_batch_items id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_batch_items_id_seq'::regclass);


--
-- Name: invoice_batches id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches ALTER COLUMN id SET DEFAULT nextval('public.invoice_batches_id_seq'::regclass);


--
-- Name: invoice_payment_methods id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods ALTER COLUMN id SET DEFAULT nextval('public.invoice_payment_methods_id_seq'::regclass);


--
-- Name: invoice_tokens id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens ALTER COLUMN id SET DEFAULT nextval('public.invoice_tokens_id_seq'::regclass);


--
-- Name: recurring_invoice_templates id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates ALTER COLUMN id SET DEFAULT nextval('public.recurring_invoice_templates_id_seq'::regclass);


--
-- Name: sage_bank_reconciliations id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.sage_bank_reconciliations_id_seq'::regclass);


--
-- Name: sage_connections id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections ALTER COLUMN id SET DEFAULT nextval('public.sage_connections_id_seq'::regclass);


--
-- Name: sage_entities id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities ALTER COLUMN id SET DEFAULT nextval('public.sage_entities_id_seq'::regclass);


--
-- Name: sage_journal_entries id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries ALTER COLUMN id SET DEFAULT nextval('public.sage_journal_entries_id_seq'::regclass);


--
-- Name: sage_ledger_accounts id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts ALTER COLUMN id SET DEFAULT nextval('public.sage_ledger_accounts_id_seq'::regclass);


--
-- Name: sage_sync_queue id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue ALTER COLUMN id SET DEFAULT nextval('public.sage_sync_queue_id_seq'::regclass);


--
-- Name: sage_tax_returns id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns ALTER COLUMN id SET DEFAULT nextval('public.sage_tax_returns_id_seq'::regclass);


--
-- Name: zoho_automation_rules id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules ALTER COLUMN id SET DEFAULT nextval('public.zoho_automation_rules_id_seq'::regclass);


--
-- Name: zoho_connections id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections ALTER COLUMN id SET DEFAULT nextval('public.zoho_connections_id_seq'::regclass);


--
-- Name: zoho_entities id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities ALTER COLUMN id SET DEFAULT nextval('public.zoho_entities_id_seq'::regclass);


--
-- Name: zoho_recurring_profiles id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles ALTER COLUMN id SET DEFAULT nextval('public.zoho_recurring_profiles_id_seq'::regclass);


--
-- Name: zoho_sync_history id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history ALTER COLUMN id SET DEFAULT nextval('public.zoho_sync_history_id_seq'::regclass);


--
-- Name: zoho_tax_rules id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules ALTER COLUMN id SET DEFAULT nextval('public.zoho_tax_rules_id_seq'::regclass);


--
-- Data for Name: ai_financial_insights; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.ai_financial_insights (id, user_id, insight_type, category, title, description, recommendations, potential_savings, confidence_score, is_read, is_acted_upon, user_feedback, valid_from, valid_until, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.api_keys (id, user_id, key_hash, key_prefix, name, permissions, rate_limit, last_used_at, expires_at, is_active, created_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.audit_logs (id, entity_type, entity_id, action, actor_id, actor_role, changes, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: auth_audit_log; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_audit_log (id, user_id, event_type, auth_method, device_id, session_id, ip_address, location, success, failure_reason, risk_score, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: auth_challenges; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_challenges (id, user_key, challenge, challenge_type, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: auth_risk_analysis; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_risk_analysis (id, user_id, session_id, risk_score, risk_level, risk_factors, location_risk, device_risk, behavior_risk, velocity_risk, required_auth_level, is_blocked, analyzed_at) FROM stdin;
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_sessions (id, user_id, session_token, refresh_token, device_id, ip_address, user_agent, location, risk_score, is_active, last_activity, expires_at, created_at, revoked_at, revoked_reason) FROM stdin;
\.


--
-- Data for Name: auto_topup_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auto_topup_rules (id, user_id, wallet_id, trigger_threshold, topup_amount, max_monthly_amount, source_payment_method_id, is_active, last_triggered_at, next_check_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bill_payments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bill_payments (id, bill_id, user_id, amount, payment_date, payment_method_id, transaction_id, status, confirmation_number, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bills (id, user_id, biller_name, biller_category, account_number, amount_due, due_date, is_recurring, recurrence_pattern, auto_pay_enabled, auto_pay_amount, payment_method_id, status, last_paid_date, next_due_date, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blockchain_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.blockchain_transactions (id, user_id, wallet_id, chain, transaction_hash, from_address, to_address, value, token_address, token_symbol, gas_used, gas_price, nonce, block_number, status, type, metadata, created_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: blockchain_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.blockchain_wallets (id, user_id, wallet_type, chain_id, network, address, public_key, encrypted_private_key, derivation_path, is_primary, is_imported, custody_type, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bridge_swaps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bridge_swaps (id, swap_id, user_id, from_chain, to_chain, from_token_address, to_token_address, from_amount, to_amount, fee_amount, from_tx_hash, to_tx_hash, status, error_message, metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: business_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.business_rules (id, rule_name, rule_type, entity_type, entity_id, conditions, actions, priority, is_active, created_by, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.businesses (id, organization_id, business_name, business_type, industry, annual_revenue, employee_count, founded_date, description, logo_url, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: charity_donations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.charity_donations (id, user_id, charity_id, amount, currency, is_recurring, recurrence_pattern, transaction_id, receipt_url, tax_receipt_sent, tax_year, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: charity_organizations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.charity_organizations (id, name, ein, category, cause, description, website, logo_url, is_verified, tax_deductible, verification_date, impact_metrics, transparency_score, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: child_parents; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.child_parents (id, parent_id, child_id, relationship, daily_limit, monthly_limit, auto_topup_enabled, auto_topup_threshold, auto_topup_amount, permissions, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_checks; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.compliance_checks (id, user_id, transaction_id, check_type, check_status, risk_score, risk_factors, reviewed_by, notes, metadata, created_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: contract_interactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.contract_interactions (id, contract_id, user_id, function_name, parameters, transaction_hash, gas_used, status, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: custody_configurations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custody_configurations (id, user_id, custody_type, key_shares, threshold, user_shard_encrypted, server_shard_location, recovery_method, recovery_shares, backup_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_credits; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.customer_credits (id, customer_id, organization_id, amount, source_invoice_id, applied_to_invoice_id, status, created_at, applied_at, expires_at) FROM stdin;
\.


--
-- Data for Name: enterprise_ramps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.enterprise_ramps (id, organization_id, type, amount, method, provider, reference_id, bank_account_id, status, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: enterprise_treasuries; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.enterprise_treasuries (id, organization_id, wallet_address, solana_tree_address, tree_capacity, invoices_created, tempo_balance, circle_balance, tempo_wallet_id, circle_wallet_id, total_minted, total_burned, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gift_cards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.gift_cards (id, code, initial_value, current_balance, currency, purchaser_id, recipient_id, recipient_email, is_activated, is_redeemed, expires_at, design_template, personal_message, metadata, created_at, activated_at, redeemed_at) FROM stdin;
\.


--
-- Data for Name: invoice_attachments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_attachments (id, invoice_id, file_name, file_type, file_size, storage_url, ipfs_hash, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_batch_items; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_batch_items (id, batch_id, invoice_id, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_batches; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_batches (id, batch_id, user_id, total_invoices, total_amount, currency, status, blockchain_tx_hash, processed_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_events (id, invoice_id, event_type, event_data, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_line_items (id, invoice_id, line_number, description, quantity, unit_price, tax_rate, tax_amount, discount_rate, discount_amount, line_total, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_payment_methods; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_payment_methods (id, invoice_id, method_type, is_enabled, fee_percentage, fee_fixed, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_payments (id, invoice_id, payer_id, amount, payment_type, provider, transaction_hash, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: invoice_templates; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_templates (id, organization_id, name, description, default_terms, default_notes, line_items_template, tax_rate, is_recurring, recurrence_pattern, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_tokens (id, invoice_id, token_id, chain, tx_hash, from_user_id, to_user_id, amount, currency, description, due_date, ipfs_hash, smart_contract_address, status, paid_at, payment_tx_hash, paid_by_user_id, line_items, metadata, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_wallets (id, invoice_id, wallet_address, blockchain, mode, is_ephemeral, persistence_threshold, auto_sweep_enabled, quantum_resistant, quantum_key_id, quantum_algorithm, status, activated_at, expires_at, swept_at, transaction_count, total_received, total_swept, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoices (id, invoice_number, user_id, organization_id, type, amount, currency, status, client_name, vendor_name, description, payment_method, due_date, paid_date, is_recurring, create_ephemeral_wallet, ephemeral_wallet_created, wallet_mode, metadata, created_at, updated_at, solana_address, recipient_id, paid_amount, invoice_type, metadata_uri, paid_at, last_payment_at) FROM stdin;
\.


--
-- Data for Name: kyc_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.kyc_sessions (id, user_id, provider, session_id, inquiry_id, status, verification_level, risk_score, checks_completed, documents_submitted, rejection_reasons, metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: loyalty_rewards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.loyalty_rewards (id, program_name, program_type, tiers, point_value, earning_rules, redemption_rules, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.loyalty_transactions (id, user_id, reward_program_id, transaction_type, points_earned, points_redeemed, points_balance, reference_transaction_id, description, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: magic_links; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.magic_links (id, user_id, token, email, purpose, used, expires_at, created_at, used_at, ip_address) FROM stdin;
\.


--
-- Data for Name: multi_sig_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.multi_sig_transactions (id, wallet_id, transaction_data, signatures, status, executed_tx_hash, created_by, metadata, created_at, executed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: multi_sig_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.multi_sig_wallets (id, wallet_name, enterprise_id, chain, address, threshold, signers, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: organization_users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.organization_users (id, organization_id, user_id, role, permissions, is_primary, joined_at, invited_by, invitation_status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.organizations (id, org_id, name, legal_name, tax_id, registration_number, parent_id, org_type, path_ids, hierarchy_level, email, phone, website, address_line1, address_line2, city, state, postal_code, country, kyb_status, aml_risk_score, compliance_status, verified, verified_at, erp_customer_id, erp_vendor_id, erp_cost_center, erp_sync_enabled, erp_last_sync, metadata, created_at, updated_at, wallet_type, feature_tier, can_upgrade, upgraded_from_consumer, consumer_limits, parent_organization_id, organization_type, email_verified, phone_verified, mfa_enabled, mfa_methods, type, industry, status, kyc_status, compliance_score, description) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.payment_methods (id, user_id, method_type, card_last_four, card_brand, exp_month, exp_year, bank_name, account_last_four, routing_number, wallet_address, blockchain_network, is_default, is_active, verified, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_requests; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.payment_requests (id, requester_id, payer_id, amount, description, status, qr_code, solana_address, created_at, paid_at, declined_at, decline_reason, expires_at) FROM stdin;
\.


--
-- Data for Name: price_feeds; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.price_feeds (id, token_symbol, base_currency, price, source, confidence, volume_24h, market_cap, metadata, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: quantum_key_registry; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.quantum_key_registry (id, wallet_id, algorithm, public_key, key_hash, lattice_params, security_level, is_active, created_at, rotated_at) FROM stdin;
\.


--
-- Data for Name: ready_cash_loans; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.ready_cash_loans (id, user_id, loan_amount, interest_rate, term_days, total_repayment, amount_paid, next_payment_date, status, approved_at, disbursed_at, fully_paid_at, credit_score, risk_assessment, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recurring_invoice_templates; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.recurring_invoice_templates (id, user_id, template_name, to_user_id, amount, currency, description, frequency, interval_count, next_invoice_date, end_date, is_active, auto_send, auto_charge, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sage_bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_bank_reconciliations (id, account_id, bank_account_id, statement_date, statement_balance, reconciled_balance, difference, status, reconciled_items, outstanding_items, reconciled_by, reconciled_at, created_at) FROM stdin;
\.


--
-- Data for Name: sage_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_connections (id, account_id, company_id, company_name, access_token, refresh_token, token_expiry, subscription_type, region, features, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sage_entities; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_entities (id, account_id, entity_type, sage_id, data, attachments, audit_trail, synced_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: sage_journal_entries; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_journal_entries (id, account_id, journal_id, reference, date, description, total_amount, currency_code, journal_lines, attachments, posted, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: sage_ledger_accounts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_ledger_accounts (id, account_id, ledger_account_id, display_id, nominal_code, name, account_type, category, tax_rate_id, is_control, is_active, balance, currency_code, created_at) FROM stdin;
\.


--
-- Data for Name: sage_sync_queue; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_sync_queue (id, account_id, entity_type, operation, data, priority, status, attempts, max_attempts, error_message, scheduled_at, processed_at) FROM stdin;
\.


--
-- Data for Name: sage_tax_returns; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_tax_returns (id, account_id, return_id, tax_type, period_start, period_end, status, total_sales, total_purchases, tax_due, submission_date, reference_number, created_at) FROM stdin;
\.


--
-- Data for Name: smart_contracts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.smart_contracts (id, owner_id, contract_name, contract_type, chain, address, abi, bytecode, source_code, compiler_version, optimization_enabled, is_verified, is_upgradeable, solana_program_type, metadata, deployed_at, created_at) FROM stdin;
\.


--
-- Data for Name: split_bill_participants; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.split_bill_participants (id, split_bill_id, user_id, email, phone, name, amount_owed, amount_paid, payment_status, payment_date, transaction_id, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: split_bills; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.split_bills (id, creator_id, title, total_amount, currency, split_method, custom_splits, status, settled_at, category, description, receipt_url, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sso_providers (id, provider_name, provider_type, client_id, client_secret_encrypted, authorization_url, token_url, user_info_url, jwks_url, scopes, metadata, is_active, created_at, updated_at) FROM stdin;
df1bb1ef-d62c-4816-b4b8-4ef3071a4487	google	oauth2	\N	\N	https://accounts.google.com/o/oauth2/v2/auth	https://oauth2.googleapis.com/token	https://www.googleapis.com/oauth2/v2/userinfo	\N	{openid,email,profile}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
9102507f-f20b-41a5-9b87-85186c49be23	apple	oauth2	\N	\N	https://appleid.apple.com/auth/authorize	https://appleid.apple.com/auth/token	\N	\N	{name,email}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
91fb7f51-736f-4b47-9649-a12ca66296d8	microsoft	oauth2	\N	\N	https://login.microsoftonline.com/common/oauth2/v2.0/authorize	https://login.microsoftonline.com/common/oauth2/v2.0/token	https://graph.microsoft.com/v1.0/me	\N	{openid,email,profile}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
\.


--
-- Data for Name: super_app_bookings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.super_app_bookings (id, user_id, booking_type, service_provider, booking_reference, booking_date, service_date, total_amount, currency, payment_status, booking_details, status, cancellation_policy, cancelled_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_audit_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_audit_logs (id, tenant_id, user_id, action, resource_type, resource_id, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_billing; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_billing (id, tenant_id, billing_period_start, billing_period_end, subscription_fee, transaction_fees, api_usage_fees, storage_fees, total_amount, status, invoice_url, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_settings (id, tenant_id, setting_key, setting_value, setting_type, is_encrypted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_transactions (id, tenant_id, wallet_id, transaction_type, amount, currency, status, external_reference, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_users (id, tenant_id, user_id, role, permissions, is_primary, status, joined_at, removed_at) FROM stdin;
\.


--
-- Data for Name: tenant_vault_keys; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_vault_keys (id, tenant_id, key_type, public_key, encrypted_private_key, key_metadata, rotation_date, expiration_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_wallets (id, tenant_id, wallet_type, currency, balance, available_balance, pending_balance, blockchain_address, circle_wallet_id, tempo_wallet_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenants (id, tenant_code, name, type, isolation_level, billing_tier, metadata, wallet_derivation_path, status, gross_margin_percent, subscription_expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tillipay_cards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tillipay_cards (id, user_id, tillipay_card_id, card_number_masked, card_type, card_network, card_status, expiry_month, expiry_year, billing_address, spending_limits, metadata, created_at, activated_at, deactivated_at) FROM stdin;
\.


--
-- Data for Name: tillipay_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tillipay_transactions (id, card_id, tillipay_tx_id, transaction_type, amount, currency, merchant_name, merchant_category, status, authorization_code, decline_reason, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tokens (id, enterprise_id, token_name, token_symbol, token_type, chain, contract_address, mint_address, decimals, total_supply, max_supply, is_paused, is_compliant, compliance_standard, stablecoin_type, stablecoin_peg, asset_type, metadata, created_at, updated_at, deployed_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.transactions (id, user_id, wallet_id, type, amount, currency, from_address, to_address, from_user_id, to_user_id, blockchain_network, transaction_hash, block_number, gas_used, gas_price, status, status_message, compliance_checked, compliance_status, risk_score, metadata, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: treasury_accounts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_accounts (id, enterprise_id, account_name, chain, address, balance, locked_balance, reserve_ratio, account_type, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: treasury_swaps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_swaps (id, organization_id, amount, from_provider, to_provider, from_balance_before, from_balance_after, to_balance_before, to_balance_after, swap_reason, transaction_hash, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: treasury_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_transactions (id, treasury_account_id, transaction_type, amount, token_id, from_address, to_address, blockchain_tx_id, status, executed_by, metadata, created_at, executed_at) FROM stdin;
\.


--
-- Data for Name: user_biometrics; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_biometrics (id, user_id, device_id, biometric_type, biometric_hash, salt, algorithm, is_active, enrolled_at, last_verified_at, failed_attempts, locked_until) FROM stdin;
\.


--
-- Data for Name: user_devices_enhanced; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_devices_enhanced (id, user_id, device_id, device_name, device_type, device_model, os_version, app_version, push_token, biometric_enabled, biometric_type, device_fingerprint, trust_level, is_trusted, last_seen, created_at, blocked_at, blocked_reason) FROM stdin;
\.


--
-- Data for Name: user_mfa_settings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_mfa_settings (id, user_id, mfa_type, is_primary, is_enabled, secret_encrypted, phone_number, email, backup_codes, last_used_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_profiles (id, user_id, profile_type, date_of_birth, ssn_last_four, personal_address, emergency_contact, job_title, department, employee_id, business_email, business_phone, profile_picture_url, preferences, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sso_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_sso_connections (id, user_id, provider_id, external_user_id, access_token_encrypted, refresh_token_encrypted, token_expires_at, profile_data, last_login_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.users (id, email, username, first_name, last_name, phone, password_hash, profile_image, date_of_birth, auth_level, require_mfa, mfa_grace_period_until, biometric_enabled, custody_type, risk_profile, last_risk_assessment, passwordless_enabled, recovery_email, recovery_phone, security_questions, trusted_ips, allowed_countries, blocked_countries, failed_login_attempts, last_failed_login, account_locked_until, password_changed_at, password_history, session_timeout_minutes, is_verified, is_active, kyc_verified, kyc_level, metadata, created_at, updated_at, last_login, user_type, primary_organization_id) FROM stdin;
user-cd06a4f0-b5fd-4c33-b0a2-79a518d62567	test@monay.com	testuser	Test	User	\N	$2a$06$zNOUyI7ox4Q.cxvXx82jrOnHBu7qIBBGdgXdkOiulO7Ks2FEYPgaW	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:01:08.473516-04	\N	30	t	t	f	\N	{}	2025-09-23 08:01:08.473516-04	2025-09-23 08:01:08.473516-04	\N	individual	\N
admin-88da2d60-98f1-4161-9329-f51e340f8248	admin@monay.com	admin	Admin	User	\N	$2a$06$iBHrIdyrlDI02Uqyi8XkqusSV4.pRy2XVuFRKBvjBtEV76xObzYK2	\N	\N	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:02:32.642268-04	\N	30	t	t	t	\N	{}	2025-09-23 08:02:32.642268-04	2025-09-23 08:02:32.642268-04	\N	individual	\N
enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	enterprise@monay.com	enterprise	Enterprise	Admin	\N	$2a$06$AWmU.2SDQQ9q1p90XdXeGeHgeP.Uv3aLYRUnj8vOOuHGvAaUm2DlS	\N	\N	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:09:44.670034-04	\N	30	t	t	t	\N	{}	2025-09-23 08:09:44.670034-04	2025-09-23 08:09:44.670034-04	\N	individual	\N
\.


--
-- Data for Name: wallet_lifecycle_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_lifecycle_events (id, wallet_id, event_type, event_data, blockchain_tx_hash, created_at) FROM stdin;
\.


--
-- Data for Name: wallet_mode_decisions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_mode_decisions (id, wallet_id, decision_type, from_mode, to_mode, confidence_score, factors, created_at) FROM stdin;
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallets (id, user_id, organization_id, wallet_name, wallet_type, wallet_address, public_key, blockchain, chain_id, is_smart_wallet, contract_address, balance, locked_balance, kyc_status, aml_verified, sanctions_checked, is_active, is_primary, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.webauthn_credentials (id, user_id, credential_id, public_key, counter, device_type, name, transports, backup_eligible, backup_state, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: zk_compliance_proofs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zk_compliance_proofs (id, wallet_id, proof_type, proof_data, verification_key, is_valid, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_automation_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_automation_rules (id, account_id, rule_name, trigger_type, conditions, actions, enabled, priority, last_triggered, execution_count, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_connections (id, organization_id, account_id, organization_name, access_token, refresh_token, token_expiry, scope, region, features, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zoho_entities; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_entities (id, account_id, entity_type, entity_id, data, custom_fields, tags, attachments, synced_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zoho_recurring_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_recurring_profiles (id, account_id, profile_id, profile_type, customer_id, frequency, start_date, end_date, next_invoice_date, total_amount, currency_code, status, line_items, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_sync_history; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_sync_history (id, account_id, entity_type, sync_type, status, records_synced, errors, started_at, completed_at, error_details, metadata) FROM stdin;
\.


--
-- Data for Name: zoho_tax_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_tax_rules (id, account_id, tax_id, tax_name, tax_percentage, tax_type, is_compound, is_inclusive, region_codes, product_categories, exemptions, created_at) FROM stdin;
\.


--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_attachments_id_seq', 1, false);


--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_batch_items_id_seq', 1, false);


--
-- Name: invoice_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_batches_id_seq', 1, false);


--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_payment_methods_id_seq', 1, false);


--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_tokens_id_seq', 1, false);


--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.recurring_invoice_templates_id_seq', 1, false);


--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_bank_reconciliations_id_seq', 1, false);


--
-- Name: sage_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_connections_id_seq', 1, false);


--
-- Name: sage_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_entities_id_seq', 1, false);


--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_journal_entries_id_seq', 1, false);


--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_ledger_accounts_id_seq', 1, false);


--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_sync_queue_id_seq', 1, false);


--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_tax_returns_id_seq', 1, false);


--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_automation_rules_id_seq', 1, false);


--
-- Name: zoho_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_connections_id_seq', 1, false);


--
-- Name: zoho_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_entities_id_seq', 1, false);


--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_recurring_profiles_id_seq', 1, false);


--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_sync_history_id_seq', 1, false);


--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_tax_rules_id_seq', 1, false);


--
-- Name: ai_financial_insights ai_financial_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ai_financial_insights
    ADD CONSTRAINT ai_financial_insights_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_log auth_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_user_key_challenge_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_key_challenge_type_key UNIQUE (user_key, challenge_type);


--
-- Name: auth_risk_analysis auth_risk_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: auth_sessions auth_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_session_token_key UNIQUE (session_token);


--
-- Name: auto_topup_rules auto_topup_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_pkey PRIMARY KEY (id);


--
-- Name: bill_payments bill_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_pkey PRIMARY KEY (id);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_transaction_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_transaction_hash_key UNIQUE (transaction_hash);


--
-- Name: blockchain_wallets blockchain_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_pkey PRIMARY KEY (id);


--
-- Name: blockchain_wallets blockchain_wallets_user_id_address_wallet_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_user_id_address_wallet_type_key UNIQUE (user_id, address, wallet_type);


--
-- Name: bridge_swaps bridge_swaps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_pkey PRIMARY KEY (id);


--
-- Name: bridge_swaps bridge_swaps_swap_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_swap_id_key UNIQUE (swap_id);


--
-- Name: business_rules business_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.business_rules
    ADD CONSTRAINT business_rules_pkey PRIMARY KEY (id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (id);


--
-- Name: charity_donations charity_donations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_pkey PRIMARY KEY (id);


--
-- Name: charity_organizations charity_organizations_ein_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_organizations
    ADD CONSTRAINT charity_organizations_ein_key UNIQUE (ein);


--
-- Name: charity_organizations charity_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_organizations
    ADD CONSTRAINT charity_organizations_pkey PRIMARY KEY (id);


--
-- Name: child_parents child_parents_parent_id_child_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_parent_id_child_id_key UNIQUE (parent_id, child_id);


--
-- Name: child_parents child_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_pkey PRIMARY KEY (id);


--
-- Name: compliance_checks compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: contract_interactions contract_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_pkey PRIMARY KEY (id);


--
-- Name: custody_configurations custody_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_pkey PRIMARY KEY (id);


--
-- Name: custody_configurations custody_configurations_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_user_id_key UNIQUE (user_id);


--
-- Name: customer_credits customer_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_pkey PRIMARY KEY (id);


--
-- Name: enterprise_ramps enterprise_ramps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_ramps
    ADD CONSTRAINT enterprise_ramps_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries enterprise_treasuries_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries enterprise_treasuries_solana_tree_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_solana_tree_address_key UNIQUE (solana_tree_address);


--
-- Name: gift_cards gift_cards_code_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_code_key UNIQUE (code);


--
-- Name: gift_cards gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_pkey PRIMARY KEY (id);


--
-- Name: invoice_attachments invoice_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments
    ADD CONSTRAINT invoice_attachments_pkey PRIMARY KEY (id);


--
-- Name: invoice_batch_items invoice_batch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_batches invoice_batches_batch_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_batch_id_key UNIQUE (batch_id);


--
-- Name: invoice_batches invoice_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_pkey PRIMARY KEY (id);


--
-- Name: invoice_events invoice_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_payment_methods invoice_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods
    ADD CONSTRAINT invoice_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoice_templates invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: invoice_tokens invoice_tokens_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_invoice_id_key UNIQUE (invoice_id);


--
-- Name: invoice_tokens invoice_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_pkey PRIMARY KEY (id);


--
-- Name: invoice_wallets invoice_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_solana_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_solana_address_key UNIQUE (solana_address);


--
-- Name: kyc_sessions kyc_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.kyc_sessions
    ADD CONSTRAINT kyc_sessions_pkey PRIMARY KEY (id);


--
-- Name: loyalty_rewards loyalty_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_rewards
    ADD CONSTRAINT loyalty_rewards_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_token_key UNIQUE (token);


--
-- Name: multi_sig_transactions multi_sig_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_pkey PRIMARY KEY (id);


--
-- Name: multi_sig_wallets multi_sig_wallets_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_chain_address_key UNIQUE (chain, address);


--
-- Name: multi_sig_wallets multi_sig_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_pkey PRIMARY KEY (id);


--
-- Name: organization_users organization_users_organization_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_user_id_key UNIQUE (organization_id, user_id);


--
-- Name: organization_users organization_users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_org_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_org_id_key UNIQUE (org_id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_solana_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_solana_address_key UNIQUE (solana_address);


--
-- Name: price_feeds price_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.price_feeds
    ADD CONSTRAINT price_feeds_pkey PRIMARY KEY (id);


--
-- Name: quantum_key_registry quantum_key_registry_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_key_hash_key UNIQUE (key_hash);


--
-- Name: quantum_key_registry quantum_key_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_pkey PRIMARY KEY (id);


--
-- Name: ready_cash_loans ready_cash_loans_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ready_cash_loans
    ADD CONSTRAINT ready_cash_loans_pkey PRIMARY KEY (id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: sage_bank_reconciliations sage_bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations
    ADD CONSTRAINT sage_bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: sage_connections sage_connections_account_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections
    ADD CONSTRAINT sage_connections_account_id_key UNIQUE (account_id);


--
-- Name: sage_connections sage_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections
    ADD CONSTRAINT sage_connections_pkey PRIMARY KEY (id);


--
-- Name: sage_entities sage_entities_account_id_entity_type_sage_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_account_id_entity_type_sage_id_key UNIQUE (account_id, entity_type, sage_id);


--
-- Name: sage_entities sage_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_pkey PRIMARY KEY (id);


--
-- Name: sage_journal_entries sage_journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries
    ADD CONSTRAINT sage_journal_entries_pkey PRIMARY KEY (id);


--
-- Name: sage_ledger_accounts sage_ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts
    ADD CONSTRAINT sage_ledger_accounts_pkey PRIMARY KEY (id);


--
-- Name: sage_sync_queue sage_sync_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue
    ADD CONSTRAINT sage_sync_queue_pkey PRIMARY KEY (id);


--
-- Name: sage_tax_returns sage_tax_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns
    ADD CONSTRAINT sage_tax_returns_pkey PRIMARY KEY (id);


--
-- Name: smart_contracts smart_contracts_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_chain_address_key UNIQUE (chain, address);


--
-- Name: smart_contracts smart_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_pkey PRIMARY KEY (id);


--
-- Name: split_bill_participants split_bill_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_pkey PRIMARY KEY (id);


--
-- Name: split_bills split_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bills
    ADD CONSTRAINT split_bills_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_provider_name_key UNIQUE (provider_name);


--
-- Name: super_app_bookings super_app_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.super_app_bookings
    ADD CONSTRAINT super_app_bookings_pkey PRIMARY KEY (id);


--
-- Name: tenant_audit_logs tenant_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_billing tenant_billing_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_billing
    ADD CONSTRAINT tenant_billing_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_tenant_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_setting_key_key UNIQUE (tenant_id, setting_key);


--
-- Name: tenant_transactions tenant_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_tenant_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_tenant_id_user_id_key UNIQUE (tenant_id, user_id);


--
-- Name: tenant_vault_keys tenant_vault_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_vault_keys
    ADD CONSTRAINT tenant_vault_keys_pkey PRIMARY KEY (id);


--
-- Name: tenant_wallets tenant_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_tenant_code_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_tenant_code_key UNIQUE (tenant_code);


--
-- Name: tillipay_cards tillipay_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_pkey PRIMARY KEY (id);


--
-- Name: tillipay_cards tillipay_cards_tillipay_card_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_tillipay_card_id_key UNIQUE (tillipay_card_id);


--
-- Name: tillipay_transactions tillipay_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_pkey PRIMARY KEY (id);


--
-- Name: tillipay_transactions tillipay_transactions_tillipay_tx_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_tillipay_tx_id_key UNIQUE (tillipay_tx_id);


--
-- Name: tokens tokens_chain_contract_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_chain_contract_address_key UNIQUE (chain, contract_address);


--
-- Name: tokens tokens_chain_mint_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_chain_mint_address_key UNIQUE (chain, mint_address);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_accounts treasury_accounts_enterprise_id_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_enterprise_id_chain_address_key UNIQUE (enterprise_id, chain, address);


--
-- Name: treasury_accounts treasury_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_pkey PRIMARY KEY (id);


--
-- Name: treasury_swaps treasury_swaps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_swaps
    ADD CONSTRAINT treasury_swaps_pkey PRIMARY KEY (id);


--
-- Name: treasury_transactions treasury_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries uniq_organization_treasury; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT uniq_organization_treasury UNIQUE (organization_id);


--
-- Name: user_biometrics user_biometrics_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_pkey PRIMARY KEY (id);


--
-- Name: user_biometrics user_biometrics_user_id_device_id_biometric_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_user_id_device_id_biometric_type_key UNIQUE (user_id, device_id, biometric_type);


--
-- Name: user_devices_enhanced user_devices_enhanced_device_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_device_id_key UNIQUE (device_id);


--
-- Name: user_devices_enhanced user_devices_enhanced_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_settings user_mfa_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_settings user_mfa_settings_user_id_mfa_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_user_id_mfa_type_key UNIQUE (user_id, mfa_type);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_key UNIQUE (user_id);


--
-- Name: user_sso_connections user_sso_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_pkey PRIMARY KEY (id);


--
-- Name: user_sso_connections user_sso_connections_provider_id_external_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_external_user_id_key UNIQUE (provider_id, external_user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_pkey PRIMARY KEY (id);


--
-- Name: wallet_mode_decisions wallet_mode_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_mode_decisions
    ADD CONSTRAINT wallet_mode_decisions_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: zk_compliance_proofs zk_compliance_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_pkey PRIMARY KEY (id);


--
-- Name: zoho_automation_rules zoho_automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules
    ADD CONSTRAINT zoho_automation_rules_pkey PRIMARY KEY (id);


--
-- Name: zoho_connections zoho_connections_account_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections
    ADD CONSTRAINT zoho_connections_account_id_key UNIQUE (account_id);


--
-- Name: zoho_connections zoho_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections
    ADD CONSTRAINT zoho_connections_pkey PRIMARY KEY (id);


--
-- Name: zoho_entities zoho_entities_account_id_entity_type_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_account_id_entity_type_entity_id_key UNIQUE (account_id, entity_type, entity_id);


--
-- Name: zoho_entities zoho_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_pkey PRIMARY KEY (id);


--
-- Name: zoho_recurring_profiles zoho_recurring_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles
    ADD CONSTRAINT zoho_recurring_profiles_pkey PRIMARY KEY (id);


--
-- Name: zoho_sync_history zoho_sync_history_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history
    ADD CONSTRAINT zoho_sync_history_pkey PRIMARY KEY (id);


--
-- Name: zoho_tax_rules zoho_tax_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules
    ADD CONSTRAINT zoho_tax_rules_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_insights_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_ai_insights_type ON public.ai_financial_insights USING btree (insight_type);


--
-- Name: idx_ai_insights_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_ai_insights_user ON public.ai_financial_insights USING btree (user_id);


--
-- Name: idx_api_keys_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_active ON public.api_keys USING btree (is_active, expires_at);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_audit_logs_actor; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_actor ON public.audit_logs USING btree (actor_id);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_timestamp ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_auth_audit_event; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_event ON public.auth_audit_log USING btree (event_type);


--
-- Name: idx_auth_audit_success; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_success ON public.auth_audit_log USING btree (success, created_at DESC);


--
-- Name: idx_auth_audit_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_timestamp ON public.auth_audit_log USING btree (created_at DESC);


--
-- Name: idx_auth_audit_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_user ON public.auth_audit_log USING btree (user_id);


--
-- Name: idx_auth_challenges_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_challenges_expires ON public.auth_challenges USING btree (expires_at);


--
-- Name: idx_auth_challenges_user_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_challenges_user_type ON public.auth_challenges USING btree (user_key, challenge_type);


--
-- Name: idx_auth_sessions_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_active ON public.auth_sessions USING btree (is_active, expires_at);


--
-- Name: idx_auth_sessions_refresh; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_refresh ON public.auth_sessions USING btree (refresh_token);


--
-- Name: idx_auth_sessions_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_token ON public.auth_sessions USING btree (session_token);


--
-- Name: idx_auth_sessions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_user ON public.auth_sessions USING btree (user_id);


--
-- Name: idx_auto_topup_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auto_topup_user ON public.auto_topup_rules USING btree (user_id);


--
-- Name: idx_auto_topup_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auto_topup_wallet ON public.auto_topup_rules USING btree (wallet_id);


--
-- Name: idx_bill_payments_bill; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bill_payments_bill ON public.bill_payments USING btree (bill_id);


--
-- Name: idx_bill_payments_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bill_payments_user ON public.bill_payments USING btree (user_id);


--
-- Name: idx_bills_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bills_due_date ON public.bills USING btree (due_date);


--
-- Name: idx_bills_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bills_user ON public.bills USING btree (user_id);


--
-- Name: idx_blockchain_tx_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_hash ON public.blockchain_transactions USING btree (transaction_hash);


--
-- Name: idx_blockchain_tx_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_user ON public.blockchain_transactions USING btree (user_id);


--
-- Name: idx_blockchain_tx_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_wallet ON public.blockchain_transactions USING btree (wallet_id);


--
-- Name: idx_blockchain_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_wallets_address ON public.blockchain_wallets USING btree (address);


--
-- Name: idx_blockchain_wallets_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_wallets_user ON public.blockchain_wallets USING btree (user_id);


--
-- Name: idx_bookings_service_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_service_date ON public.super_app_bookings USING btree (service_date);


--
-- Name: idx_bookings_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_type ON public.super_app_bookings USING btree (booking_type);


--
-- Name: idx_bookings_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_user ON public.super_app_bookings USING btree (user_id);


--
-- Name: idx_bridge_swaps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bridge_swaps_status ON public.bridge_swaps USING btree (status);


--
-- Name: idx_bridge_swaps_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bridge_swaps_user ON public.bridge_swaps USING btree (user_id);


--
-- Name: idx_business_rules_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_business_rules_entity ON public.business_rules USING btree (entity_type, entity_id);


--
-- Name: idx_business_rules_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_business_rules_type ON public.business_rules USING btree (rule_type);


--
-- Name: idx_businesses_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_businesses_org ON public.businesses USING btree (organization_id);


--
-- Name: idx_cash_loans_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_cash_loans_status ON public.ready_cash_loans USING btree (status);


--
-- Name: idx_cash_loans_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_cash_loans_user ON public.ready_cash_loans USING btree (user_id);


--
-- Name: idx_charity_orgs_category; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_charity_orgs_category ON public.charity_organizations USING btree (category);


--
-- Name: idx_child_parents_child; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_child_parents_child ON public.child_parents USING btree (child_id);


--
-- Name: idx_child_parents_parent; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_child_parents_parent ON public.child_parents USING btree (parent_id);


--
-- Name: idx_compliance_checks_tx; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_checks_tx ON public.compliance_checks USING btree (transaction_id);


--
-- Name: idx_compliance_checks_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_checks_user ON public.compliance_checks USING btree (user_id);


--
-- Name: idx_contract_interactions_contract; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_contract_interactions_contract ON public.contract_interactions USING btree (contract_id);


--
-- Name: idx_contract_interactions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_contract_interactions_user ON public.contract_interactions USING btree (user_id);


--
-- Name: idx_custody_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custody_type ON public.custody_configurations USING btree (custody_type);


--
-- Name: idx_custody_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custody_user ON public.custody_configurations USING btree (user_id);


--
-- Name: idx_customer_credits_customer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_customer ON public.customer_credits USING btree (customer_id);


--
-- Name: idx_customer_credits_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_organization ON public.customer_credits USING btree (organization_id);


--
-- Name: idx_customer_credits_source; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_source ON public.customer_credits USING btree (source_invoice_id);


--
-- Name: idx_customer_credits_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_status ON public.customer_credits USING btree (status);


--
-- Name: idx_donations_charity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_donations_charity ON public.charity_donations USING btree (charity_id);


--
-- Name: idx_donations_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_donations_user ON public.charity_donations USING btree (user_id);


--
-- Name: idx_enterprise_ramps_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_created ON public.enterprise_ramps USING btree (created_at);


--
-- Name: idx_enterprise_ramps_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_organization ON public.enterprise_ramps USING btree (organization_id);


--
-- Name: idx_enterprise_ramps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_status ON public.enterprise_ramps USING btree (status);


--
-- Name: idx_enterprise_ramps_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_type ON public.enterprise_ramps USING btree (type);


--
-- Name: idx_enterprise_treasuries_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_treasuries_organization ON public.enterprise_treasuries USING btree (organization_id);


--
-- Name: idx_enterprise_treasuries_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_treasuries_status ON public.enterprise_treasuries USING btree (status);


--
-- Name: idx_gift_cards_code; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_code ON public.gift_cards USING btree (code);


--
-- Name: idx_gift_cards_purchaser; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_purchaser ON public.gift_cards USING btree (purchaser_id);


--
-- Name: idx_gift_cards_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_recipient ON public.gift_cards USING btree (recipient_id);


--
-- Name: idx_invoice_events_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_created ON public.invoice_events USING btree (created_at);


--
-- Name: idx_invoice_events_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_created_at ON public.invoice_events USING btree (created_at);


--
-- Name: idx_invoice_events_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_invoice ON public.invoice_events USING btree (invoice_id);


--
-- Name: idx_invoice_events_invoice_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_invoice_id ON public.invoice_events USING btree (invoice_id);


--
-- Name: idx_invoice_events_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_type ON public.invoice_events USING btree (event_type);


--
-- Name: idx_invoice_items_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_items_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_invoice_line_items_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_line_items_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_invoice_payments_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_created ON public.invoice_payments USING btree (created_at);


--
-- Name: idx_invoice_payments_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_invoice ON public.invoice_payments USING btree (invoice_id);


--
-- Name: idx_invoice_payments_payer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_payer ON public.invoice_payments USING btree (payer_id);


--
-- Name: idx_invoice_payments_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_status ON public.invoice_payments USING btree (status);


--
-- Name: idx_invoice_templates_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_templates_active ON public.invoice_templates USING btree (is_active);


--
-- Name: idx_invoice_templates_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_templates_organization ON public.invoice_templates USING btree (organization_id);


--
-- Name: idx_invoice_tokens_chain; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_chain ON public.invoice_tokens USING btree (chain);


--
-- Name: idx_invoice_tokens_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_created_at ON public.invoice_tokens USING btree (created_at);


--
-- Name: idx_invoice_tokens_description; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_description ON public.invoice_tokens USING gin (to_tsvector('english'::regconfig, description));


--
-- Name: idx_invoice_tokens_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_due_date ON public.invoice_tokens USING btree (due_date);


--
-- Name: idx_invoice_tokens_from_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_from_user ON public.invoice_tokens USING btree (from_user_id);


--
-- Name: idx_invoice_tokens_line_items; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_line_items ON public.invoice_tokens USING gin (line_items);


--
-- Name: idx_invoice_tokens_metadata; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_metadata ON public.invoice_tokens USING gin (metadata);


--
-- Name: idx_invoice_tokens_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_status ON public.invoice_tokens USING btree (status);


--
-- Name: idx_invoice_tokens_to_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_to_user ON public.invoice_tokens USING btree (to_user_id);


--
-- Name: idx_invoice_tokens_token_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_token_id ON public.invoice_tokens USING btree (token_id);


--
-- Name: idx_invoice_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_address ON public.invoice_wallets USING btree (wallet_address);


--
-- Name: idx_invoice_wallets_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_invoice ON public.invoice_wallets USING btree (invoice_id);


--
-- Name: idx_invoice_wallets_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_status ON public.invoice_wallets USING btree (status);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_organization ON public.invoices USING btree (organization_id);


--
-- Name: idx_invoices_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_recipient ON public.invoices USING btree (recipient_id);


--
-- Name: idx_invoices_solana_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_solana_address ON public.invoices USING btree (solana_address);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status);


--
-- Name: idx_invoices_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_user ON public.invoices USING btree (user_id);


--
-- Name: idx_kyc_sessions_provider; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_kyc_sessions_provider ON public.kyc_sessions USING btree (provider, session_id);


--
-- Name: idx_kyc_sessions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_kyc_sessions_user ON public.kyc_sessions USING btree (user_id);


--
-- Name: idx_loyalty_tx_program; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_loyalty_tx_program ON public.loyalty_transactions USING btree (reward_program_id);


--
-- Name: idx_loyalty_tx_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_loyalty_tx_user ON public.loyalty_transactions USING btree (user_id);


--
-- Name: idx_magic_links_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_expires ON public.magic_links USING btree (expires_at);


--
-- Name: idx_magic_links_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_token ON public.magic_links USING btree (token);


--
-- Name: idx_magic_links_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_user ON public.magic_links USING btree (user_id);


--
-- Name: idx_mode_decisions_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_wallet ON public.wallet_mode_decisions USING btree (wallet_id);


--
-- Name: idx_multi_sig_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_multi_sig_enterprise ON public.multi_sig_wallets USING btree (enterprise_id);


--
-- Name: idx_multi_sig_tx_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_multi_sig_tx_wallet ON public.multi_sig_transactions USING btree (wallet_id);


--
-- Name: idx_org_users_org_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_org_id ON public.organization_users USING btree (organization_id);


--
-- Name: idx_org_users_role; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_role ON public.organization_users USING btree (role);


--
-- Name: idx_org_users_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_status ON public.organization_users USING btree (invitation_status);


--
-- Name: idx_org_users_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_user_id ON public.organization_users USING btree (user_id);


--
-- Name: idx_organizations_feature_tier; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_feature_tier ON public.organizations USING btree (feature_tier);


--
-- Name: idx_organizations_kyc_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_kyc_status ON public.organizations USING btree (kyc_status);


--
-- Name: idx_organizations_parent; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_parent ON public.organizations USING btree (parent_id);


--
-- Name: idx_organizations_path; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_path ON public.organizations USING gin (path_ids);


--
-- Name: idx_organizations_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_status ON public.organizations USING btree (status);


--
-- Name: idx_organizations_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_type ON public.organizations USING btree (org_type);


--
-- Name: idx_organizations_wallet_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_wallet_type ON public.organizations USING btree (wallet_type);


--
-- Name: idx_payment_methods_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_methods_user ON public.payment_methods USING btree (user_id);


--
-- Name: idx_payment_requests_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_created ON public.payment_requests USING btree (created_at);


--
-- Name: idx_payment_requests_payer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_payer ON public.payment_requests USING btree (payer_id);


--
-- Name: idx_payment_requests_requester; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_requester ON public.payment_requests USING btree (requester_id);


--
-- Name: idx_payment_requests_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_status ON public.payment_requests USING btree (status);


--
-- Name: idx_price_feeds_symbol; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_price_feeds_symbol ON public.price_feeds USING btree (token_symbol, base_currency);


--
-- Name: idx_price_feeds_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_price_feeds_timestamp ON public.price_feeds USING btree ("timestamp" DESC);


--
-- Name: idx_quantum_keys_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_quantum_keys_wallet ON public.quantum_key_registry USING btree (wallet_id);


--
-- Name: idx_recurring_templates_next_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recurring_templates_next_date ON public.recurring_invoice_templates USING btree (next_invoice_date);


--
-- Name: idx_recurring_templates_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recurring_templates_user ON public.recurring_invoice_templates USING btree (user_id);


--
-- Name: idx_risk_analysis_session; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_session ON public.auth_risk_analysis USING btree (session_id);


--
-- Name: idx_risk_analysis_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_timestamp ON public.auth_risk_analysis USING btree (analyzed_at DESC);


--
-- Name: idx_risk_analysis_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_user ON public.auth_risk_analysis USING btree (user_id);


--
-- Name: idx_sage_entities_lookup; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_entities_lookup ON public.sage_entities USING btree (account_id, entity_type, sage_id);


--
-- Name: idx_sage_ledger_nominal; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_ledger_nominal ON public.sage_ledger_accounts USING btree (account_id, nominal_code);


--
-- Name: idx_sage_sync_queue_pending; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_sync_queue_pending ON public.sage_sync_queue USING btree (account_id, status, priority DESC);


--
-- Name: idx_smart_contracts_owner; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_smart_contracts_owner ON public.smart_contracts USING btree (owner_id);


--
-- Name: idx_split_bills_creator; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_bills_creator ON public.split_bills USING btree (creator_id);


--
-- Name: idx_split_participants_bill; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_participants_bill ON public.split_bill_participants USING btree (split_bill_id);


--
-- Name: idx_split_participants_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_participants_user ON public.split_bill_participants USING btree (user_id);


--
-- Name: idx_sso_providers_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sso_providers_active ON public.sso_providers USING btree (is_active);


--
-- Name: idx_sso_providers_name; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sso_providers_name ON public.sso_providers USING btree (provider_name);


--
-- Name: idx_tenant_audit_logs_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_audit_logs_created_at ON public.tenant_audit_logs USING btree (created_at);


--
-- Name: idx_tenant_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_audit_logs_tenant_id ON public.tenant_audit_logs USING btree (tenant_id);


--
-- Name: idx_tenant_billing_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_billing_tenant_id ON public.tenant_billing USING btree (tenant_id);


--
-- Name: idx_tenant_transactions_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_transactions_created_at ON public.tenant_transactions USING btree (created_at);


--
-- Name: idx_tenant_transactions_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_transactions_tenant_id ON public.tenant_transactions USING btree (tenant_id);


--
-- Name: idx_tenant_users_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_tenant_id ON public.tenant_users USING btree (tenant_id);


--
-- Name: idx_tenant_users_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_user_id ON public.tenant_users USING btree (user_id);


--
-- Name: idx_tenant_wallets_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_wallets_tenant_id ON public.tenant_wallets USING btree (tenant_id);


--
-- Name: idx_tenants_code; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_code ON public.tenants USING btree (tenant_code);


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status);


--
-- Name: idx_tenants_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_type ON public.tenants USING btree (type);


--
-- Name: idx_tillipay_cards_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tillipay_cards_user ON public.tillipay_cards USING btree (user_id);


--
-- Name: idx_tillipay_tx_card; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tillipay_tx_card ON public.tillipay_transactions USING btree (card_id);


--
-- Name: idx_tokens_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tokens_enterprise ON public.tokens USING btree (enterprise_id);


--
-- Name: idx_tokens_symbol; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tokens_symbol ON public.tokens USING btree (token_symbol);


--
-- Name: idx_transactions_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_hash ON public.transactions USING btree (transaction_hash);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- Name: idx_transactions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_user ON public.transactions USING btree (user_id);


--
-- Name: idx_transactions_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_wallet ON public.transactions USING btree (wallet_id);


--
-- Name: idx_treasury_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_enterprise ON public.treasury_accounts USING btree (enterprise_id);


--
-- Name: idx_treasury_swaps_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_created ON public.treasury_swaps USING btree (created_at);


--
-- Name: idx_treasury_swaps_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_organization ON public.treasury_swaps USING btree (organization_id);


--
-- Name: idx_treasury_swaps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_status ON public.treasury_swaps USING btree (status);


--
-- Name: idx_treasury_tx_account; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_tx_account ON public.treasury_transactions USING btree (treasury_account_id);


--
-- Name: idx_treasury_tx_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_tx_token ON public.treasury_transactions USING btree (token_id);


--
-- Name: idx_user_biometrics_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_active ON public.user_biometrics USING btree (user_id, is_active);


--
-- Name: idx_user_biometrics_device; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_device ON public.user_biometrics USING btree (device_id);


--
-- Name: idx_user_biometrics_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_user ON public.user_biometrics USING btree (user_id);


--
-- Name: idx_user_devices_enhanced_device; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_device ON public.user_devices_enhanced USING btree (device_id);


--
-- Name: idx_user_devices_enhanced_trusted; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_trusted ON public.user_devices_enhanced USING btree (user_id, is_trusted);


--
-- Name: idx_user_devices_enhanced_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_user ON public.user_devices_enhanced USING btree (user_id);


--
-- Name: idx_user_mfa_enabled; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_mfa_enabled ON public.user_mfa_settings USING btree (user_id, is_enabled);


--
-- Name: idx_user_mfa_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_mfa_user ON public.user_mfa_settings USING btree (user_id);


--
-- Name: idx_user_profiles_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_profiles_type ON public.user_profiles USING btree (profile_type);


--
-- Name: idx_user_profiles_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_profiles_user_id ON public.user_profiles USING btree (user_id);


--
-- Name: idx_user_sso_external; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_external ON public.user_sso_connections USING btree (external_user_id);


--
-- Name: idx_user_sso_provider; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_provider ON public.user_sso_connections USING btree (provider_id);


--
-- Name: idx_user_sso_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_user ON public.user_sso_connections USING btree (user_id);


--
-- Name: idx_users_account_locked; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_account_locked ON public.users USING btree (account_locked_until);


--
-- Name: idx_users_auth_level; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_auth_level ON public.users USING btree (auth_level);


--
-- Name: idx_users_custody_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_custody_type ON public.users USING btree (custody_type);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_primary_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_primary_org ON public.users USING btree (primary_organization_id);


--
-- Name: idx_users_require_mfa; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_require_mfa ON public.users USING btree (require_mfa);


--
-- Name: idx_users_risk_profile; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_risk_profile ON public.users USING btree (risk_profile);


--
-- Name: idx_users_user_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_user_type ON public.users USING btree (user_type);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_wallet_events_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_type ON public.wallet_lifecycle_events USING btree (event_type);


--
-- Name: idx_wallet_events_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_wallet ON public.wallet_lifecycle_events USING btree (wallet_id);


--
-- Name: idx_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_address ON public.wallets USING btree (wallet_address);


--
-- Name: idx_wallets_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_org ON public.wallets USING btree (organization_id);


--
-- Name: idx_wallets_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_user ON public.wallets USING btree (user_id);


--
-- Name: idx_webauthn_credential; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webauthn_credential ON public.webauthn_credentials USING btree (credential_id);


--
-- Name: idx_webauthn_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webauthn_user ON public.webauthn_credentials USING btree (user_id);


--
-- Name: idx_zk_proofs_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zk_proofs_wallet ON public.zk_compliance_proofs USING btree (wallet_id);


--
-- Name: idx_zoho_entities_lookup; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zoho_entities_lookup ON public.zoho_entities USING btree (account_id, entity_type, entity_id);


--
-- Name: idx_zoho_sync_history; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zoho_sync_history ON public.zoho_sync_history USING btree (account_id, entity_type, status);


--
-- Name: users ensure_user_consistency_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER ensure_user_consistency_trigger BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.ensure_user_consistency();


--
-- Name: invoice_tokens invoice_tokens_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER invoice_tokens_updated_at BEFORE UPDATE ON public.invoice_tokens FOR EACH ROW EXECUTE FUNCTION public.update_invoice_updated_at();


--
-- Name: recurring_invoice_templates recurring_templates_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER recurring_templates_updated_at BEFORE UPDATE ON public.recurring_invoice_templates FOR EACH ROW EXECUTE FUNCTION public.update_invoice_updated_at();


--
-- Name: invoice_payments trigger_update_invoice_on_payment; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER trigger_update_invoice_on_payment AFTER INSERT OR UPDATE ON public.invoice_payments FOR EACH ROW EXECUTE FUNCTION public.update_invoice_status_on_payment();


--
-- Name: invoices update_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: organizations update_organizations_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: auth_risk_analysis update_risk_profile_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_risk_profile_trigger AFTER INSERT ON public.auth_risk_analysis FOR EACH ROW EXECUTE FUNCTION public.update_user_risk_profile();


--
-- Name: transactions update_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: wallets update_wallets_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_financial_insights ai_financial_insights_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ai_financial_insights
    ADD CONSTRAINT ai_financial_insights_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: auth_audit_log auth_audit_log_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: auth_audit_log auth_audit_log_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id);


--
-- Name: auth_audit_log auth_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_risk_analysis auth_risk_analysis_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id);


--
-- Name: auth_risk_analysis auth_risk_analysis_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_sessions auth_sessions_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_topup_rules auto_topup_rules_source_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_source_payment_method_id_fkey FOREIGN KEY (source_payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: auto_topup_rules auto_topup_rules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auto_topup_rules auto_topup_rules_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id);


--
-- Name: bill_payments bill_payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(id);


--
-- Name: bill_payments bill_payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: bill_payments bill_payments_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: bill_payments bill_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bills bills_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: bills bills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blockchain_transactions blockchain_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blockchain_transactions blockchain_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.blockchain_wallets(id);


--
-- Name: blockchain_wallets blockchain_wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bridge_swaps bridge_swaps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: business_rules business_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.business_rules
    ADD CONSTRAINT business_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: businesses businesses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: charity_donations charity_donations_charity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_charity_id_fkey FOREIGN KEY (charity_id) REFERENCES public.charity_organizations(id);


--
-- Name: charity_donations charity_donations_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: charity_donations charity_donations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: child_parents child_parents_child_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_child_id_fkey FOREIGN KEY (child_id) REFERENCES public.users(id);


--
-- Name: child_parents child_parents_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.users(id);


--
-- Name: compliance_checks compliance_checks_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: compliance_checks compliance_checks_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: compliance_checks compliance_checks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: contract_interactions contract_interactions_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.smart_contracts(id);


--
-- Name: contract_interactions contract_interactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: custody_configurations custody_configurations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_credits customer_credits_applied_to_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_applied_to_invoice_id_fkey FOREIGN KEY (applied_to_invoice_id) REFERENCES public.invoices(id);


--
-- Name: customer_credits customer_credits_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: customer_credits customer_credits_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: customer_credits customer_credits_source_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_source_invoice_id_fkey FOREIGN KEY (source_invoice_id) REFERENCES public.invoices(id);


--
-- Name: enterprise_ramps enterprise_ramps_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_ramps
    ADD CONSTRAINT enterprise_ramps_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: enterprise_treasuries enterprise_treasuries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gift_cards gift_cards_purchaser_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_purchaser_id_fkey FOREIGN KEY (purchaser_id) REFERENCES public.users(id);


--
-- Name: gift_cards gift_cards_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: invoice_attachments invoice_attachments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments
    ADD CONSTRAINT invoice_attachments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id) ON DELETE CASCADE;


--
-- Name: invoice_batch_items invoice_batch_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.invoice_batches(batch_id) ON DELETE CASCADE;


--
-- Name: invoice_batch_items invoice_batch_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id);


--
-- Name: invoice_batches invoice_batches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: invoice_events invoice_events_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_events invoice_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payment_methods invoice_payment_methods_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods
    ADD CONSTRAINT invoice_payment_methods_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.users(id);


--
-- Name: invoice_templates invoice_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: invoice_tokens invoice_tokens_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id);


--
-- Name: invoice_tokens invoice_tokens_paid_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_paid_by_user_id_fkey FOREIGN KEY (paid_by_user_id) REFERENCES public.users(id);


--
-- Name: invoice_tokens invoice_tokens_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: invoice_wallets invoice_wallets_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: invoices invoices_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: kyc_sessions kyc_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.kyc_sessions
    ADD CONSTRAINT kyc_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: loyalty_transactions loyalty_transactions_reference_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_reference_transaction_id_fkey FOREIGN KEY (reference_transaction_id) REFERENCES public.transactions(id);


--
-- Name: loyalty_transactions loyalty_transactions_reward_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_reward_program_id_fkey FOREIGN KEY (reward_program_id) REFERENCES public.loyalty_rewards(id);


--
-- Name: loyalty_transactions loyalty_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: magic_links magic_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: multi_sig_transactions multi_sig_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: multi_sig_transactions multi_sig_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.multi_sig_wallets(id);


--
-- Name: multi_sig_wallets multi_sig_wallets_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: organization_users organization_users_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: organization_users organization_users_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organizations organizations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.organizations(id);


--
-- Name: organizations organizations_parent_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_parent_organization_id_fkey FOREIGN KEY (parent_organization_id) REFERENCES public.organizations(id);


--
-- Name: payment_methods payment_methods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_requests payment_requests_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.users(id);


--
-- Name: payment_requests payment_requests_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: quantum_key_registry quantum_key_registry_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: ready_cash_loans ready_cash_loans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ready_cash_loans
    ADD CONSTRAINT ready_cash_loans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sage_bank_reconciliations sage_bank_reconciliations_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations
    ADD CONSTRAINT sage_bank_reconciliations_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_entities sage_entities_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_journal_entries sage_journal_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries
    ADD CONSTRAINT sage_journal_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_ledger_accounts sage_ledger_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts
    ADD CONSTRAINT sage_ledger_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_sync_queue sage_sync_queue_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue
    ADD CONSTRAINT sage_sync_queue_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_tax_returns sage_tax_returns_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns
    ADD CONSTRAINT sage_tax_returns_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: smart_contracts smart_contracts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: split_bill_participants split_bill_participants_split_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_split_bill_id_fkey FOREIGN KEY (split_bill_id) REFERENCES public.split_bills(id) ON DELETE CASCADE;


--
-- Name: split_bill_participants split_bill_participants_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: split_bill_participants split_bill_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: split_bills split_bills_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bills
    ADD CONSTRAINT split_bills_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: super_app_bookings super_app_bookings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.super_app_bookings
    ADD CONSTRAINT super_app_bookings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tenant_audit_logs tenant_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_audit_logs tenant_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tenant_billing tenant_billing_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_billing
    ADD CONSTRAINT tenant_billing_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_transactions tenant_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_transactions tenant_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.tenant_wallets(id);


--
-- Name: tenant_users tenant_users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_users tenant_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tenant_vault_keys tenant_vault_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_vault_keys
    ADD CONSTRAINT tenant_vault_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_wallets tenant_wallets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tillipay_cards tillipay_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tillipay_transactions tillipay_transactions_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_card_id_fkey FOREIGN KEY (card_id) REFERENCES public.tillipay_cards(id);


--
-- Name: tokens tokens_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id);


--
-- Name: treasury_accounts treasury_accounts_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: treasury_swaps treasury_swaps_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_swaps
    ADD CONSTRAINT treasury_swaps_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: treasury_transactions treasury_transactions_blockchain_tx_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_blockchain_tx_id_fkey FOREIGN KEY (blockchain_tx_id) REFERENCES public.blockchain_transactions(id);


--
-- Name: treasury_transactions treasury_transactions_executed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_executed_by_fkey FOREIGN KEY (executed_by) REFERENCES public.users(id);


--
-- Name: treasury_transactions treasury_transactions_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.tokens(id);


--
-- Name: treasury_transactions treasury_transactions_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_treasury_account_id_fkey FOREIGN KEY (treasury_account_id) REFERENCES public.treasury_accounts(id);


--
-- Name: user_biometrics user_biometrics_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: user_biometrics user_biometrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_devices_enhanced user_devices_enhanced_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_mfa_settings user_mfa_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sso_connections user_sso_connections_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.sso_providers(id);


--
-- Name: user_sso_connections user_sso_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_primary_organization_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_organization_fkey FOREIGN KEY (primary_organization_id) REFERENCES public.organizations(id);


--
-- Name: users users_primary_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_organization_id_fkey FOREIGN KEY (primary_organization_id) REFERENCES public.organizations(id);


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: wallet_mode_decisions wallet_mode_decisions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_mode_decisions
    ADD CONSTRAINT wallet_mode_decisions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: wallets wallets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: zk_compliance_proofs zk_compliance_proofs_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: zoho_automation_rules zoho_automation_rules_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules
    ADD CONSTRAINT zoho_automation_rules_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_entities zoho_entities_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_recurring_profiles zoho_recurring_profiles_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles
    ADD CONSTRAINT zoho_recurring_profiles_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_sync_history zoho_sync_history_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history
    ADD CONSTRAINT zoho_sync_history_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_tax_rules zoho_tax_rules_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules
    ADD CONSTRAINT zoho_tax_rules_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: tenant_audit_logs; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_audit_logs tenant_audit_logs_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_audit_logs_isolation_policy ON public.tenant_audit_logs USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_settings tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_settings USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_transactions tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_transactions USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_wallets tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_wallets USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_transactions; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_users; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_users ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_users tenant_users_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_users_isolation_policy ON public.tenant_users USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_wallets; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_wallets ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 1AKhmaxtcgm3vzNvsOR7g0JZMQ2LiTeAjTnp9EuTDSzPSQhjsU6Kgek045EOSHi

