--
-- PostgreSQL database dump
--

\restrict ba7VW0oln19ewAOKkQ2gyTLOHkRZQ0g3w0Ok7CczoAWvOERK1SAQjbKoit7YKZp

-- Dumped from database version 16.10 (Homebrew)
-- Dumped by pg_dump version 16.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: attestation_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.attestation_type AS ENUM (
    'identity',
    'compliance',
    'transfer',
    'cross_rail',
    'batch_operation'
);


ALTER TYPE public.attestation_type OWNER TO alisaberi;

--
-- Name: auth_level; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.auth_level AS ENUM (
    'basic',
    'verified',
    'mfa_required',
    'biometric_required',
    'high_security'
);


ALTER TYPE public.auth_level OWNER TO alisaberi;

--
-- Name: auth_method; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.auth_method AS ENUM (
    'password',
    'biometric',
    'mfa_totp',
    'mfa_sms',
    'mfa_email',
    'webauthn',
    'magic_link',
    'sso',
    'api_key'
);


ALTER TYPE public.auth_method OWNER TO alisaberi;

--
-- Name: biometric_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.biometric_type AS ENUM (
    'face_id',
    'touch_id',
    'fingerprint',
    'iris',
    'voice'
);


ALTER TYPE public.biometric_type OWNER TO alisaberi;

--
-- Name: blockchain_network; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.blockchain_network AS ENUM (
    'base_mainnet',
    'base_testnet',
    'polygon_zkevm_mainnet',
    'polygon_zkevm_testnet',
    'solana_mainnet',
    'solana_devnet'
);


ALTER TYPE public.blockchain_network OWNER TO alisaberi;

--
-- Name: card_network; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.card_network AS ENUM (
    'visa',
    'mastercard',
    'amex',
    'discover'
);


ALTER TYPE public.card_network OWNER TO alisaberi;

--
-- Name: card_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.card_type AS ENUM (
    'physical',
    'virtual'
);


ALTER TYPE public.card_type OWNER TO alisaberi;

--
-- Name: claim_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.claim_status AS ENUM (
    'pending',
    'verified',
    'rejected',
    'expired',
    'revoked'
);


ALTER TYPE public.claim_status OWNER TO alisaberi;

--
-- Name: claim_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.claim_type AS ENUM (
    'kyc_verified',
    'aml_cleared',
    'accredited_investor',
    'qualified_purchaser',
    'institutional',
    'geographic_restriction',
    'age_verification',
    'source_of_funds'
);


ALTER TYPE public.claim_type OWNER TO alisaberi;

--
-- Name: crypto_asset_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.crypto_asset_type AS ENUM (
    'stablecoin',
    'volatile',
    'cbdc',
    'wrapped',
    'synthetic',
    'governance',
    'utility',
    'security',
    'commodity'
);


ALTER TYPE public.crypto_asset_type OWNER TO alisaberi;

--
-- Name: custody_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.custody_type AS ENUM (
    'self',
    'hybrid',
    'managed',
    'institutional'
);


ALTER TYPE public.custody_type OWNER TO alisaberi;

--
-- Name: device_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.device_type AS ENUM (
    'WEB',
    'DESKTOP',
    'IOS',
    'ANDROID'
);


ALTER TYPE public.device_type OWNER TO alisaberi;

--
-- Name: kyc_provider; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.kyc_provider AS ENUM (
    'persona',
    'alloy',
    'onfido',
    'internal'
);


ALTER TYPE public.kyc_provider OWNER TO alisaberi;

--
-- Name: kyc_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.kyc_status AS ENUM (
    'not_started',
    'pending',
    'in_review',
    'approved',
    'rejected',
    'expired'
);


ALTER TYPE public.kyc_status OWNER TO alisaberi;

--
-- Name: mfa_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.mfa_type AS ENUM (
    'totp',
    'sms',
    'email',
    'webauthn',
    'backup_codes',
    'push'
);


ALTER TYPE public.mfa_type OWNER TO alisaberi;

--
-- Name: multi_sig_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.multi_sig_status AS ENUM (
    'pending',
    'partially_signed',
    'executed',
    'cancelled',
    'expired'
);


ALTER TYPE public.multi_sig_status OWNER TO alisaberi;

--
-- Name: oracle_source; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.oracle_source AS ENUM (
    'chainlink',
    'pyth',
    'band_protocol',
    'dia',
    'uma',
    'api3',
    'tellor',
    'redstone',
    'flux',
    'umbrella',
    'internal'
);


ALTER TYPE public.oracle_source OWNER TO alisaberi;

--
-- Name: org_feature_tier; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_feature_tier AS ENUM (
    'basic',
    'standard',
    'premium',
    'enterprise'
);


ALTER TYPE public.org_feature_tier OWNER TO alisaberi;

--
-- Name: org_user_role; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_user_role AS ENUM (
    'owner',
    'admin',
    'manager',
    'member',
    'viewer',
    'finance',
    'developer'
);


ALTER TYPE public.org_user_role OWNER TO alisaberi;

--
-- Name: org_wallet_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.org_wallet_type AS ENUM (
    'consumer',
    'enterprise'
);


ALTER TYPE public.org_wallet_type OWNER TO alisaberi;

--
-- Name: payment_method_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.payment_method_type AS ENUM (
    'card',
    'ach',
    'wire',
    'wallet',
    'crypto_stable',
    'crypto_unstable',
    'bank_account',
    'invoice',
    'crypto_defi',
    'crypto_cbdc'
);


ALTER TYPE public.payment_method_type OWNER TO alisaberi;

--
-- Name: reconciliation_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.reconciliation_status AS ENUM (
    'pending',
    'matched',
    'mismatched',
    'investigating',
    'resolved'
);


ALTER TYPE public.reconciliation_status OWNER TO alisaberi;

--
-- Name: restriction_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.restriction_type AS ENUM (
    'country_based',
    'time_based',
    'amount_based',
    'recipient_based',
    'token_based'
);


ALTER TYPE public.restriction_type OWNER TO alisaberi;

--
-- Name: risk_level; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.risk_level AS ENUM (
    'low',
    'medium',
    'high',
    'critical',
    'blocked'
);


ALTER TYPE public.risk_level OWNER TO alisaberi;

--
-- Name: rule_action; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.rule_action AS ENUM (
    'block',
    'review',
    'approve',
    'notify',
    'report'
);


ALTER TYPE public.rule_action OWNER TO alisaberi;

--
-- Name: rule_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.rule_type AS ENUM (
    'transaction_limit',
    'velocity_limit',
    'kyc_requirement',
    'geographic_restriction',
    'token_restriction',
    'compliance_check'
);


ALTER TYPE public.rule_type OWNER TO alisaberi;

--
-- Name: solana_program_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.solana_program_type AS ENUM (
    'native',
    'spl_token',
    'token_2022',
    'anchor',
    'custom'
);


ALTER TYPE public.solana_program_type OWNER TO alisaberi;

--
-- Name: sso_provider_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.sso_provider_type AS ENUM (
    'oauth2',
    'saml',
    'oidc',
    'custom'
);


ALTER TYPE public.sso_provider_type OWNER TO alisaberi;

--
-- Name: stablecoin_backing; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.stablecoin_backing AS ENUM (
    'fiat_collateralized',
    'crypto_collateralized',
    'algorithmic',
    'commodity_backed',
    'hybrid'
);


ALTER TYPE public.stablecoin_backing OWNER TO alisaberi;

--
-- Name: stablecoin_peg; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.stablecoin_peg AS ENUM (
    'USD',
    'EUR',
    'GBP',
    'JPY',
    'CHF',
    'AUD',
    'CAD',
    'SGD',
    'GOLD',
    'SILVER',
    'BASKET'
);


ALTER TYPE public.stablecoin_peg OWNER TO alisaberi;

--
-- Name: token_extension_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.token_extension_type AS ENUM (
    'transfer_hook',
    'permanent_delegate',
    'transfer_fee',
    'interest_bearing',
    'confidential_transfer',
    'metadata',
    'memo_required'
);


ALTER TYPE public.token_extension_type OWNER TO alisaberi;

--
-- Name: token_standard; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.token_standard AS ENUM (
    'ERC20',
    'ERC3643',
    'TOKEN2022',
    'SPL'
);


ALTER TYPE public.token_standard OWNER TO alisaberi;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.transaction_status AS ENUM (
    'pending',
    'processing',
    'completed',
    'failed',
    'cancelled',
    'reversed',
    'success'
);


ALTER TYPE public.transaction_status OWNER TO alisaberi;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.transaction_type AS ENUM (
    'deposit',
    'withdrawal',
    'transfer',
    'swap',
    'mint',
    'burn',
    'cross_rail',
    'payment',
    'refund',
    'invoice_payment',
    'crypto_exchange',
    'staking',
    'yield_farming',
    'liquidity_provision',
    'collateralization'
);


ALTER TYPE public.transaction_type OWNER TO alisaberi;

--
-- Name: user_role_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_role_type AS ENUM (
    'platform_admin',
    'compliance_officer',
    'treasury_manager',
    'support_agent',
    'enterprise_admin',
    'enterprise_finance',
    'enterprise_developer',
    'premium_consumer',
    'verified_consumer',
    'basic_consumer',
    'secondary_user',
    'merchant',
    'payment_processor'
);


ALTER TYPE public.user_role_type OWNER TO alisaberi;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'inactive',
    'suspended',
    'deleted',
    'pending_verification'
);


ALTER TYPE public.user_status OWNER TO alisaberi;

--
-- Name: user_type; Type: TYPE; Schema: public; Owner: alisaberi
--

CREATE TYPE public.user_type AS ENUM (
    'individual',
    'organization'
);


ALTER TYPE public.user_type OWNER TO alisaberi;

--
-- Name: check_consumer_daily_limit(character varying, numeric); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.check_consumer_daily_limit(p_user_id character varying, p_amount numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_daily_limit NUMERIC;
    v_daily_spent NUMERIC;
BEGIN
    -- Get user's daily limit
    SELECT consumer_daily_limit INTO v_daily_limit
    FROM users
    WHERE id = p_user_id;

    -- Get today's spending
    SELECT COALESCE(SUM(amount), 0) INTO v_daily_spent
    FROM transactions
    WHERE user_id = p_user_id
      AND created_at >= CURRENT_DATE
      AND type IN ('transfer', 'withdrawal', 'payment');

    -- Check if new amount would exceed limit
    RETURN (v_daily_spent + p_amount) <= v_daily_limit;
END;
$$;


ALTER FUNCTION public.check_consumer_daily_limit(p_user_id character varying, p_amount numeric) OWNER TO alisaberi;

--
-- Name: check_overdue_invoices(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.check_overdue_invoices() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE invoices
    SET status = 'OVERDUE'
    WHERE status IN ('PENDING', 'PARTIALLY_PAID')
    AND due_date < NOW();
END;
$$;


ALTER FUNCTION public.check_overdue_invoices() OWNER TO alisaberi;

--
-- Name: check_spending_limit(character varying, uuid, character varying, numeric); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.check_spending_limit(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) RETURNS TABLE(allowed boolean, remaining_amount numeric, limit_id uuid, enforcement_action character varying, message text)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_limit RECORD;
    v_effective_limit DECIMAL;
    v_remaining DECIMAL;
BEGIN
    -- Get the active limit for this entity and type
    SELECT * INTO v_limit
    FROM spending_limits
    WHERE entity_type = p_entity_type
        AND entity_id = p_entity_id
        AND limit_type = p_limit_type
        AND is_active = true
        AND deleted_at IS NULL
    ORDER BY priority DESC
    LIMIT 1;

    -- If no limit found, allow by default
    IF NOT FOUND THEN
        RETURN QUERY SELECT
            true::BOOLEAN as allowed,
            NULL::DECIMAL as remaining_amount,
            NULL::UUID as limit_id,
            'allow'::VARCHAR as enforcement_action,
            'No spending limit configured'::TEXT as message;
        RETURN;
    END IF;

    -- Check for temporary override
    IF v_limit.temporary_override_amount IS NOT NULL
        AND v_limit.temporary_override_expires > CURRENT_TIMESTAMP THEN
        v_effective_limit := v_limit.temporary_override_amount;
    ELSE
        v_effective_limit := v_limit.limit_amount;
    END IF;

    -- Calculate remaining amount
    v_remaining := v_effective_limit - v_limit.current_usage;

    -- Check if transaction would exceed limit
    IF p_amount > v_remaining THEN
        -- Log violation
        INSERT INTO spending_limit_violations (
            spending_limit_id,
            entity_type,
            entity_id,
            attempted_amount,
            limit_amount,
            current_usage,
            violation_type,
            action_taken
        ) VALUES (
            v_limit.id,
            p_entity_type,
            p_entity_id,
            p_amount,
            v_effective_limit,
            v_limit.current_usage,
            p_limit_type,
            v_limit.enforcement_action
        );

        RETURN QUERY SELECT
            false::BOOLEAN as allowed,
            v_remaining as remaining_amount,
            v_limit.id as limit_id,
            v_limit.enforcement_action as enforcement_action,
            format('Transaction exceeds %s limit. Remaining: $%s', v_limit.limit_type, v_remaining)::TEXT as message;
    ELSE
        RETURN QUERY SELECT
            true::BOOLEAN as allowed,
            v_remaining as remaining_amount,
            v_limit.id as limit_id,
            'allow'::VARCHAR as enforcement_action,
            format('Transaction within limits. Remaining after: $%s', (v_remaining - p_amount))::TEXT as message;
    END IF;
END;
$_$;


ALTER FUNCTION public.check_spending_limit(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) OWNER TO alisaberi;

--
-- Name: FUNCTION check_spending_limit(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric); Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON FUNCTION public.check_spending_limit(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) IS 'Checks if a transaction amount is within spending limits';


--
-- Name: cleanup_expired_sessions(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.cleanup_expired_sessions() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE auth_sessions
    SET is_active = false, revoked_at = NOW(), revoked_reason = 'expired'
    WHERE expires_at < NOW() AND is_active = true;

    DELETE FROM magic_links WHERE expires_at < NOW() - INTERVAL '7 days';
    DELETE FROM auth_sessions WHERE expires_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_expired_sessions() OWNER TO alisaberi;

--
-- Name: create_consumer_tenant(uuid, character varying, character varying); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.create_consumer_tenant(p_user_id uuid, p_user_email character varying, p_user_name character varying) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tenant_id UUID;
    v_tenant_code VARCHAR(50);
BEGIN
    -- Generate unique tenant code
    v_tenant_code := 'TNT-' || SUBSTRING(p_user_id::TEXT, 1, 8);

    -- Create tenant
    INSERT INTO tenants (
        tenant_code,
        name,
        type,
        isolation_level,
        billing_tier,
        status
    ) VALUES (
        v_tenant_code,
        COALESCE(p_user_name, p_user_email),
        'individual',
        'row',
        'free',
        'active'
    ) RETURNING id INTO v_tenant_id;

    -- Link user to tenant
    INSERT INTO tenant_users (
        tenant_id,
        user_id,
        role,
        is_primary,
        status
    ) VALUES (
        v_tenant_id,
        p_user_id,
        'owner',
        TRUE,
        'active'
    );

    RETURN v_tenant_id;
END;
$$;


ALTER FUNCTION public.create_consumer_tenant(p_user_id uuid, p_user_email character varying, p_user_name character varying) OWNER TO alisaberi;

--
-- Name: create_user_with_tenant(character varying, character varying, character varying, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.create_user_with_tenant(p_user_id character varying, p_email character varying, p_first_name character varying, p_last_name character varying, p_user_type character varying, p_organization_id uuid DEFAULT NULL::uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_tenant_id UUID;
BEGIN
    IF p_user_type = 'individual' AND p_organization_id IS NULL THEN
        -- Create individual tenant for consumer
        INSERT INTO tenants (
            tenant_code,
            name,
            type,
            isolation_level,
            billing_tier,
            status
        ) VALUES (
            'TNT-IND-' || SUBSTRING(p_user_id::TEXT, 1, 8),
            COALESCE(p_first_name || ' ' || p_last_name, p_email),
            'individual',
            'row',
            'free',
            'active'
        ) RETURNING id INTO v_tenant_id;

        -- Link user directly to tenant
        INSERT INTO tenant_users (
            tenant_id,
            user_id,
            role,
            is_primary,
            status
        ) VALUES (
            v_tenant_id,
            p_user_id,
            'owner',
            TRUE,
            'active'
        );

        RETURN v_tenant_id;
    ELSIF p_organization_id IS NOT NULL THEN
        -- Business user - get tenant from organization
        SELECT tenant_id INTO v_tenant_id
        FROM organizations
        WHERE id = p_organization_id;

        -- User is linked to organization, NOT to tenant directly
        -- (This should be handled by organization_users table)

        RETURN v_tenant_id;
    ELSE
        RAISE EXCEPTION 'Invalid user configuration: type=% org_id=%', p_user_type, p_organization_id;
    END IF;
END;
$$;


ALTER FUNCTION public.create_user_with_tenant(p_user_id character varying, p_email character varying, p_first_name character varying, p_last_name character varying, p_user_type character varying, p_organization_id uuid) OWNER TO alisaberi;

--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    RETURN current_setting('app.current_tenant_id', TRUE)::UUID;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
$$;


ALTER FUNCTION public.current_tenant_id() OWNER TO alisaberi;

--
-- Name: ensure_user_consistency(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.ensure_user_consistency() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- If user_type is 'organization', they should have at least one organization
    IF NEW.user_type = 'organization' THEN
        -- Allow the update/insert but schedule a check
        -- The actual organization assignment can happen after user creation
        NULL;
    END IF;

    -- If user_type is 'individual', clear primary organization
    IF NEW.user_type = 'individual' THEN
        NEW.primary_organization_id := NULL;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.ensure_user_consistency() OWNER TO alisaberi;

--
-- Name: get_next_invoice_number(uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.get_next_invoice_number(ent_id uuid) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    next_number BIGINT;
BEGIN
    UPDATE enterprise_treasuries
    SET invoices_created = invoices_created + 1
    WHERE enterprise_id = ent_id
    RETURNING invoices_created INTO next_number;

    RETURN next_number;
END;
$$;


ALTER FUNCTION public.get_next_invoice_number(ent_id uuid) OWNER TO alisaberi;

--
-- Name: get_user_tenant_context(uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.get_user_tenant_context(p_user_id uuid) RETURNS TABLE(tenant_id uuid, tenant_code character varying, tenant_name character varying, tenant_type character varying, user_role character varying, is_primary boolean, organization_id uuid, organization_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        t.id as tenant_id,
        t.tenant_code,
        t.name as tenant_name,
        t.type as tenant_type,
        tu.role as user_role,
        tu.is_primary,
        o.id as organization_id,
        o.name as organization_name
    FROM tenant_users tu
    JOIN tenants t ON tu.tenant_id = t.id
    LEFT JOIN organizations o ON t.id = o.tenant_id
    WHERE tu.user_id = p_user_id
    AND tu.status = 'active'
    ORDER BY tu.is_primary DESC, tu.joined_at;
END;
$$;


ALTER FUNCTION public.get_user_tenant_context(p_user_id uuid) OWNER TO alisaberi;

--
-- Name: get_user_tenant_context(character varying); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.get_user_tenant_context(p_user_id character varying) RETURNS TABLE(tenant_id uuid, tenant_code character varying, tenant_name character varying, tenant_type character varying, access_type character varying, organization_id uuid, organization_name character varying, user_role character varying, is_primary boolean)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- First check if user has direct tenant relationship (individual consumer)
    IF EXISTS (
        SELECT 1 FROM tenant_users tu WHERE tu.user_id = p_user_id::VARCHAR
    ) THEN
        RETURN QUERY
        SELECT
            t.id as tenant_id,
            t.tenant_code,
            t.name as tenant_name,
            t.type as tenant_type,
            'individual'::VARCHAR as access_type,
            NULL::UUID as organization_id,
            NULL::VARCHAR as organization_name,
            tu.role as user_role,
            tu.is_primary
        FROM tenant_users tu
        JOIN tenants t ON tu.tenant_id = t.id
        WHERE tu.user_id = p_user_id::VARCHAR
        AND tu.status = 'active';
    ELSE
        -- User must be part of organization(s)
        RETURN QUERY
        SELECT
            t.id as tenant_id,
            t.tenant_code,
            t.name as tenant_name,
            t.type as tenant_type,
            'organization'::VARCHAR as access_type,
            o.id as organization_id,
            o.name as organization_name,
            ou.role::text as user_role,  -- Cast enum to text
            FALSE as is_primary
        FROM organization_users ou
        JOIN organizations o ON ou.organization_id = o.id
        JOIN tenants t ON o.tenant_id = t.id
        WHERE ou.user_id = p_user_id::VARCHAR
        AND ou.invitation_status = 'active'
        ORDER BY ou.joined_at;
    END IF;
END;
$$;


ALTER FUNCTION public.get_user_tenant_context(p_user_id character varying) OWNER TO alisaberi;

--
-- Name: invite_user_to_organization(uuid, character varying, character varying, uuid); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role character varying, p_invited_by uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id UUID;
    v_invitation_id UUID;
BEGIN
    -- Check if user exists
    SELECT id INTO v_user_id FROM users WHERE email = p_email;

    IF v_user_id IS NULL THEN
        -- Create a placeholder user if doesn't exist
        INSERT INTO users (email, username, user_type, is_active, is_verified)
        VALUES (p_email, split_part(p_email, '@', 1), 'organization', false, false)
        RETURNING id INTO v_user_id;
    END IF;

    -- Create or update organization_user record
    INSERT INTO organization_users (
        organization_id, user_id, role, invited_by, invitation_status
    ) VALUES (
        p_organization_id, v_user_id, p_role, p_invited_by, 'pending'
    )
    ON CONFLICT (organization_id, user_id)
    DO UPDATE SET
        role = EXCLUDED.role,
        invitation_status = 'pending',
        updated_at = NOW()
    RETURNING id INTO v_invitation_id;

    RETURN v_invitation_id;
END;
$$;


ALTER FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role character varying, p_invited_by uuid) OWNER TO alisaberi;

--
-- Name: invite_user_to_organization(uuid, character varying, public.org_user_role, character varying); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role public.org_user_role, p_invited_by character varying) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id VARCHAR(255);
    v_invitation_id UUID;
BEGIN
    -- Check if user exists
    SELECT id INTO v_user_id FROM users WHERE email = p_email;

    IF v_user_id IS NULL THEN
        -- Create a placeholder user if doesn't exist
        v_user_id := 'usr_' || substr(md5(random()::text), 1, 16);
        INSERT INTO users (id, email, username, user_type, is_active, is_verified)
        VALUES (v_user_id, p_email, split_part(p_email, '@', 1), 'organization', false, false);
    ELSE
        -- Update existing user to organization type if they were individual
        UPDATE users SET user_type = 'organization' WHERE id = v_user_id AND user_type = 'individual';
    END IF;

    -- Create or update organization_user record
    INSERT INTO organization_users (
        organization_id, user_id, role, invited_by, invitation_status
    ) VALUES (
        p_organization_id, v_user_id, p_role, p_invited_by, 'pending'
    )
    ON CONFLICT (organization_id, user_id)
    DO UPDATE SET
        role = EXCLUDED.role,
        invitation_status = 'pending',
        updated_at = NOW()
    RETURNING id INTO v_invitation_id;

    RETURN v_invitation_id;
END;
$$;


ALTER FUNCTION public.invite_user_to_organization(p_organization_id uuid, p_email character varying, p_role public.org_user_role, p_invited_by character varying) OWNER TO alisaberi;

--
-- Name: prevent_org_users_in_tenant_users(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.prevent_org_users_in_tenant_users() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM organization_users ou WHERE ou.user_id = NEW.user_id
    ) THEN
        RAISE EXCEPTION 'User % is part of an organization and cannot have direct tenant relationship', NEW.user_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.prevent_org_users_in_tenant_users() OWNER TO alisaberi;

--
-- Name: reset_spending_limits(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.reset_spending_limits() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Reset daily limits
    UPDATE spending_limits
    SET current_usage = 0,
        last_reset = CURRENT_TIMESTAMP,
        reset_time = CURRENT_TIMESTAMP + INTERVAL '1 day'
    WHERE time_window = 'daily'
        AND reset_time <= CURRENT_TIMESTAMP
        AND is_active = true
        AND deleted_at IS NULL;

    -- Reset weekly limits
    UPDATE spending_limits
    SET current_usage = 0,
        last_reset = CURRENT_TIMESTAMP,
        reset_time = CURRENT_TIMESTAMP + INTERVAL '1 week'
    WHERE time_window = 'weekly'
        AND reset_time <= CURRENT_TIMESTAMP
        AND is_active = true
        AND deleted_at IS NULL;

    -- Reset monthly limits
    UPDATE spending_limits
    SET current_usage = 0,
        last_reset = CURRENT_TIMESTAMP,
        reset_time = CURRENT_TIMESTAMP + INTERVAL '1 month'
    WHERE time_window = 'monthly'
        AND reset_time <= CURRENT_TIMESTAMP
        AND is_active = true
        AND deleted_at IS NULL;

    -- Expire temporary overrides
    UPDATE spending_limits
    SET temporary_override_amount = NULL,
        temporary_override_expires = NULL
    WHERE temporary_override_expires <= CURRENT_TIMESTAMP
        AND temporary_override_amount IS NOT NULL;
END;
$$;


ALTER FUNCTION public.reset_spending_limits() OWNER TO alisaberi;

--
-- Name: FUNCTION reset_spending_limits(); Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON FUNCTION public.reset_spending_limits() IS 'Resets spending limit usage based on time windows';


--
-- Name: update_invoice_status_on_payment(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_invoice_status_on_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.status = 'COMPLETED' THEN
        UPDATE invoices
        SET
            paid_amount = paid_amount + NEW.amount,
            last_payment_at = NEW.created_at,
            status = CASE
                WHEN (paid_amount + NEW.amount) >= amount THEN 'PAID'
                WHEN (paid_amount + NEW.amount) > 0 THEN 'PARTIALLY_PAID'
                ELSE status
            END,
            paid_at = CASE
                WHEN (paid_amount + NEW.amount) >= amount THEN NEW.created_at
                ELSE paid_at
            END
        WHERE id = NEW.invoice_id;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_status_on_payment() OWNER TO alisaberi;

--
-- Name: update_invoice_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_invoice_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_invoice_updated_at() OWNER TO alisaberi;

--
-- Name: update_notifications_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_notifications_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN NEW.updated_at = CURRENT_TIMESTAMP; RETURN NEW; END; $$;


ALTER FUNCTION public.update_notifications_updated_at() OWNER TO alisaberi;

--
-- Name: update_spending_limits_updated_at(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_spending_limits_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_spending_limits_updated_at() OWNER TO alisaberi;

--
-- Name: update_spending_usage(character varying, uuid, character varying, numeric); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_spending_usage(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE spending_limits
    SET current_usage = current_usage + p_amount,
        updated_at = CURRENT_TIMESTAMP
    WHERE entity_type = p_entity_type
        AND entity_id = p_entity_id
        AND limit_type = p_limit_type
        AND is_active = true
        AND deleted_at IS NULL;
END;
$$;


ALTER FUNCTION public.update_spending_usage(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) OWNER TO alisaberi;

--
-- Name: FUNCTION update_spending_usage(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric); Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON FUNCTION public.update_spending_usage(p_entity_type character varying, p_entity_id uuid, p_limit_type character varying, p_amount numeric) IS 'Updates the current usage amount for a spending limit';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO alisaberi;

--
-- Name: update_user_risk_profile(); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.update_user_risk_profile() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    avg_risk INTEGER;
    new_risk_level risk_level;
BEGIN
    -- Calculate average risk from recent sessions
    SELECT AVG(risk_score) INTO avg_risk
    FROM auth_risk_analysis
    WHERE user_id = NEW.user_id
    AND analyzed_at > NOW() - INTERVAL '30 days';

    -- Determine risk level
    IF avg_risk IS NULL OR avg_risk < 25 THEN
        new_risk_level := 'low';
    ELSIF avg_risk < 50 THEN
        new_risk_level := 'medium';
    ELSIF avg_risk < 75 THEN
        new_risk_level := 'high';
    ELSE
        new_risk_level := 'critical';
    END IF;

    -- Update user risk profile
    UPDATE users
    SET risk_profile = new_risk_level,
        last_risk_assessment = NOW()
    WHERE id = NEW.user_id;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_user_risk_profile() OWNER TO alisaberi;

--
-- Name: upgrade_organization_to_enterprise(uuid, public.org_feature_tier); Type: FUNCTION; Schema: public; Owner: alisaberi
--

CREATE FUNCTION public.upgrade_organization_to_enterprise(p_organization_id uuid, p_feature_tier public.org_feature_tier DEFAULT 'standard'::public.org_feature_tier) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE organizations
    SET
        wallet_type = 'enterprise',
        feature_tier = p_feature_tier,
        upgraded_from_consumer = TRUE,
        consumer_limits = NULL,
        updated_at = NOW()
    WHERE
        id = p_organization_id
        AND wallet_type = 'consumer'
        AND can_upgrade = TRUE;

    RETURN FOUND;
END;
$$;


ALTER FUNCTION public.upgrade_organization_to_enterprise(p_organization_id uuid, p_feature_tier public.org_feature_tier) OWNER TO alisaberi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.activity_logs (
    id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    admin_id character varying(255),
    user_id character varying(255),
    "userId" character varying(255),
    transaction_id character varying(255),
    "transactionId" character varying(255),
    ip character varying(100),
    activity_type character varying(100),
    "activityType" character varying(100),
    message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    action character varying(255),
    description text,
    "ipAddress" character varying(100),
    "adminId" character varying(255),
    metadata jsonb,
    "userAgent" text,
    method character varying(20),
    endpoint text,
    "statusCode" integer,
    "responseTime" integer,
    "errorDetails" text
);


ALTER TABLE public.activity_logs OWNER TO alisaberi;

--
-- Name: ai_financial_insights; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.ai_financial_insights (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    insight_type character varying(50) NOT NULL,
    category character varying(100),
    title character varying(255),
    description text,
    recommendations jsonb DEFAULT '[]'::jsonb,
    potential_savings numeric(20,2),
    confidence_score numeric(5,4),
    is_read boolean DEFAULT false,
    is_acted_upon boolean DEFAULT false,
    user_feedback character varying(50),
    valid_from timestamp with time zone DEFAULT now(),
    valid_until timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_financial_insights OWNER TO alisaberi;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    key_hash character varying(255) NOT NULL,
    key_prefix character varying(10) NOT NULL,
    name character varying(255),
    permissions jsonb,
    rate_limit integer DEFAULT 1000,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO alisaberi;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255),
    action character varying(100) NOT NULL,
    actor_id character varying(255),
    actor_role character varying(50),
    changes jsonb,
    ip_address inet,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO alisaberi;

--
-- Name: auth_audit_log; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    event_type character varying(100) NOT NULL,
    auth_method public.auth_method,
    device_id uuid,
    session_id uuid,
    ip_address inet,
    location jsonb,
    success boolean NOT NULL,
    failure_reason character varying(255),
    risk_score integer,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auth_audit_log OWNER TO alisaberi;

--
-- Name: auth_challenges; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_key character varying(255) NOT NULL,
    challenge text NOT NULL,
    challenge_type character varying(50) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auth_challenges OWNER TO alisaberi;

--
-- Name: auth_risk_analysis; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_risk_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    session_id uuid,
    risk_score integer NOT NULL,
    risk_level public.risk_level NOT NULL,
    risk_factors jsonb NOT NULL,
    location_risk integer,
    device_risk integer,
    behavior_risk integer,
    velocity_risk integer,
    required_auth_level public.auth_level,
    is_blocked boolean DEFAULT false,
    analyzed_at timestamp with time zone DEFAULT now(),
    CONSTRAINT auth_risk_analysis_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.auth_risk_analysis OWNER TO alisaberi;

--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auth_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    session_token character varying(512) NOT NULL,
    refresh_token character varying(512),
    device_id uuid,
    ip_address inet,
    user_agent text,
    location jsonb,
    risk_score integer DEFAULT 0,
    is_active boolean DEFAULT true,
    last_activity timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    revoked_at timestamp with time zone,
    revoked_reason character varying(255),
    CONSTRAINT auth_sessions_risk_score_check CHECK (((risk_score >= 0) AND (risk_score <= 100)))
);


ALTER TABLE public.auth_sessions OWNER TO alisaberi;

--
-- Name: auto_topup_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.auto_topup_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    trigger_threshold numeric(20,2) NOT NULL,
    topup_amount numeric(20,2) NOT NULL,
    max_monthly_amount numeric(20,2),
    source_payment_method_id uuid,
    is_active boolean DEFAULT true,
    last_triggered_at timestamp with time zone,
    next_check_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.auto_topup_rules OWNER TO alisaberi;

--
-- Name: batch_transfer_recipients; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.batch_transfer_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id character varying(255) NOT NULL,
    recipient_address character varying(255) NOT NULL,
    amount numeric(40,18) NOT NULL,
    currency character varying(10) DEFAULT 'USDC'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    transaction_id character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.batch_transfer_recipients OWNER TO alisaberi;

--
-- Name: batch_transfers; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.batch_transfers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    batch_id character varying(255) NOT NULL,
    sender_id character varying(255) NOT NULL,
    total_amount numeric(40,18) NOT NULL,
    total_recipients integer NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying,
    provider character varying(50),
    fee numeric(40,18),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.batch_transfers OWNER TO alisaberi;

--
-- Name: bill_payments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bill_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bill_id uuid,
    user_id character varying(255),
    amount numeric(20,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method_id uuid,
    transaction_id character varying(255),
    status character varying(50) DEFAULT 'completed'::character varying,
    confirmation_number character varying(100),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bill_payments OWNER TO alisaberi;

--
-- Name: billing_metrics; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.billing_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    transaction_count integer DEFAULT 0,
    transaction_volume_cents bigint DEFAULT 0,
    computation_units_used integer DEFAULT 0,
    api_calls_count integer DEFAULT 0,
    storage_used_bytes bigint DEFAULT 0,
    bandwidth_used_bytes bigint DEFAULT 0,
    overage_charges_cents integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.billing_metrics OWNER TO alisaberi;

--
-- Name: bills; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    biller_name character varying(255) NOT NULL,
    biller_category character varying(100),
    account_number character varying(100),
    amount_due numeric(20,2),
    due_date date,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    auto_pay_enabled boolean DEFAULT false,
    auto_pay_amount numeric(20,2),
    payment_method_id uuid,
    status character varying(50) DEFAULT 'pending'::character varying,
    last_paid_date date,
    next_due_date date,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bills OWNER TO alisaberi;

--
-- Name: blockchain_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.blockchain_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    chain character varying(50) NOT NULL,
    transaction_hash character varying(255),
    from_address character varying(255),
    to_address character varying(255),
    value numeric(40,18),
    token_address character varying(255),
    token_symbol character varying(20),
    gas_used bigint,
    gas_price numeric(40,18),
    nonce integer,
    block_number bigint,
    status public.transaction_status,
    type public.transaction_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    confirmed_at timestamp with time zone
);


ALTER TABLE public.blockchain_transactions OWNER TO alisaberi;

--
-- Name: blockchain_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.blockchain_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    wallet_type character varying(50) NOT NULL,
    chain_id integer,
    network public.blockchain_network,
    address character varying(255) NOT NULL,
    public_key text,
    encrypted_private_key text,
    derivation_path character varying(255),
    is_primary boolean DEFAULT false,
    is_imported boolean DEFAULT false,
    custody_type character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.blockchain_wallets OWNER TO alisaberi;

--
-- Name: bridge_swaps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.bridge_swaps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    swap_id character varying(255) NOT NULL,
    user_id character varying(255),
    from_chain public.blockchain_network NOT NULL,
    to_chain public.blockchain_network NOT NULL,
    from_token_address character varying(255),
    to_token_address character varying(255),
    from_amount numeric(40,18) NOT NULL,
    to_amount numeric(40,18),
    fee_amount numeric(40,18),
    from_tx_hash character varying(255),
    to_tx_hash character varying(255),
    status public.transaction_status,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.bridge_swaps OWNER TO alisaberi;

--
-- Name: business_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.business_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    rule_name character varying(255) NOT NULL,
    rule_type public.rule_type,
    entity_type character varying(50),
    entity_id character varying(255),
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    priority integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.business_rules OWNER TO alisaberi;

--
-- Name: businesses; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.businesses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid,
    business_name character varying(255) NOT NULL,
    business_type character varying(100),
    industry character varying(100),
    annual_revenue numeric(20,2),
    employee_count integer,
    founded_date date,
    description text,
    logo_url text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.businesses OWNER TO alisaberi;

--
-- Name: charity_donations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.charity_donations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    charity_id uuid,
    amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    transaction_id character varying(255),
    receipt_url text,
    tax_receipt_sent boolean DEFAULT false,
    tax_year integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.charity_donations OWNER TO alisaberi;

--
-- Name: charity_organizations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.charity_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    ein character varying(20),
    category character varying(100),
    cause character varying(255),
    description text,
    website character varying(255),
    logo_url text,
    is_verified boolean DEFAULT false,
    tax_deductible boolean DEFAULT false,
    verification_date date,
    impact_metrics jsonb DEFAULT '{}'::jsonb,
    transparency_score numeric(5,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.charity_organizations OWNER TO alisaberi;

--
-- Name: child_parents; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.child_parents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_id character varying(255),
    child_id character varying(255),
    relationship character varying(50),
    daily_limit numeric(20,2),
    monthly_limit numeric(20,2),
    auto_topup_enabled boolean DEFAULT false,
    auto_topup_threshold numeric(20,2),
    auto_topup_amount numeric(20,2),
    permissions jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.child_parents OWNER TO alisaberi;

--
-- Name: compliance_checks; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.compliance_checks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    transaction_id character varying(255),
    check_type character varying(50),
    check_status character varying(50),
    risk_score integer,
    risk_factors jsonb,
    reviewed_by character varying(255),
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    reviewed_at timestamp with time zone
);


ALTER TABLE public.compliance_checks OWNER TO alisaberi;

--
-- Name: consumer_preferences; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.consumer_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    preferred_currency character varying(10) DEFAULT 'USDC'::character varying,
    auto_balance boolean DEFAULT false,
    smart_routing boolean DEFAULT true,
    instant_notifications boolean DEFAULT true,
    theme character varying(20) DEFAULT 'light'::character varying,
    language character varying(10) DEFAULT 'en'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.consumer_preferences OWNER TO alisaberi;

--
-- Name: consumer_rewards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.consumer_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    reward_type character varying(50) NOT NULL,
    points_earned numeric(20,2) DEFAULT 0,
    points_redeemed numeric(20,2) DEFAULT 0,
    points_balance numeric(20,2) DEFAULT 0,
    tier character varying(20) DEFAULT 'bronze'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.consumer_rewards OWNER TO alisaberi;

--
-- Name: consumer_subscriptions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.consumer_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    merchant_name character varying(255) NOT NULL,
    amount numeric(40,18) NOT NULL,
    currency character varying(10) DEFAULT 'USDC'::character varying,
    frequency character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    next_payment_date date,
    last_payment_date date,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    cancelled_at timestamp with time zone
);


ALTER TABLE public.consumer_subscriptions OWNER TO alisaberi;

--
-- Name: consumer_virtual_cards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.consumer_virtual_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    card_id character varying(255) NOT NULL,
    last_four character varying(4),
    brand character varying(20),
    status character varying(20) DEFAULT 'active'::character varying,
    spending_limit numeric(40,18),
    daily_spent numeric(40,18) DEFAULT 0,
    monthly_spent numeric(40,18) DEFAULT 0,
    provider character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.consumer_virtual_cards OWNER TO alisaberi;

--
-- Name: contract_interactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.contract_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    contract_id uuid,
    user_id character varying(255),
    function_name character varying(255),
    parameters jsonb,
    transaction_hash character varying(255),
    gas_used bigint,
    status public.transaction_status,
    result jsonb,
    error_message text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.contract_interactions OWNER TO alisaberi;

--
-- Name: countries; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.countries (
    id integer NOT NULL,
    code character varying(100),
    name character varying(100),
    "countryCallingCode" character varying(11),
    "currencyCode" character varying(100),
    status character varying(20) DEFAULT 'inactive'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT countries_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'deleted'::character varying])::text[])))
);


ALTER TABLE public.countries OWNER TO alisaberi;

--
-- Name: countries_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.countries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.countries_id_seq OWNER TO alisaberi;

--
-- Name: countries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.countries_id_seq OWNED BY public.countries.id;


--
-- Name: custody_configurations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.custody_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    custody_type public.custody_type NOT NULL,
    key_shares integer DEFAULT 2,
    threshold integer DEFAULT 2,
    user_shard_encrypted text,
    server_shard_location character varying(50),
    recovery_method character varying(50),
    recovery_shares jsonb,
    backup_enabled boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT custody_configurations_key_shares_check CHECK (((key_shares >= 1) AND (key_shares <= 5)))
);


ALTER TABLE public.custody_configurations OWNER TO alisaberi;

--
-- Name: customer_credits; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.customer_credits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    customer_id character varying(255),
    organization_id uuid,
    amount numeric(20,2) NOT NULL,
    source_invoice_id uuid,
    applied_to_invoice_id uuid,
    status character varying(50) DEFAULT 'AVAILABLE'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    applied_at timestamp without time zone,
    expires_at timestamp without time zone,
    CONSTRAINT chk_credit_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_credit_status CHECK (((status)::text = ANY ((ARRAY['AVAILABLE'::character varying, 'APPLIED'::character varying, 'EXPIRED'::character varying, 'REFUNDED'::character varying])::text[])))
);


ALTER TABLE public.customer_credits OWNER TO alisaberi;

--
-- Name: TABLE customer_credits; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.customer_credits IS 'Customer credit balances from invoice overpayments';


--
-- Name: enterprise_ramps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.enterprise_ramps (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    type character varying(10) NOT NULL,
    amount numeric(20,2) NOT NULL,
    method character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    reference_id character varying(255),
    bank_account_id uuid,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    metadata jsonb,
    CONSTRAINT chk_ramp_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_ramp_method CHECK (((method)::text = ANY ((ARRAY['ACH'::character varying, 'WIRE'::character varying, 'CARD'::character varying, 'CHECK'::character varying])::text[]))),
    CONSTRAINT chk_ramp_provider CHECK (((provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying, 'tillipay'::character varying])::text[]))),
    CONSTRAINT chk_ramp_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'PROCESSING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying, 'CANCELLED'::character varying])::text[]))),
    CONSTRAINT chk_ramp_type CHECK (((type)::text = ANY ((ARRAY['ONRAMP'::character varying, 'OFFRAMP'::character varying])::text[])))
);


ALTER TABLE public.enterprise_ramps OWNER TO alisaberi;

--
-- Name: enterprise_treasuries; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.enterprise_treasuries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    wallet_address character varying(255) NOT NULL,
    solana_tree_address character varying(255),
    tree_capacity integer DEFAULT 1048576,
    invoices_created integer DEFAULT 0,
    tempo_balance numeric(20,2) DEFAULT 0.00,
    circle_balance numeric(20,2) DEFAULT 0.00,
    tempo_wallet_id character varying(255),
    circle_wallet_id character varying(255),
    total_minted numeric(20,2) DEFAULT 0.00,
    total_burned numeric(20,2) DEFAULT 0.00,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_treasury_status CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'SUSPENDED'::character varying, 'CLOSED'::character varying])::text[])))
);


ALTER TABLE public.enterprise_treasuries OWNER TO alisaberi;

--
-- Name: TABLE enterprise_treasuries; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.enterprise_treasuries IS 'Enterprise treasury management with Solana integration for tokenized invoices';


--
-- Name: gift_cards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.gift_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    initial_value numeric(20,2) NOT NULL,
    current_balance numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    purchaser_id character varying(255),
    recipient_id character varying(255),
    recipient_email character varying(255),
    is_activated boolean DEFAULT false,
    is_redeemed boolean DEFAULT false,
    expires_at timestamp with time zone,
    design_template character varying(100),
    personal_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    redeemed_at timestamp with time zone
);


ALTER TABLE public.gift_cards OWNER TO alisaberi;

--
-- Name: invoice_attachments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_attachments (
    id integer NOT NULL,
    invoice_id character varying(50),
    file_name character varying(255) NOT NULL,
    file_type character varying(50),
    file_size integer,
    storage_url text,
    ipfs_hash character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_attachments OWNER TO alisaberi;

--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_attachments_id_seq OWNER TO alisaberi;

--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_attachments_id_seq OWNED BY public.invoice_attachments.id;


--
-- Name: invoice_batch_items; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_batch_items (
    id integer NOT NULL,
    batch_id character varying(50),
    invoice_id character varying(50),
    status character varying(20) DEFAULT 'pending'::character varying,
    error_message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_batch_items OWNER TO alisaberi;

--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_batch_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_batch_items_id_seq OWNER TO alisaberi;

--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_batch_items_id_seq OWNED BY public.invoice_batch_items.id;


--
-- Name: invoice_batches; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_batches (
    id integer NOT NULL,
    batch_id character varying(50) NOT NULL,
    user_id character varying(255),
    total_invoices integer NOT NULL,
    total_amount numeric(20,8),
    currency character varying(10),
    status character varying(20) DEFAULT 'processing'::character varying,
    blockchain_tx_hash character varying(255),
    processed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.invoice_batches OWNER TO alisaberi;

--
-- Name: invoice_batches_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_batches_id_seq OWNER TO alisaberi;

--
-- Name: invoice_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_batches_id_seq OWNED BY public.invoice_batches.id;


--
-- Name: invoice_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    event_type character varying(50) NOT NULL,
    event_data jsonb,
    user_id character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_event_type CHECK (((event_type)::text = ANY ((ARRAY['CREATED'::character varying, 'SENT'::character varying, 'VIEWED'::character varying, 'PAYMENT_RECEIVED'::character varying, 'PAYMENT_FAILED'::character varying, 'REMINDER_SENT'::character varying, 'OVERDUE_NOTICE'::character varying, 'CANCELLED'::character varying, 'REFUNDED'::character varying, 'CREDIT_APPLIED'::character varying])::text[])))
);


ALTER TABLE public.invoice_events OWNER TO alisaberi;

--
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid,
    line_number integer NOT NULL,
    description text,
    quantity numeric(20,4) DEFAULT 1,
    unit_price numeric(20,4),
    tax_rate numeric(5,2) DEFAULT 0,
    tax_amount numeric(20,2) DEFAULT 0,
    discount_rate numeric(5,2) DEFAULT 0,
    discount_amount numeric(20,2) DEFAULT 0,
    line_total numeric(20,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.invoice_line_items OWNER TO alisaberi;

--
-- Name: invoice_payment_methods; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_payment_methods (
    id integer NOT NULL,
    invoice_id character varying(50),
    method_type character varying(20) NOT NULL,
    is_enabled boolean DEFAULT true,
    fee_percentage numeric(5,4),
    fee_fixed numeric(10,2),
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT invoice_payment_methods_method_type_check CHECK (((method_type)::text = ANY ((ARRAY['wallet'::character varying, 'card'::character varying, 'bank'::character varying, 'crypto'::character varying])::text[])))
);


ALTER TABLE public.invoice_payment_methods OWNER TO alisaberi;

--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_payment_methods_id_seq OWNER TO alisaberi;

--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_payment_methods_id_seq OWNED BY public.invoice_payment_methods.id;


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_payments (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    invoice_id uuid,
    payer_id character varying(255),
    amount numeric(20,2) NOT NULL,
    payment_type character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    transaction_hash character varying(255),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    CONSTRAINT chk_payment_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_payment_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying, 'REVERSED'::character varying])::text[]))),
    CONSTRAINT chk_payment_type CHECK (((payment_type)::text = ANY ((ARRAY['EXACT'::character varying, 'PARTIAL'::character varying, 'OVERPAYMENT'::character varying, 'CREDIT'::character varying])::text[]))),
    CONSTRAINT chk_provider CHECK (((provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying, 'credit'::character varying])::text[])))
);


ALTER TABLE public.invoice_payments OWNER TO alisaberi;

--
-- Name: TABLE invoice_payments; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoice_payments IS 'Payment records for invoices with support for partial and overpayments';


--
-- Name: invoice_templates; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    name character varying(255) NOT NULL,
    description text,
    default_terms text,
    default_notes text,
    line_items_template jsonb,
    tax_rate numeric(5,2) DEFAULT 0.00,
    is_recurring boolean DEFAULT false,
    recurrence_pattern character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_recurrence_pattern CHECK (((recurrence_pattern IS NULL) OR ((recurrence_pattern)::text = ANY ((ARRAY['DAILY'::character varying, 'WEEKLY'::character varying, 'BIWEEKLY'::character varying, 'MONTHLY'::character varying, 'QUARTERLY'::character varying, 'ANNUALLY'::character varying])::text[]))))
);


ALTER TABLE public.invoice_templates OWNER TO alisaberi;

--
-- Name: invoice_tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_tokens (
    id integer NOT NULL,
    invoice_id character varying(50) NOT NULL,
    token_id character varying(255),
    chain character varying(20) NOT NULL,
    tx_hash character varying(255),
    from_user_id character varying(255),
    to_user_id character varying(255),
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    description text,
    due_date timestamp without time zone,
    ipfs_hash character varying(255),
    smart_contract_address character varying(255),
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    paid_at timestamp without time zone,
    payment_tx_hash character varying(255),
    paid_by_user_id character varying(255),
    line_items jsonb,
    metadata jsonb,
    tags character varying[],
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT invoice_tokens_chain_check CHECK (((chain)::text = ANY ((ARRAY['evm'::character varying, 'solana'::character varying])::text[]))),
    CONSTRAINT invoice_tokens_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'cancelled'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.invoice_tokens OWNER TO alisaberi;

--
-- Name: TABLE invoice_tokens; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoice_tokens IS 'Main table for tokenized invoices - foundation of invoice-first payment model';


--
-- Name: COLUMN invoice_tokens.invoice_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.invoice_id IS 'Unique invoice identifier (e.g., INV-1234567890-ABCD)';


--
-- Name: COLUMN invoice_tokens.token_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.token_id IS 'Blockchain token ID (NFT or SPL token)';


--
-- Name: COLUMN invoice_tokens.chain; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.chain IS 'Blockchain network: evm (Base L2) or solana';


--
-- Name: COLUMN invoice_tokens.ipfs_hash; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.invoice_tokens.ipfs_hash IS 'IPFS hash for invoice metadata storage';


--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.invoice_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_tokens_id_seq OWNER TO alisaberi;

--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.invoice_tokens_id_seq OWNED BY public.invoice_tokens.id;


--
-- Name: invoice_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoice_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_id uuid,
    wallet_address character varying(255) NOT NULL,
    blockchain character varying(50) DEFAULT 'polygon'::character varying,
    mode character varying(20) DEFAULT 'ephemeral'::character varying,
    is_ephemeral boolean DEFAULT true,
    persistence_threshold numeric(20,2),
    auto_sweep_enabled boolean DEFAULT true,
    quantum_resistant boolean DEFAULT false,
    quantum_key_id uuid,
    quantum_algorithm character varying(50),
    status character varying(50) DEFAULT 'active'::character varying,
    activated_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    swept_at timestamp with time zone,
    transaction_count integer DEFAULT 0,
    total_received numeric(20,2) DEFAULT 0,
    total_swept numeric(20,2) DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.invoice_wallets OWNER TO alisaberi;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_number character varying(100) NOT NULL,
    user_id character varying(255),
    organization_id uuid,
    type character varying(50),
    amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    client_name character varying(255),
    vendor_name character varying(255),
    description text,
    payment_method character varying(50),
    due_date date,
    paid_date date,
    is_recurring boolean DEFAULT false,
    create_ephemeral_wallet boolean DEFAULT false,
    ephemeral_wallet_created boolean DEFAULT false,
    wallet_mode character varying(20),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    solana_address character varying(255),
    recipient_id character varying(255),
    paid_amount numeric(20,2) DEFAULT 0.00,
    invoice_type character varying(50) DEFAULT 'ENTERPRISE'::character varying,
    metadata_uri text,
    paid_at timestamp without time zone,
    last_payment_at timestamp without time zone
);


ALTER TABLE public.invoices OWNER TO alisaberi;

--
-- Name: TABLE invoices; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.invoices IS 'Tokenized invoices stored as compressed NFTs on Solana blockchain';


--
-- Name: kyc_sessions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.kyc_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    provider public.kyc_provider,
    session_id character varying(255),
    inquiry_id character varying(255),
    status public.kyc_status,
    verification_level character varying(50),
    risk_score integer,
    checks_completed jsonb,
    documents_submitted jsonb,
    rejection_reasons jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.kyc_sessions OWNER TO alisaberi;

--
-- Name: loyalty_rewards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.loyalty_rewards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_name character varying(255) NOT NULL,
    program_type character varying(50),
    tiers jsonb DEFAULT '[]'::jsonb,
    point_value numeric(10,4) DEFAULT 0.01,
    earning_rules jsonb DEFAULT '{}'::jsonb,
    redemption_rules jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.loyalty_rewards OWNER TO alisaberi;

--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.loyalty_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    reward_program_id uuid,
    transaction_type character varying(50) NOT NULL,
    points_earned integer DEFAULT 0,
    points_redeemed integer DEFAULT 0,
    points_balance integer NOT NULL,
    reference_transaction_id character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.loyalty_transactions OWNER TO alisaberi;

--
-- Name: magic_links; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.magic_links (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    token character varying(512) NOT NULL,
    email character varying(255),
    purpose character varying(50) DEFAULT 'login'::character varying,
    used boolean DEFAULT false,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    used_at timestamp with time zone,
    ip_address inet
);


ALTER TABLE public.magic_links OWNER TO alisaberi;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.migrations OWNER TO alisaberi;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO alisaberi;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: multi_sig_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.multi_sig_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    transaction_data jsonb NOT NULL,
    signatures jsonb DEFAULT '[]'::jsonb,
    status public.multi_sig_status,
    executed_tx_hash character varying(255),
    created_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    executed_at timestamp with time zone,
    expires_at timestamp with time zone
);


ALTER TABLE public.multi_sig_transactions OWNER TO alisaberi;

--
-- Name: multi_sig_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.multi_sig_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_name character varying(255) NOT NULL,
    enterprise_id character varying(255),
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    threshold integer NOT NULL,
    signers jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.multi_sig_wallets OWNER TO alisaberi;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    type character varying(255),
    title character varying(500),
    message text,
    "receiverRead" character varying(10) DEFAULT 'unread'::character varying,
    "notificationData" text,
    "fromUserId" character varying(255),
    "toUserId" character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "notifications_receiverRead_check" CHECK ((("receiverRead")::text = ANY ((ARRAY['read'::character varying, 'unread'::character varying])::text[])))
);


ALTER TABLE public.notifications OWNER TO alisaberi;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO alisaberi;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: organizations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id character varying(100) NOT NULL,
    name character varying(255) NOT NULL,
    legal_name character varying(255),
    tax_id character varying(50),
    registration_number character varying(100),
    parent_id uuid,
    org_type character varying(50) DEFAULT 'standalone'::character varying,
    path_ids uuid[],
    hierarchy_level integer DEFAULT 0,
    email character varying(255),
    phone character varying(50),
    website character varying(255),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(50),
    postal_code character varying(20),
    country character varying(2),
    kyb_status public.kyc_status DEFAULT 'not_started'::public.kyc_status,
    aml_risk_score integer,
    compliance_status character varying(50),
    verified boolean DEFAULT false,
    verified_at timestamp with time zone,
    erp_customer_id character varying(100),
    erp_vendor_id character varying(100),
    erp_cost_center character varying(50),
    erp_sync_enabled boolean DEFAULT false,
    erp_last_sync timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    wallet_type character varying(50) DEFAULT 'enterprise'::character varying,
    feature_tier character varying(50) DEFAULT 'basic'::character varying,
    can_upgrade boolean DEFAULT true,
    upgraded_from_consumer boolean DEFAULT false,
    consumer_limits jsonb DEFAULT '{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}'::jsonb,
    parent_organization_id uuid,
    organization_type character varying(50) DEFAULT 'standalone'::character varying,
    email_verified boolean DEFAULT false,
    phone_verified boolean DEFAULT false,
    mfa_enabled boolean DEFAULT true,
    mfa_methods jsonb DEFAULT '["email", "sms"]'::jsonb,
    type character varying(100),
    industry character varying(100),
    status character varying(50) DEFAULT 'active'::character varying,
    kyc_status character varying(50) DEFAULT 'not_started'::character varying,
    compliance_score integer DEFAULT 75,
    description text,
    tenant_id uuid
);


ALTER TABLE public.organizations OWNER TO alisaberi;

--
-- Name: organization_hierarchy_view; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.organization_hierarchy_view AS
 WITH RECURSIVE org_tree AS (
         SELECT organizations.id,
            organizations.name,
            organizations.parent_organization_id,
            organizations.organization_type,
            organizations.wallet_type,
            organizations.feature_tier,
            0 AS level,
            ARRAY[organizations.id] AS path
           FROM public.organizations
          WHERE (organizations.parent_organization_id IS NULL)
        UNION ALL
         SELECT o.id,
            o.name,
            o.parent_organization_id,
            o.organization_type,
            o.wallet_type,
            o.feature_tier,
            (ot.level + 1),
            (ot.path || o.id)
           FROM (public.organizations o
             JOIN org_tree ot ON ((o.parent_organization_id = ot.id)))
        )
 SELECT id,
    name,
    parent_organization_id,
    organization_type,
    wallet_type,
    feature_tier,
    level,
    path
   FROM org_tree
  ORDER BY path;


ALTER VIEW public.organization_hierarchy_view OWNER TO alisaberi;

--
-- Name: organization_users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.organization_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    user_id character varying(255) NOT NULL,
    role public.org_user_role DEFAULT 'member'::public.org_user_role NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    is_primary boolean DEFAULT false,
    joined_at timestamp with time zone DEFAULT now(),
    invited_by character varying(255),
    invitation_status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.organization_users OWNER TO alisaberi;

--
-- Name: p2p_transfers; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.p2p_transfers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sender_id character varying(255) NOT NULL,
    recipient_address character varying(255) NOT NULL,
    recipient_id character varying(255),
    amount numeric(40,18) NOT NULL,
    currency character varying(10) DEFAULT 'USDC'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    provider character varying(50),
    settlement_time_ms integer,
    fee numeric(40,18),
    memo text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.p2p_transfers OWNER TO alisaberi;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.payment_methods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    method_type public.payment_method_type NOT NULL,
    card_last_four character varying(4),
    card_brand character varying(50),
    exp_month integer,
    exp_year integer,
    bank_name character varying(255),
    account_last_four character varying(4),
    routing_number character varying(20),
    wallet_address character varying(255),
    blockchain_network character varying(50),
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    verified boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.payment_methods OWNER TO alisaberi;

--
-- Name: payment_requests; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.payment_requests (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    requester_id character varying(255),
    payer_id character varying(255),
    amount numeric(20,2) NOT NULL,
    description text,
    status character varying(50) DEFAULT 'PENDING'::character varying,
    qr_code text,
    solana_address character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    paid_at timestamp without time zone,
    declined_at timestamp without time zone,
    decline_reason text,
    expires_at timestamp without time zone,
    CONSTRAINT chk_request_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_request_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'APPROVED'::character varying, 'PAID'::character varying, 'DECLINED'::character varying, 'EXPIRED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.payment_requests OWNER TO alisaberi;

--
-- Name: TABLE payment_requests; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.payment_requests IS 'P2P payment requests between consumers';


--
-- Name: price_feeds; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.price_feeds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token_symbol character varying(20) NOT NULL,
    base_currency character varying(10) NOT NULL,
    price numeric(40,18) NOT NULL,
    source public.oracle_source,
    confidence numeric(5,2),
    volume_24h numeric(40,18),
    market_cap numeric(40,18),
    metadata jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.price_feeds OWNER TO alisaberi;

--
-- Name: quantum_key_registry; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.quantum_key_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    algorithm character varying(50) NOT NULL,
    public_key text NOT NULL,
    key_hash character varying(255) NOT NULL,
    lattice_params jsonb,
    security_level integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    rotated_at timestamp with time zone
);


ALTER TABLE public.quantum_key_registry OWNER TO alisaberi;

--
-- Name: ready_cash_loans; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.ready_cash_loans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    loan_amount numeric(20,2) NOT NULL,
    interest_rate numeric(5,4) NOT NULL,
    term_days integer NOT NULL,
    total_repayment numeric(20,2) NOT NULL,
    amount_paid numeric(20,2) DEFAULT 0,
    next_payment_date date,
    status character varying(50) DEFAULT 'pending'::character varying,
    approved_at timestamp with time zone,
    disbursed_at timestamp with time zone,
    fully_paid_at timestamp with time zone,
    credit_score integer,
    risk_assessment jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ready_cash_loans OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.recurring_invoice_templates (
    id integer NOT NULL,
    user_id character varying(255),
    template_name character varying(255),
    to_user_id character varying(255),
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    description text,
    frequency character varying(20),
    interval_count integer DEFAULT 1,
    next_invoice_date date,
    end_date date,
    is_active boolean DEFAULT true,
    auto_send boolean DEFAULT true,
    auto_charge boolean DEFAULT false,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT recurring_invoice_templates_frequency_check CHECK (((frequency)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'yearly'::character varying])::text[])))
);


ALTER TABLE public.recurring_invoice_templates OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.recurring_invoice_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recurring_invoice_templates_id_seq OWNER TO alisaberi;

--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.recurring_invoice_templates_id_seq OWNED BY public.recurring_invoice_templates.id;


--
-- Name: sage_bank_reconciliations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_bank_reconciliations (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    bank_account_id character varying(255) NOT NULL,
    statement_date date NOT NULL,
    statement_balance numeric(15,2),
    reconciled_balance numeric(15,2),
    difference numeric(15,2),
    status character varying(20),
    reconciled_items jsonb DEFAULT '[]'::jsonb,
    outstanding_items jsonb DEFAULT '[]'::jsonb,
    reconciled_by character varying(255),
    reconciled_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_bank_reconciliations OWNER TO alisaberi;

--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_bank_reconciliations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_bank_reconciliations_id_seq OWNER TO alisaberi;

--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_bank_reconciliations_id_seq OWNED BY public.sage_bank_reconciliations.id;


--
-- Name: sage_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_connections (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    company_id character varying(255),
    company_name character varying(255),
    access_token text,
    refresh_token text,
    token_expiry timestamp without time zone,
    subscription_type character varying(50),
    region character varying(10),
    features jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_connections OWNER TO alisaberi;

--
-- Name: sage_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_connections_id_seq OWNER TO alisaberi;

--
-- Name: sage_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_connections_id_seq OWNED BY public.sage_connections.id;


--
-- Name: sage_entities; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_entities (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    sage_id character varying(255) NOT NULL,
    data jsonb NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb,
    audit_trail jsonb DEFAULT '[]'::jsonb,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    version integer DEFAULT 1
);


ALTER TABLE public.sage_entities OWNER TO alisaberi;

--
-- Name: sage_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_entities_id_seq OWNER TO alisaberi;

--
-- Name: sage_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_entities_id_seq OWNED BY public.sage_entities.id;


--
-- Name: sage_journal_entries; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_journal_entries (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    journal_id character varying(255) NOT NULL,
    reference character varying(100),
    date date NOT NULL,
    description text,
    total_amount numeric(15,2),
    currency_code character varying(3),
    journal_lines jsonb NOT NULL,
    attachments jsonb DEFAULT '[]'::jsonb,
    posted boolean DEFAULT false,
    created_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_journal_entries OWNER TO alisaberi;

--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_journal_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_journal_entries_id_seq OWNER TO alisaberi;

--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_journal_entries_id_seq OWNED BY public.sage_journal_entries.id;


--
-- Name: sage_ledger_accounts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_ledger_accounts (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    ledger_account_id character varying(255) NOT NULL,
    display_id character varying(50),
    nominal_code integer,
    name character varying(255),
    account_type character varying(50),
    category character varying(100),
    tax_rate_id character varying(255),
    is_control boolean DEFAULT false,
    is_active boolean DEFAULT true,
    balance numeric(15,2),
    currency_code character varying(3),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_ledger_accounts OWNER TO alisaberi;

--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_ledger_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_ledger_accounts_id_seq OWNER TO alisaberi;

--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_ledger_accounts_id_seq OWNED BY public.sage_ledger_accounts.id;


--
-- Name: sage_sync_queue; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_sync_queue (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    operation character varying(20) NOT NULL,
    data jsonb NOT NULL,
    priority integer DEFAULT 5,
    status character varying(20) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    error_message text,
    scheduled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone
);


ALTER TABLE public.sage_sync_queue OWNER TO alisaberi;

--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_sync_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_sync_queue_id_seq OWNER TO alisaberi;

--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_sync_queue_id_seq OWNED BY public.sage_sync_queue.id;


--
-- Name: sage_tax_returns; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sage_tax_returns (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    return_id character varying(255) NOT NULL,
    tax_type character varying(50),
    period_start date,
    period_end date,
    status character varying(20),
    total_sales numeric(15,2),
    total_purchases numeric(15,2),
    tax_due numeric(15,2),
    submission_date date,
    reference_number character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sage_tax_returns OWNER TO alisaberi;

--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.sage_tax_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sage_tax_returns_id_seq OWNER TO alisaberi;

--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.sage_tax_returns_id_seq OWNED BY public.sage_tax_returns.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    name character varying(255),
    key character varying(255),
    value character varying(255),
    "settingType" character varying(20) DEFAULT 'public'::character varying,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT "settings_settingType_check" CHECK ((("settingType")::text = ANY ((ARRAY['public'::character varying, 'private'::character varying])::text[]))),
    CONSTRAINT settings_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying])::text[])))
);


ALTER TABLE public.settings OWNER TO alisaberi;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO alisaberi;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: smart_contracts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.smart_contracts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id character varying(255),
    contract_name character varying(255) NOT NULL,
    contract_type character varying(50),
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    abi jsonb,
    bytecode text,
    source_code text,
    compiler_version character varying(50),
    optimization_enabled boolean,
    is_verified boolean DEFAULT false,
    is_upgradeable boolean DEFAULT false,
    solana_program_type public.solana_program_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    deployed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.smart_contracts OWNER TO alisaberi;

--
-- Name: spending_limit_history; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.spending_limit_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    spending_limit_id uuid,
    action character varying(50) NOT NULL,
    changed_fields jsonb,
    old_values jsonb,
    new_values jsonb,
    changed_by uuid,
    change_reason text,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT spending_limit_history_action_check CHECK (((action)::text = ANY ((ARRAY['created'::character varying, 'updated'::character varying, 'deleted'::character varying, 'reset'::character varying, 'override_applied'::character varying, 'override_expired'::character varying])::text[])))
);


ALTER TABLE public.spending_limit_history OWNER TO alisaberi;

--
-- Name: TABLE spending_limit_history; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.spending_limit_history IS 'Audit trail for all changes to spending limits';


--
-- Name: spending_limit_overrides; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.spending_limit_overrides (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    spending_limit_id uuid,
    original_amount numeric(20,2) NOT NULL,
    override_amount numeric(20,2) NOT NULL,
    reason text NOT NULL,
    requested_by uuid NOT NULL,
    approved_by uuid,
    approval_status character varying(20) DEFAULT 'pending'::character varying,
    approval_date timestamp without time zone,
    valid_from timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    valid_until timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT spending_limit_overrides_approval_status_check CHECK (((approval_status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.spending_limit_overrides OWNER TO alisaberi;

--
-- Name: TABLE spending_limit_overrides; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.spending_limit_overrides IS 'Tracks temporary overrides to spending limits with approval workflow';


--
-- Name: spending_limit_violations; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.spending_limit_violations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    spending_limit_id uuid,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    transaction_id uuid,
    attempted_amount numeric(20,2) NOT NULL,
    limit_amount numeric(20,2) NOT NULL,
    current_usage numeric(20,2),
    violation_type character varying(50) NOT NULL,
    transaction_type character varying(50),
    merchant_name character varying(255),
    merchant_category character varying(100),
    action_taken character varying(50) NOT NULL,
    override_applied boolean DEFAULT false,
    occurred_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    metadata jsonb,
    CONSTRAINT spending_limit_violations_action_taken_check CHECK (((action_taken)::text = ANY ((ARRAY['blocked'::character varying, 'warned'::character varying, 'notified'::character varying, 'approval_requested'::character varying])::text[])))
);


ALTER TABLE public.spending_limit_violations OWNER TO alisaberi;

--
-- Name: TABLE spending_limit_violations; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.spending_limit_violations IS 'Logs all spending limit violations for compliance and monitoring';


--
-- Name: spending_limits; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.spending_limits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    limit_type character varying(50) NOT NULL,
    limit_amount numeric(20,2) NOT NULL,
    current_usage numeric(20,2) DEFAULT 0,
    currency character varying(10) DEFAULT 'USD'::character varying,
    time_window character varying(20),
    reset_time timestamp without time zone,
    last_reset timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    condition_type character varying(50),
    condition_value jsonb,
    can_be_overridden boolean DEFAULT false,
    override_requires_approval boolean DEFAULT true,
    override_approval_level integer DEFAULT 1,
    temporary_override_amount numeric(20,2),
    temporary_override_expires timestamp without time zone,
    is_active boolean DEFAULT true,
    priority integer DEFAULT 0,
    enforcement_action character varying(50) DEFAULT 'block'::character varying,
    notification_threshold numeric(5,2) DEFAULT 80.00,
    created_by uuid,
    updated_by uuid,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    deleted_at timestamp without time zone,
    description text,
    compliance_category character varying(100),
    regulatory_requirement boolean DEFAULT false,
    CONSTRAINT spending_limits_condition_type_check CHECK (((condition_type)::text = ANY ((ARRAY['time_based'::character varying, 'location_based'::character varying, 'merchant_category'::character varying, 'recipient_type'::character varying])::text[]))),
    CONSTRAINT spending_limits_enforcement_action_check CHECK (((enforcement_action)::text = ANY ((ARRAY['block'::character varying, 'warn'::character varying, 'notify'::character varying, 'require_approval'::character varying])::text[]))),
    CONSTRAINT spending_limits_entity_type_check CHECK (((entity_type)::text = ANY ((ARRAY['user'::character varying, 'organization'::character varying, 'group'::character varying, 'role'::character varying])::text[]))),
    CONSTRAINT spending_limits_limit_type_check CHECK (((limit_type)::text = ANY ((ARRAY['daily_transaction'::character varying, 'weekly_transaction'::character varying, 'monthly_transaction'::character varying, 'single_transaction'::character varying, 'daily_withdrawal'::character varying, 'weekly_withdrawal'::character varying, 'monthly_withdrawal'::character varying, 'daily_transfer'::character varying, 'weekly_transfer'::character varying, 'monthly_transfer'::character varying, 'daily_card_spend'::character varying, 'weekly_card_spend'::character varying, 'monthly_card_spend'::character varying, 'atm_withdrawal'::character varying, 'international_transaction'::character varying, 'crypto_purchase'::character varying, 'p2p_transfer'::character varying])::text[]))),
    CONSTRAINT spending_limits_time_window_check CHECK (((time_window)::text = ANY ((ARRAY['daily'::character varying, 'weekly'::character varying, 'monthly'::character varying, 'per_transaction'::character varying])::text[])))
);


ALTER TABLE public.spending_limits OWNER TO alisaberi;

--
-- Name: TABLE spending_limits; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.spending_limits IS 'Stores spending limits for users, organizations, groups, and roles';


--
-- Name: split_bill_participants; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.split_bill_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    split_bill_id uuid,
    user_id character varying(255),
    email character varying(255),
    phone character varying(50),
    name character varying(255),
    amount_owed numeric(20,2) NOT NULL,
    amount_paid numeric(20,2) DEFAULT 0,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_date timestamp with time zone,
    transaction_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.split_bill_participants OWNER TO alisaberi;

--
-- Name: split_bills; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.split_bills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    creator_id character varying(255),
    title character varying(255) NOT NULL,
    total_amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    split_method character varying(50) DEFAULT 'equal'::character varying,
    custom_splits jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    settled_at timestamp with time zone,
    category character varying(100),
    description text,
    receipt_url text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.split_bills OWNER TO alisaberi;

--
-- Name: sso_providers; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.sso_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider_name character varying(100) NOT NULL,
    provider_type public.sso_provider_type NOT NULL,
    client_id character varying(255),
    client_secret_encrypted text,
    authorization_url text,
    token_url text,
    user_info_url text,
    jwks_url text,
    scopes text[],
    metadata jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sso_providers OWNER TO alisaberi;

--
-- Name: stablecoin_balances; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.stablecoin_balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    currency character varying(10) NOT NULL,
    amount numeric(40,18) DEFAULT 0,
    provider character varying(50) NOT NULL,
    last_synced timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stablecoin_balances OWNER TO alisaberi;

--
-- Name: super_app_bookings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.super_app_bookings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    booking_type character varying(50) NOT NULL,
    service_provider character varying(255),
    booking_reference character varying(100),
    booking_date timestamp with time zone NOT NULL,
    service_date timestamp with time zone,
    total_amount numeric(20,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    booking_details jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'confirmed'::character varying,
    cancellation_policy jsonb DEFAULT '{}'::jsonb,
    cancelled_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.super_app_bookings OWNER TO alisaberi;

--
-- Name: tenant_audit_logs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id character varying(255),
    action character varying(100) NOT NULL,
    resource_type character varying(50),
    resource_id character varying(255),
    ip_address inet,
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_audit_logs OWNER TO alisaberi;

--
-- Name: tenant_billing; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_billing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    billing_period_start date NOT NULL,
    billing_period_end date NOT NULL,
    subscription_fee numeric(10,2) DEFAULT 0,
    transaction_fees numeric(10,2) DEFAULT 0,
    api_usage_fees numeric(10,2) DEFAULT 0,
    storage_fees numeric(10,2) DEFAULT 0,
    total_amount numeric(10,2) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    invoice_url text,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_billing_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.tenant_billing OWNER TO alisaberi;

--
-- Name: tenant_users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    is_primary boolean DEFAULT false,
    status character varying(50) DEFAULT 'active'::character varying,
    joined_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    removed_at timestamp without time zone,
    CONSTRAINT tenant_users_role_check CHECK (((role)::text = ANY ((ARRAY['owner'::character varying, 'admin'::character varying, 'manager'::character varying, 'member'::character varying, 'viewer'::character varying])::text[]))),
    CONSTRAINT tenant_users_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'suspended'::character varying, 'removed'::character varying])::text[])))
);


ALTER TABLE public.tenant_users OWNER TO alisaberi;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_code character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    isolation_level character varying(50) DEFAULT 'row'::character varying NOT NULL,
    billing_tier character varying(50) DEFAULT 'free'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    wallet_derivation_path character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    gross_margin_percent numeric(5,2) DEFAULT 0,
    subscription_expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenants_billing_tier_check CHECK (((billing_tier)::text = ANY ((ARRAY['free'::character varying, 'small_business'::character varying, 'enterprise'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT tenants_isolation_level_check CHECK (((isolation_level)::text = ANY ((ARRAY['row'::character varying, 'schema'::character varying, 'database'::character varying])::text[]))),
    CONSTRAINT tenants_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'active'::character varying, 'suspended'::character varying, 'terminated'::character varying])::text[]))),
    CONSTRAINT tenants_type_check CHECK (((type)::text = ANY ((ARRAY['individual'::character varying, 'household_member'::character varying, 'small_business'::character varying, 'enterprise'::character varying, 'holding_company'::character varying])::text[])))
);


ALTER TABLE public.tenants OWNER TO alisaberi;

--
-- Name: users; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.users (
    id character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    mobile character varying(50),
    password_hash text,
    profile_image text,
    date_of_birth date,
    auth_level public.auth_level DEFAULT 'basic'::public.auth_level,
    require_mfa boolean DEFAULT false,
    mfa_grace_period_until timestamp with time zone,
    biometric_enabled boolean DEFAULT false,
    custody_type public.custody_type DEFAULT 'self'::public.custody_type,
    risk_profile public.risk_level DEFAULT 'low'::public.risk_level,
    last_risk_assessment timestamp with time zone,
    passwordless_enabled boolean DEFAULT false,
    recovery_email character varying(255),
    recovery_phone character varying(50),
    security_questions jsonb,
    trusted_ips inet[],
    allowed_countries character varying(2)[],
    blocked_countries character varying(2)[],
    failed_login_attempts integer DEFAULT 0,
    last_failed_login timestamp with time zone,
    account_locked_until timestamp with time zone,
    password_changed_at timestamp with time zone DEFAULT now(),
    password_history text[],
    session_timeout_minutes integer DEFAULT 30,
    mobile_verified boolean DEFAULT false,
    is_active boolean DEFAULT true,
    kyc_verified boolean DEFAULT false,
    kyc_level character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    user_type character varying(50) DEFAULT 'individual'::character varying,
    primary_organization_id uuid,
    consumer_kyc_level integer DEFAULT 1,
    consumer_daily_limit numeric(40,18) DEFAULT 1000,
    consumer_monthly_limit numeric(40,18) DEFAULT 30000,
    preferred_provider character varying(50) DEFAULT 'tempo'::character varying,
    family_group_id uuid,
    is_primary_user boolean DEFAULT true,
    mpin character varying(255),
    wallet_balance double precision DEFAULT 0,
    is_deleted boolean DEFAULT false,
    is_blocked boolean DEFAULT false,
    blocked_reason text,
    referral_code character varying(50),
    referred_by character varying(255),
    qr_code text,
    gender character varying(20),
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    zip_code character varying(20),
    phone character varying(50),
    primary_contact character varying(20) DEFAULT 'mobile'::character varying,
    phone_verified boolean DEFAULT false,
    email_verified boolean DEFAULT false,
    whatsapp_enabled boolean DEFAULT false,
    whatsapp_number character varying(50),
    notification_preferences jsonb DEFAULT '{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}'::jsonb,
    contact_metadata jsonb DEFAULT '{}'::jsonb,
    role character varying(50),
    onboarding_completed boolean DEFAULT false,
    onboarding_step character varying(50),
    CONSTRAINT users_primary_contact_check CHECK (((primary_contact)::text = ANY ((ARRAY['mobile'::character varying, 'phone'::character varying, 'email'::character varying, 'whatsapp'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO alisaberi;

--
-- Name: COLUMN users.mobile; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.mobile IS 'User mobile phone number (primary for SMS/2FA)';


--
-- Name: COLUMN users.mobile_verified; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.mobile_verified IS 'Whether mobile number has been verified';


--
-- Name: COLUMN users.user_type; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.user_type IS 'Type of user: individual (direct consumer) or organization (business user)';


--
-- Name: COLUMN users.primary_organization_id; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.primary_organization_id IS 'Primary organization ID for business users, NULL for individuals';


--
-- Name: COLUMN users.phone; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.phone IS 'User landline/office phone number (optional, for voice auth)';


--
-- Name: COLUMN users.primary_contact; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.primary_contact IS 'Preferred contact method: mobile or phone';


--
-- Name: COLUMN users.phone_verified; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.phone_verified IS 'Whether landline phone has been verified';


--
-- Name: COLUMN users.email_verified; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.email_verified IS 'Whether email address has been verified';


--
-- Name: COLUMN users.whatsapp_enabled; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.whatsapp_enabled IS 'Whether user has WhatsApp on their mobile number';


--
-- Name: COLUMN users.whatsapp_number; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.whatsapp_number IS 'WhatsApp number (if different from mobile)';


--
-- Name: COLUMN users.notification_preferences; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.notification_preferences IS 'Channel preferences per notification type';


--
-- Name: COLUMN users.contact_metadata; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON COLUMN public.users.contact_metadata IS 'Additional contact preferences (timezone, language, etc)';


--
-- Name: tenant_hierarchy_view; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.tenant_hierarchy_view AS
 SELECT t.id AS tenant_id,
    t.tenant_code,
    t.name AS tenant_name,
    t.type AS tenant_type,
    t.status AS tenant_status,
    NULL::uuid AS organization_id,
    NULL::text AS organization_name,
    NULL::text AS organization_type,
    u.id AS user_id,
    u.email AS user_email,
    u.first_name,
    u.last_name,
    tu.role AS user_role,
    'individual'::text AS access_type,
    tu.is_primary,
        CASE
            WHEN ((t.type)::text = 'individual'::text) THEN 'Consumer'::text
            WHEN ((t.type)::text = 'household_member'::text) THEN 'Household Member'::text
            ELSE 'Unknown'::text
        END AS user_category
   FROM ((public.tenants t
     JOIN public.tenant_users tu ON ((t.id = tu.tenant_id)))
     JOIN public.users u ON (((tu.user_id)::text = (u.id)::text)))
  WHERE (((tu.status)::text = 'active'::text) AND (NOT (EXISTS ( SELECT 1
           FROM public.organization_users ou
          WHERE ((ou.user_id)::text = (u.id)::text)))))
UNION ALL
 SELECT t.id AS tenant_id,
    t.tenant_code,
    t.name AS tenant_name,
    t.type AS tenant_type,
    t.status AS tenant_status,
    o.id AS organization_id,
    o.name AS organization_name,
    o.organization_type,
    u.id AS user_id,
    u.email AS user_email,
    u.first_name,
    u.last_name,
    (ou.role)::text AS user_role,
    'organization'::text AS access_type,
    false AS is_primary,
        CASE
            WHEN ((t.type)::text = 'small_business'::text) THEN 'Small Business'::text
            WHEN ((t.type)::text = 'enterprise'::text) THEN 'Enterprise'::text
            WHEN ((t.type)::text = 'holding_company'::text) THEN 'Holding Company'::text
            ELSE 'Business'::text
        END AS user_category
   FROM (((public.tenants t
     JOIN public.organizations o ON ((t.id = o.tenant_id)))
     JOIN public.organization_users ou ON ((o.id = ou.organization_id)))
     JOIN public.users u ON (((ou.user_id)::text = (u.id)::text)))
  WHERE ((ou.invitation_status)::text = 'active'::text);


ALTER VIEW public.tenant_hierarchy_view OWNER TO alisaberi;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    setting_type character varying(50) DEFAULT 'string'::character varying,
    is_encrypted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_settings OWNER TO alisaberi;

--
-- Name: tenant_summary; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.tenant_summary AS
 SELECT 'Individual Consumers'::text AS category,
    count(DISTINCT tu.user_id) AS user_count,
    count(DISTINCT tu.tenant_id) AS tenant_count
   FROM public.tenant_users tu
  WHERE (NOT (EXISTS ( SELECT 1
           FROM public.organization_users ou
          WHERE ((ou.user_id)::text = (tu.user_id)::text))))
UNION ALL
 SELECT 'Business Users'::text AS category,
    count(DISTINCT ou.user_id) AS user_count,
    count(DISTINCT o.tenant_id) AS tenant_count
   FROM (public.organization_users ou
     JOIN public.organizations o ON ((ou.organization_id = o.id)))
  WHERE (o.tenant_id IS NOT NULL)
UNION ALL
 SELECT 'Organizations'::text AS category,
    count(*) AS user_count,
    count(DISTINCT organizations.tenant_id) AS tenant_count
   FROM public.organizations
  WHERE (organizations.tenant_id IS NOT NULL);


ALTER VIEW public.tenant_summary OWNER TO alisaberi;

--
-- Name: tenant_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    wallet_id uuid,
    transaction_type character varying(50) NOT NULL,
    amount numeric(20,8) NOT NULL,
    currency character varying(10) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    external_reference character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tenant_transactions OWNER TO alisaberi;

--
-- Name: tenant_vault_keys; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_vault_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    key_type character varying(50) NOT NULL,
    public_key text,
    encrypted_private_key text,
    key_metadata jsonb DEFAULT '{}'::jsonb,
    rotation_date timestamp without time zone,
    expiration_date timestamp without time zone,
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_vault_keys_key_type_check CHECK (((key_type)::text = ANY ((ARRAY['master'::character varying, 'encryption'::character varying, 'signing'::character varying, 'api'::character varying])::text[]))),
    CONSTRAINT tenant_vault_keys_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'rotating'::character varying, 'expired'::character varying, 'revoked'::character varying])::text[])))
);


ALTER TABLE public.tenant_vault_keys OWNER TO alisaberi;

--
-- Name: tenant_wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tenant_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    wallet_type character varying(50) NOT NULL,
    currency character varying(10) NOT NULL,
    balance numeric(20,8) DEFAULT 0,
    available_balance numeric(20,8) DEFAULT 0,
    pending_balance numeric(20,8) DEFAULT 0,
    blockchain_address character varying(255),
    circle_wallet_id character varying(255),
    tempo_wallet_id character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT tenant_wallets_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'frozen'::character varying, 'closed'::character varying])::text[]))),
    CONSTRAINT tenant_wallets_wallet_type_check CHECK (((wallet_type)::text = ANY ((ARRAY['fiat'::character varying, 'crypto'::character varying, 'stablecoin'::character varying, 'treasury'::character varying])::text[])))
);


ALTER TABLE public.tenant_wallets OWNER TO alisaberi;

--
-- Name: tillipay_cards; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tillipay_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    tillipay_card_id character varying(255),
    card_number_masked character varying(20),
    card_type public.card_type,
    card_network public.card_network,
    card_status character varying(50),
    expiry_month integer,
    expiry_year integer,
    billing_address jsonb,
    spending_limits jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    activated_at timestamp with time zone,
    deactivated_at timestamp with time zone
);


ALTER TABLE public.tillipay_cards OWNER TO alisaberi;

--
-- Name: tillipay_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tillipay_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    card_id uuid,
    tillipay_tx_id character varying(255),
    transaction_type public.transaction_type,
    amount numeric(20,2),
    currency character varying(10),
    merchant_name character varying(255),
    merchant_category character varying(50),
    status public.transaction_status,
    authorization_code character varying(50),
    decline_reason character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tillipay_transactions OWNER TO alisaberi;

--
-- Name: tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id character varying(255),
    token_name character varying(255) NOT NULL,
    token_symbol character varying(20) NOT NULL,
    token_type public.token_standard,
    chain public.blockchain_network NOT NULL,
    contract_address character varying(255),
    mint_address character varying(255),
    decimals integer DEFAULT 18,
    total_supply numeric(40,18),
    max_supply numeric(40,18),
    is_paused boolean DEFAULT false,
    is_compliant boolean DEFAULT true,
    compliance_standard character varying(50),
    stablecoin_type public.stablecoin_backing,
    stablecoin_peg public.stablecoin_peg,
    asset_type public.crypto_asset_type,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    deployed_at timestamp with time zone
);


ALTER TABLE public.tokens OWNER TO alisaberi;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.transactions (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    wallet_id uuid,
    type public.transaction_type NOT NULL,
    amount numeric(40,18) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    from_address character varying(255),
    to_address character varying(255),
    from_user_id character varying(255),
    to_user_id character varying(255),
    blockchain_network character varying(50),
    transaction_hash character varying(255),
    block_number bigint,
    gas_used bigint,
    gas_price numeric(40,18),
    status public.transaction_status DEFAULT 'pending'::public.transaction_status,
    status_message text,
    compliance_checked boolean DEFAULT false,
    compliance_status character varying(50),
    risk_score integer,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    batch_id character varying(255),
    "actionType" character varying(20),
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "transactionUserId" character varying(255),
    "senderId" character varying(255),
    "receiverId" character varying(255),
    "transactionId" character varying(255),
    "transactionType" character varying(20),
    "paymentMethod" character varying(20),
    "paymentStatus" character varying(20) DEFAULT 'completed'::character varying,
    "cardType" character varying(255),
    "cardName" character varying(255),
    "bankName" character varying(255),
    "last4Digit" character varying(10),
    "apiReponse" text,
    "cnpToken" character varying(255),
    "paymentRequestId" character varying(255),
    "parentId" character varying(255),
    CONSTRAINT "transactions_actionType_check" CHECK ((("actionType")::text = ANY ((ARRAY['deposit'::character varying, 'withdrawal'::character varying, 'transfer'::character varying])::text[]))),
    CONSTRAINT "transactions_paymentMethod_check" CHECK ((("paymentMethod")::text = ANY ((ARRAY['card'::character varying, 'wallet'::character varying, 'account'::character varying])::text[]))),
    CONSTRAINT "transactions_paymentStatus_check" CHECK ((("paymentStatus")::text = ANY ((ARRAY['pending'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'failed'::character varying])::text[]))),
    CONSTRAINT "transactions_transactionType_check" CHECK ((("transactionType")::text = ANY ((ARRAY['credit'::character varying, 'debit'::character varying])::text[])))
);


ALTER TABLE public.transactions OWNER TO alisaberi;

--
-- Name: treasury_accounts; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_accounts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id character varying(255),
    account_name character varying(255) NOT NULL,
    chain public.blockchain_network NOT NULL,
    address character varying(255) NOT NULL,
    balance numeric(40,18) DEFAULT 0,
    locked_balance numeric(40,18) DEFAULT 0,
    reserve_ratio numeric(5,2),
    account_type character varying(50),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.treasury_accounts OWNER TO alisaberi;

--
-- Name: treasury_swaps; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_swaps (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    organization_id uuid,
    amount numeric(20,2) NOT NULL,
    from_provider character varying(50) NOT NULL,
    to_provider character varying(50) NOT NULL,
    from_balance_before numeric(20,2),
    from_balance_after numeric(20,2),
    to_balance_before numeric(20,2),
    to_balance_after numeric(20,2),
    swap_reason text,
    transaction_hash character varying(255),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    CONSTRAINT chk_different_providers CHECK (((from_provider)::text <> (to_provider)::text)),
    CONSTRAINT chk_swap_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT chk_swap_providers CHECK ((((from_provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying])::text[])) AND ((to_provider)::text = ANY ((ARRAY['tempo'::character varying, 'circle'::character varying])::text[])))),
    CONSTRAINT chk_swap_status CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.treasury_swaps OWNER TO alisaberi;

--
-- Name: TABLE treasury_swaps; Type: COMMENT; Schema: public; Owner: alisaberi
--

COMMENT ON TABLE public.treasury_swaps IS 'Audit trail for treasury swaps between Tempo and Circle';


--
-- Name: treasury_transactions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.treasury_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    treasury_account_id uuid,
    transaction_type public.transaction_type,
    amount numeric(40,18) NOT NULL,
    token_id uuid,
    from_address character varying(255),
    to_address character varying(255),
    blockchain_tx_id uuid,
    status public.transaction_status,
    executed_by character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    executed_at timestamp with time zone
);


ALTER TABLE public.treasury_transactions OWNER TO alisaberi;

--
-- Name: user_biometrics; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_biometrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    device_id uuid,
    biometric_type public.biometric_type NOT NULL,
    biometric_hash text NOT NULL,
    salt character varying(255) NOT NULL,
    algorithm character varying(50) DEFAULT 'PBKDF2'::character varying,
    is_active boolean DEFAULT true,
    enrolled_at timestamp with time zone DEFAULT now(),
    last_verified_at timestamp with time zone,
    failed_attempts integer DEFAULT 0,
    locked_until timestamp with time zone
);


ALTER TABLE public.user_biometrics OWNER TO alisaberi;

--
-- Name: user_devices; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_devices (
    id uuid,
    "userId" character varying(255),
    "deviceId" character varying(255),
    "deviceName" character varying(255),
    "deviceType" public.device_type,
    "deviceModel" character varying(255),
    "osVersion" character varying(50),
    "appVersion" character varying(50),
    timezone text,
    "biometricEnabled" boolean,
    "isTrusted" boolean,
    created_at timestamp with time zone,
    "lastSeen" timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_devices OWNER TO alisaberi;

--
-- Name: user_devices_enhanced; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_devices_enhanced (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    device_id character varying(255) NOT NULL,
    device_name character varying(255),
    device_type public.device_type NOT NULL,
    device_model character varying(255),
    os_version character varying(50),
    app_version character varying(50),
    push_token text,
    biometric_enabled boolean DEFAULT false,
    biometric_type public.biometric_type,
    device_fingerprint jsonb,
    trust_level integer DEFAULT 0,
    is_trusted boolean DEFAULT false,
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    blocked_at timestamp with time zone,
    blocked_reason character varying(255),
    CONSTRAINT user_devices_enhanced_trust_level_check CHECK (((trust_level >= 0) AND (trust_level <= 100)))
);


ALTER TABLE public.user_devices_enhanced OWNER TO alisaberi;

--
-- Name: user_mfa_settings; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_mfa_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    mfa_type public.mfa_type NOT NULL,
    is_primary boolean DEFAULT false,
    is_enabled boolean DEFAULT true,
    secret_encrypted text,
    phone_number character varying(50),
    email character varying(255),
    backup_codes text[],
    last_used_at timestamp with time zone,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_mfa_settings OWNER TO alisaberi;

--
-- Name: user_organization_view; Type: VIEW; Schema: public; Owner: alisaberi
--

CREATE VIEW public.user_organization_view AS
 SELECT u.id AS user_id,
    u.email,
    u.username,
    u.first_name,
    u.last_name,
    u.user_type,
    u.primary_organization_id,
    o.id AS organization_id,
    o.name AS organization_name,
    o.wallet_type,
    o.feature_tier,
    ou.role AS user_role,
    ou.is_primary,
    ou.joined_at,
        CASE
            WHEN ((u.user_type)::text = 'individual'::text) THEN 'Individual Consumer'::text
            WHEN (((u.user_type)::text = 'organization'::text) AND ((o.wallet_type)::text = 'consumer'::text)) THEN 'Small Business User'::text
            WHEN (((u.user_type)::text = 'organization'::text) AND ((o.wallet_type)::text = 'enterprise'::text)) THEN 'Enterprise User'::text
            ELSE 'Unknown'::text
        END AS user_category
   FROM ((public.users u
     LEFT JOIN public.organization_users ou ON ((((u.id)::text = (ou.user_id)::text) AND ((ou.invitation_status)::text = 'active'::text))))
     LEFT JOIN public.organizations o ON ((ou.organization_id = o.id)));


ALTER VIEW public.user_organization_view OWNER TO alisaberi;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255) NOT NULL,
    profile_type character varying(50) NOT NULL,
    date_of_birth date,
    ssn_last_four character varying(4),
    personal_address jsonb,
    emergency_contact jsonb,
    job_title character varying(255),
    department character varying(255),
    employee_id character varying(100),
    business_email character varying(255),
    business_phone character varying(50),
    profile_picture_url text,
    preferences jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO alisaberi;

--
-- Name: user_sso_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_sso_connections (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    provider_id uuid,
    external_user_id character varying(255) NOT NULL,
    access_token_encrypted text,
    refresh_token_encrypted text,
    token_expires_at timestamp with time zone,
    profile_data jsonb,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_sso_connections OWNER TO alisaberi;

--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.user_tokens (
    id character varying(255) NOT NULL,
    user_id character varying(255),
    token text,
    refresh_token text,
    type character varying(50),
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_tokens OWNER TO alisaberi;

--
-- Name: users_backup_20250929; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.users_backup_20250929 (
    id character varying(255),
    email character varying(255),
    username character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    mobile character varying(50),
    password_hash text,
    profile_image text,
    date_of_birth date,
    auth_level public.auth_level,
    require_mfa boolean,
    mfa_grace_period_until timestamp with time zone,
    biometric_enabled boolean,
    custody_type public.custody_type,
    risk_profile public.risk_level,
    last_risk_assessment timestamp with time zone,
    passwordless_enabled boolean,
    recovery_email character varying(255),
    recovery_phone character varying(50),
    security_questions jsonb,
    trusted_ips inet[],
    allowed_countries character varying(2)[],
    blocked_countries character varying(2)[],
    failed_login_attempts integer,
    last_failed_login timestamp with time zone,
    account_locked_until timestamp with time zone,
    password_changed_at timestamp with time zone,
    password_history text[],
    session_timeout_minutes integer,
    mobile_verified boolean,
    is_active boolean,
    kyc_verified boolean,
    kyc_level character varying(50),
    metadata jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    last_login timestamp with time zone,
    user_type character varying(50),
    primary_organization_id uuid,
    consumer_kyc_level integer,
    consumer_daily_limit numeric(40,18),
    consumer_monthly_limit numeric(40,18),
    preferred_provider character varying(50),
    family_group_id uuid,
    is_primary_user boolean,
    mpin character varying(255),
    wallet_balance double precision,
    is_deleted boolean,
    is_blocked boolean,
    blocked_reason text,
    referral_code character varying(50),
    referred_by character varying(255),
    qr_code text,
    gender character varying(20),
    address text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    zip_code character varying(20),
    phone character varying(50),
    primary_contact character varying(10),
    phone_verified boolean
);


ALTER TABLE public.users_backup_20250929 OWNER TO alisaberi;

--
-- Name: wallet_lifecycle_events; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_lifecycle_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    event_type character varying(50) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb,
    blockchain_tx_hash character varying(255),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallet_lifecycle_events OWNER TO alisaberi;

--
-- Name: wallet_mode_decisions; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallet_mode_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    decision_type character varying(50) NOT NULL,
    from_mode character varying(20),
    to_mode character varying(20),
    confidence_score numeric(5,4),
    factors jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.wallet_mode_decisions OWNER TO alisaberi;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    organization_id uuid,
    wallet_name character varying(255),
    wallet_type character varying(50) NOT NULL,
    wallet_address character varying(255),
    public_key text,
    blockchain character varying(50) DEFAULT 'base'::character varying,
    chain_id integer,
    is_smart_wallet boolean DEFAULT false,
    contract_address character varying(255),
    balance numeric(40,18) DEFAULT 0,
    locked_balance numeric(40,18) DEFAULT 0,
    kyc_status public.kyc_status DEFAULT 'not_started'::public.kyc_status,
    aml_verified boolean DEFAULT false,
    sanctions_checked boolean DEFAULT false,
    is_active boolean DEFAULT true,
    is_primary boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    provider character varying(50),
    type character varying(50)
);


ALTER TABLE public.wallets OWNER TO alisaberi;

--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.webauthn_credentials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(255),
    credential_id text NOT NULL,
    public_key text NOT NULL,
    counter bigint DEFAULT 0,
    device_type character varying(50),
    name character varying(255),
    transports text[],
    backup_eligible boolean DEFAULT false,
    backup_state boolean DEFAULT false,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.webauthn_credentials OWNER TO alisaberi;

--
-- Name: zk_compliance_proofs; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zk_compliance_proofs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    wallet_id uuid,
    proof_type character varying(50) NOT NULL,
    proof_data text NOT NULL,
    verification_key text,
    is_valid boolean,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.zk_compliance_proofs OWNER TO alisaberi;

--
-- Name: zoho_automation_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_automation_rules (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    rule_name character varying(255) NOT NULL,
    trigger_type character varying(50) NOT NULL,
    conditions jsonb NOT NULL,
    actions jsonb NOT NULL,
    enabled boolean DEFAULT true,
    priority integer DEFAULT 0,
    last_triggered timestamp without time zone,
    execution_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_automation_rules OWNER TO alisaberi;

--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_automation_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_automation_rules_id_seq OWNER TO alisaberi;

--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_automation_rules_id_seq OWNED BY public.zoho_automation_rules.id;


--
-- Name: zoho_connections; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_connections (
    id integer NOT NULL,
    organization_id character varying(255) NOT NULL,
    account_id character varying(255) NOT NULL,
    organization_name character varying(255),
    access_token text,
    refresh_token text,
    token_expiry timestamp without time zone,
    scope text,
    region character varying(10),
    features jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_connections OWNER TO alisaberi;

--
-- Name: zoho_connections_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_connections_id_seq OWNER TO alisaberi;

--
-- Name: zoho_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_connections_id_seq OWNED BY public.zoho_connections.id;


--
-- Name: zoho_entities; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_entities (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255) NOT NULL,
    data jsonb NOT NULL,
    custom_fields jsonb DEFAULT '{}'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    attachments jsonb DEFAULT '[]'::jsonb,
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_entities OWNER TO alisaberi;

--
-- Name: zoho_entities_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_entities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_entities_id_seq OWNER TO alisaberi;

--
-- Name: zoho_entities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_entities_id_seq OWNED BY public.zoho_entities.id;


--
-- Name: zoho_recurring_profiles; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_recurring_profiles (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    profile_id character varying(255) NOT NULL,
    profile_type character varying(50) NOT NULL,
    customer_id character varying(255),
    frequency character varying(20),
    start_date date,
    end_date date,
    next_invoice_date date,
    total_amount numeric(15,2),
    currency_code character varying(3),
    status character varying(20),
    line_items jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_recurring_profiles OWNER TO alisaberi;

--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_recurring_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_recurring_profiles_id_seq OWNER TO alisaberi;

--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_recurring_profiles_id_seq OWNED BY public.zoho_recurring_profiles.id;


--
-- Name: zoho_sync_history; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_sync_history (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    entity_type character varying(50) NOT NULL,
    sync_type character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    records_synced integer DEFAULT 0,
    errors integer DEFAULT 0,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    error_details jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.zoho_sync_history OWNER TO alisaberi;

--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_sync_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_sync_history_id_seq OWNER TO alisaberi;

--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_sync_history_id_seq OWNED BY public.zoho_sync_history.id;


--
-- Name: zoho_tax_rules; Type: TABLE; Schema: public; Owner: alisaberi
--

CREATE TABLE public.zoho_tax_rules (
    id integer NOT NULL,
    account_id character varying(255) NOT NULL,
    tax_id character varying(255) NOT NULL,
    tax_name character varying(255),
    tax_percentage numeric(10,4),
    tax_type character varying(50),
    is_compound boolean DEFAULT false,
    is_inclusive boolean DEFAULT false,
    region_codes jsonb DEFAULT '[]'::jsonb,
    product_categories jsonb DEFAULT '[]'::jsonb,
    exemptions jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.zoho_tax_rules OWNER TO alisaberi;

--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: alisaberi
--

CREATE SEQUENCE public.zoho_tax_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.zoho_tax_rules_id_seq OWNER TO alisaberi;

--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alisaberi
--

ALTER SEQUENCE public.zoho_tax_rules_id_seq OWNED BY public.zoho_tax_rules.id;


--
-- Name: countries id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.countries ALTER COLUMN id SET DEFAULT nextval('public.countries_id_seq'::regclass);


--
-- Name: invoice_attachments id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments ALTER COLUMN id SET DEFAULT nextval('public.invoice_attachments_id_seq'::regclass);


--
-- Name: invoice_batch_items id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_batch_items_id_seq'::regclass);


--
-- Name: invoice_batches id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches ALTER COLUMN id SET DEFAULT nextval('public.invoice_batches_id_seq'::regclass);


--
-- Name: invoice_payment_methods id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods ALTER COLUMN id SET DEFAULT nextval('public.invoice_payment_methods_id_seq'::regclass);


--
-- Name: invoice_tokens id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens ALTER COLUMN id SET DEFAULT nextval('public.invoice_tokens_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: recurring_invoice_templates id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates ALTER COLUMN id SET DEFAULT nextval('public.recurring_invoice_templates_id_seq'::regclass);


--
-- Name: sage_bank_reconciliations id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations ALTER COLUMN id SET DEFAULT nextval('public.sage_bank_reconciliations_id_seq'::regclass);


--
-- Name: sage_connections id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections ALTER COLUMN id SET DEFAULT nextval('public.sage_connections_id_seq'::regclass);


--
-- Name: sage_entities id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities ALTER COLUMN id SET DEFAULT nextval('public.sage_entities_id_seq'::regclass);


--
-- Name: sage_journal_entries id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries ALTER COLUMN id SET DEFAULT nextval('public.sage_journal_entries_id_seq'::regclass);


--
-- Name: sage_ledger_accounts id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts ALTER COLUMN id SET DEFAULT nextval('public.sage_ledger_accounts_id_seq'::regclass);


--
-- Name: sage_sync_queue id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue ALTER COLUMN id SET DEFAULT nextval('public.sage_sync_queue_id_seq'::regclass);


--
-- Name: sage_tax_returns id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns ALTER COLUMN id SET DEFAULT nextval('public.sage_tax_returns_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: zoho_automation_rules id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules ALTER COLUMN id SET DEFAULT nextval('public.zoho_automation_rules_id_seq'::regclass);


--
-- Name: zoho_connections id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections ALTER COLUMN id SET DEFAULT nextval('public.zoho_connections_id_seq'::regclass);


--
-- Name: zoho_entities id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities ALTER COLUMN id SET DEFAULT nextval('public.zoho_entities_id_seq'::regclass);


--
-- Name: zoho_recurring_profiles id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles ALTER COLUMN id SET DEFAULT nextval('public.zoho_recurring_profiles_id_seq'::regclass);


--
-- Name: zoho_sync_history id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history ALTER COLUMN id SET DEFAULT nextval('public.zoho_sync_history_id_seq'::regclass);


--
-- Name: zoho_tax_rules id; Type: DEFAULT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules ALTER COLUMN id SET DEFAULT nextval('public.zoho_tax_rules_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.activity_logs (id, admin_id, user_id, "userId", transaction_id, "transactionId", ip, activity_type, "activityType", message, created_at, "createdAt", updated_at, "updatedAt", action, description, "ipAddress", "adminId", metadata, "userAgent", method, endpoint, "statusCode", "responseTime", "errorDetails") FROM stdin;
1a4e7adf-3b94-45e5-bc87-a951eb98d205	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 09:20:56.117202	2025-09-29 09:20:56.117202	2025-09-29 09:20:56.117202	2025-09-29 09:20:56.117202	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
4c81f9e7-49ab-47fd-956a-283283e2ef70	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 14:46:32.952788	2025-09-29 14:46:32.952788	2025-09-29 14:46:32.952788	2025-09-29 14:46:32.952788	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f17870b9-d33f-4fed-84df-80e3da2a8e35	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:36:33.457337	2025-09-29 16:36:33.457337	2025-09-29 16:36:33.457337	2025-09-29 16:36:33.457337	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
435fb2df-d279-4dee-b38b-946d56cdd81f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:45:57.538997	2025-09-29 16:45:57.538997	2025-09-29 16:45:57.538997	2025-09-29 16:45:57.538997	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
e4f0e621-b47e-4f31-9fbf-973e960bbac7	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:48:12.483718	2025-09-29 16:48:12.483718	2025-09-29 16:48:12.483718	2025-09-29 16:48:12.483718	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
711c29e3-090f-405a-a020-83b0983e92a1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:48:14.162318	2025-09-29 16:48:14.162318	2025-09-29 16:48:14.162318	2025-09-29 16:48:14.162318	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d34e552f-5ef8-4579-b28b-ce8593cd22c5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:48:16.864948	2025-09-29 16:48:16.864948	2025-09-29 16:48:16.864948	2025-09-29 16:48:16.864948	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9c442301-259d-4f1e-b9fe-2fab5d92785e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 16:48:20.811436	2025-09-29 16:48:20.811436	2025-09-29 16:48:20.811436	2025-09-29 16:48:20.811436	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
aff7d0c2-242f-47a4-8241-606f01370600	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:06:46.611907	2025-09-29 17:06:46.611907	2025-09-29 17:06:46.611907	2025-09-29 17:06:46.611907	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
3756b82d-10ee-4920-b831-33ec8ea7f88f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:09:22.723665	2025-09-29 17:09:22.723665	2025-09-29 17:09:22.723665	2025-09-29 17:09:22.723665	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
32b96deb-68a7-4908-9f5b-05faa3350aa5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:15:58.860397	2025-09-29 17:15:58.860397	2025-09-29 17:15:58.860397	2025-09-29 17:15:58.860397	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
810e6740-91d9-47b4-80bc-044df744f658	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:20:09.405796	2025-09-29 17:20:09.405796	2025-09-29 17:20:09.405796	2025-09-29 17:20:09.405796	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
28a30eb3-8d60-4d39-85b5-a83392d0e3a6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:22:07.684696	2025-09-29 17:22:07.684696	2025-09-29 17:22:07.684696	2025-09-29 17:22:07.684696	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a45c2968-2562-4865-9ec6-849bfa85e33a	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:22:09.387107	2025-09-29 17:22:09.387107	2025-09-29 17:22:09.387107	2025-09-29 17:22:09.387107	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
450a240b-cf77-4b1f-a3a1-59b38dac57a8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:22:12.062559	2025-09-29 17:22:12.062559	2025-09-29 17:22:12.062559	2025-09-29 17:22:12.062559	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
eca79bb2-8de0-43e7-bdc9-a31bcc120732	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:22:14.828361	2025-09-29 17:22:14.828361	2025-09-29 17:22:14.828361	2025-09-29 17:22:14.828361	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1bd02b92-732b-47e6-8234-872d5321d53c	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:32:30.005859	2025-09-29 17:32:30.005859	2025-09-29 17:32:30.005859	2025-09-29 17:32:30.005859	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
c68f7acc-3f4c-4457-8277-0f503626115b	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:50:01.35344	2025-09-29 17:50:01.35344	2025-09-29 17:50:01.35344	2025-09-29 17:50:01.35344	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
95a48092-df98-4b79-9d47-ab23795dc9e1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:50:03.958617	2025-09-29 17:50:03.958617	2025-09-29 17:50:03.958617	2025-09-29 17:50:03.958617	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
e54f12ed-dee0-4518-bcd9-bb2ce71fc07f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 17:50:51.483833	2025-09-29 17:50:51.483833	2025-09-29 17:50:51.483833	2025-09-29 17:50:51.483833	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
f64857f6-b17b-4da6-8d63-7b7e1e34adc5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:14:20.161244	2025-09-29 18:14:20.161244	2025-09-29 18:14:20.161244	2025-09-29 18:14:20.161244	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
28c7a830-17f6-4a5b-912f-65053002b7d3	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:14:49.404941	2025-09-29 18:14:49.404941	2025-09-29 18:14:49.404941	2025-09-29 18:14:49.404941	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ecd501d1-61e0-403c-ac36-7ef3e85b4a94	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:14:51.274994	2025-09-29 18:14:51.274994	2025-09-29 18:14:51.274994	2025-09-29 18:14:51.274994	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a18e0a0b-e84a-4341-8088-00c5caec4bbe	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:14:54.889052	2025-09-29 18:14:54.889052	2025-09-29 18:14:54.889052	2025-09-29 18:14:54.889052	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
7f711bff-a3a8-424d-86ce-772d423fbdd6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:14:58.542285	2025-09-29 18:14:58.542285	2025-09-29 18:14:58.542285	2025-09-29 18:14:58.542285	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0aae01ab-0bc7-4283-af08-a03234c8733a	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:17:41.465925	2025-09-29 18:17:41.465925	2025-09-29 18:17:41.465925	2025-09-29 18:17:41.465925	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
17b3de64-99a8-4ef3-9ee5-6d8c5c0db622	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:32:04.985906	2025-09-29 18:32:04.985906	2025-09-29 18:32:04.985906	2025-09-29 18:32:04.985906	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
b8a88790-6659-464b-9575-160bc1682596	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:30.849582	2025-09-29 18:35:30.849582	2025-09-29 18:35:30.849582	2025-09-29 18:35:30.849582	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a178a41e-f776-40b1-aae6-a38bbe5e9a6d	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:32.496249	2025-09-29 18:35:32.496249	2025-09-29 18:35:32.496249	2025-09-29 18:35:32.496249	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c7053039-d5c7-4512-a382-2b5d013c94e2	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:35.734116	2025-09-29 18:35:35.734116	2025-09-29 18:35:35.734116	2025-09-29 18:35:35.734116	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6faa38c1-c5cd-4321-b23e-c0413260570d	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:38.730638	2025-09-29 18:35:38.730638	2025-09-29 18:35:38.730638	2025-09-29 18:35:38.730638	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
41521ce0-a89e-4004-982a-65c178bf8bdf	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:41.561707	2025-09-29 18:35:41.561707	2025-09-29 18:35:41.561707	2025-09-29 18:35:41.561707	login	Login	\N	\N	\N	\N	\N	\N	\N	\N	\N
0e5bc3d7-c8cf-4201-8079-3a2b83dcb316	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:45.288214	2025-09-29 18:35:45.288214	2025-09-29 18:35:45.288214	2025-09-29 18:35:45.288214	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c05e1687-6fac-4787-9e0e-3a8a272325a6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:35:58.88852	2025-09-29 18:35:58.88852	2025-09-29 18:35:58.88852	2025-09-29 18:35:58.88852	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0822a247-8c91-478c-9bc4-793f50c40805	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:47:12.296163	2025-09-29 18:47:12.296163	2025-09-29 18:47:12.296163	2025-09-29 18:47:12.296163	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
dd30406d-c225-4819-9fe7-aeb4c712e75f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:48:42.230332	2025-09-29 18:48:42.230332	2025-09-29 18:48:42.230332	2025-09-29 18:48:42.230332	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
cb0b1993-6587-4423-b477-ff9f840e9ed3	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 18:49:19.808284	2025-09-29 18:49:19.808284	2025-09-29 18:49:19.808284	2025-09-29 18:49:19.808284	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
afe93e6d-1d7c-47a0-afd2-8d4eb3bc64c7	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:00:22.29656	2025-09-29 19:00:22.29656	2025-09-29 19:00:22.29656	2025-09-29 19:00:22.29656	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d65ba6a4-7604-4f94-8d20-a4405361bf39	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:27:06.114745	2025-09-29 19:27:06.114745	2025-09-29 19:27:06.114745	2025-09-29 19:27:06.114745	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9f0e19dd-3a03-44fb-9b1a-7cbcf0062bf6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:27:27.914113	2025-09-29 19:27:27.914113	2025-09-29 19:27:27.914113	2025-09-29 19:27:27.914113	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
fdda1db2-74fc-4464-b497-13894d8bf301	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:27:34.432552	2025-09-29 19:27:34.432552	2025-09-29 19:27:34.432552	2025-09-29 19:27:34.432552	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
54b17296-738e-4eb1-a1f8-8d7f294d1f33	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:29:48.964921	2025-09-29 19:29:48.964921	2025-09-29 19:29:48.964921	2025-09-29 19:29:48.964921	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
64c4df25-e0bd-4a03-bb32-894cd8afb5e2	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:42:22.436356	2025-09-29 19:42:22.436356	2025-09-29 19:42:22.436356	2025-09-29 19:42:22.436356	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
3fbe9640-ae53-405b-9ff1-8cb4598bb005	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:47:34.377864	2025-09-29 19:47:34.377864	2025-09-29 19:47:34.377864	2025-09-29 19:47:34.377864	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d6aac0aa-890f-4fb4-9825-c2d38bcb076e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:52:31.543553	2025-09-29 19:52:31.543553	2025-09-29 19:52:31.543553	2025-09-29 19:52:31.543553	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
8bf49ca8-0155-4775-b575-28b62b27bb58	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:53:13.568396	2025-09-29 19:53:13.568396	2025-09-29 19:53:13.568396	2025-09-29 19:53:13.568396	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6cfe2769-04ef-4952-8400-ad5d8ea0fff2	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:53:28.409304	2025-09-29 19:53:28.409304	2025-09-29 19:53:28.409304	2025-09-29 19:53:28.409304	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c918db98-7900-4c10-95c7-c18afb7a21a9	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 19:57:01.756559	2025-09-29 19:57:01.756559	2025-09-29 19:57:01.756559	2025-09-29 19:57:01.756559	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b70d6a6b-20d9-46e4-b16a-636ed388e6c5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:00:45.681036	2025-09-29 20:00:45.681036	2025-09-29 20:00:45.681036	2025-09-29 20:00:45.681036	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
81104637-c402-417d-af57-5a6e441126ab	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:05:09.230148	2025-09-29 20:05:09.230148	2025-09-29 20:05:09.230148	2025-09-29 20:05:09.230148	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b561f0e4-6431-4147-9bd4-724e989b238e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:06:14.220389	2025-09-29 20:06:14.220389	2025-09-29 20:06:14.220389	2025-09-29 20:06:14.220389	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
25cc330f-df4a-4d08-ad5e-a436b7925abe	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:09:05.048106	2025-09-29 20:09:05.048106	2025-09-29 20:09:05.048106	2025-09-29 20:09:05.048106	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
78fe9bd9-e17b-4a8a-b1ae-507921aa1e46	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:17:43.874474	2025-09-29 20:17:43.874474	2025-09-29 20:17:43.874474	2025-09-29 20:17:43.874474	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
de7d6e5c-8196-484a-8125-15ea854ffdd1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:19:45.599433	2025-09-29 20:19:45.599433	2025-09-29 20:19:45.599433	2025-09-29 20:19:45.599433	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
89ebbd61-b76a-4e10-a3e5-d4da60a0d2bd	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:22:01.318921	2025-09-29 20:22:01.318921	2025-09-29 20:22:01.318921	2025-09-29 20:22:01.318921	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
bc5355b6-e3b5-4c6e-9e9d-3f6b10b58f91	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 20:54:18.963081	2025-09-29 20:54:18.963081	2025-09-29 20:54:18.963081	2025-09-29 20:54:18.963081	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
4c3e8bf1-3e31-4ff9-93b6-c40189907fd9	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 21:43:07.93949	2025-09-29 21:43:07.93949	2025-09-29 21:43:07.93949	2025-09-29 21:43:07.93949	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ae435ff2-a223-4cd2-9ff0-8be9c183e8a0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 21:55:36.055149	2025-09-29 21:55:36.055149	2025-09-29 21:55:36.055149	2025-09-29 21:55:36.055149	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a6decc1d-e79b-405c-bb97-116d5271d80a	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 21:58:05.231722	2025-09-29 21:58:05.231722	2025-09-29 21:58:05.231722	2025-09-29 21:58:05.231722	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
da3de236-f2cb-4070-9364-c435d7fce801	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:00:50.560213	2025-09-29 22:00:50.560213	2025-09-29 22:00:50.560213	2025-09-29 22:00:50.560213	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6f41efe0-dc7a-4c39-a1ec-8f7fc6dc2a31	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:01:22.496822	2025-09-29 22:01:22.496822	2025-09-29 22:01:22.496822	2025-09-29 22:01:22.496822	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
5d12d90b-7734-48c6-b4a2-5df9fab5423e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:30:51.794472	2025-09-29 22:30:51.794472	2025-09-29 22:30:51.794472	2025-09-29 22:30:51.794472	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
19f6a91c-300e-41e7-96e9-647f6338605f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:32:46.442129	2025-09-29 22:32:46.442129	2025-09-29 22:32:46.442129	2025-09-29 22:32:46.442129	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
08e5b2fa-3fa1-4138-840f-2f2d85f628b7	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:37:36.597701	2025-09-29 22:37:36.597701	2025-09-29 22:37:36.597701	2025-09-29 22:37:36.597701	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
480aecd9-3438-462c-ac62-d825019b68f4	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:38:08.455904	2025-09-29 22:38:08.455904	2025-09-29 22:38:08.455904	2025-09-29 22:38:08.455904	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
bdc43454-4f6c-4913-89f5-1fc8968d01e7	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:43:28.721179	2025-09-29 22:43:28.721179	2025-09-29 22:43:28.721179	2025-09-29 22:43:28.721179	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f0f9b494-7688-42e7-abba-54538fe42f48	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:44:03.565709	2025-09-29 22:44:03.565709	2025-09-29 22:44:03.565709	2025-09-29 22:44:03.565709	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f0aed6cd-5f97-424f-a6c1-25f3f3c02933	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:46:57.466743	2025-09-29 22:46:57.466743	2025-09-29 22:46:57.466743	2025-09-29 22:46:57.466743	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
7cc8376c-fd67-4323-a049-8bd0980ff892	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:51:17.141595	2025-09-29 22:51:17.141595	2025-09-29 22:51:17.141595	2025-09-29 22:51:17.141595	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
2ba279cd-4334-45d5-a7ad-544ad6c8bfd5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:52:20.949587	2025-09-29 22:52:20.949587	2025-09-29 22:52:20.949587	2025-09-29 22:52:20.949587	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
5865a4bf-23bd-47fc-8608-acca172e1279	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:52:46.259475	2025-09-29 22:52:46.259475	2025-09-29 22:52:46.259475	2025-09-29 22:52:46.259475	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9d35faac-477b-4af0-9bd9-04e6bca8b11d	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:55:33.109905	2025-09-29 22:55:33.109905	2025-09-29 22:55:33.109905	2025-09-29 22:55:33.109905	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
420759a1-b851-4fee-99c1-710881a1fdf8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 22:59:38.463697	2025-09-29 22:59:38.463697	2025-09-29 22:59:38.463697	2025-09-29 22:59:38.463697	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
5487ddcd-53fa-465f-8427-d093110ae416	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 23:04:10.15936	2025-09-29 23:04:10.15936	2025-09-29 23:04:10.15936	2025-09-29 23:04:10.15936	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d5c1b378-7045-47f1-88aa-3b3e0d8519ec	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 23:04:39.238938	2025-09-29 23:04:39.238938	2025-09-29 23:04:39.238938	2025-09-29 23:04:39.238938	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1eec6e8e-b7ee-43bf-acb9-357554bb6ddf	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-29 23:05:26.168123	2025-09-29 23:05:26.168123	2025-09-29 23:05:26.168123	2025-09-29 23:05:26.168123	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0b834de8-fbc3-49a9-be29-b36601a68952	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 00:36:21.12364	2025-09-30 00:36:21.12364	2025-09-30 00:36:21.12364	2025-09-30 00:36:21.12364	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ac1fe66f-7e32-4234-8538-608d142a5ba0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 00:38:38.588076	2025-09-30 00:38:38.588076	2025-09-30 00:38:38.588076	2025-09-30 00:38:38.588076	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b9537b79-0e5d-4705-8785-9ba140329c80	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 00:41:50.971806	2025-09-30 00:41:50.971806	2025-09-30 00:41:50.971806	2025-09-30 00:41:50.971806	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
2d1db2b9-89ac-4bab-a903-80db4654c42b	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:05:23.502313	2025-09-30 01:05:23.502313	2025-09-30 01:05:23.502313	2025-09-30 01:05:23.502313	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0011f107-b989-470e-be34-bf044176e4cd	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:07:43.783454	2025-09-30 01:07:43.783454	2025-09-30 01:07:43.783454	2025-09-30 01:07:43.783454	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b7054a5b-1ab3-4a7f-8233-4246a72854f8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:15:26.443708	2025-09-30 01:15:26.443708	2025-09-30 01:15:26.443708	2025-09-30 01:15:26.443708	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d9e3b38e-b984-4739-b299-e425bdf5d1bf	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:19:27.107337	2025-09-30 01:19:27.107337	2025-09-30 01:19:27.107337	2025-09-30 01:19:27.107337	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
979871bf-2d3d-4846-9cbb-a89df2c5dfd8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:33:46.818603	2025-09-30 01:33:46.818603	2025-09-30 01:33:46.818603	2025-09-30 01:33:46.818603	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
8e1768db-9f33-49d2-b4cb-43d9b9b507ca	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:52:53.772188	2025-09-30 01:52:53.772188	2025-09-30 01:52:53.772188	2025-09-30 01:52:53.772188	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
224880a1-ea7a-4e05-a6a8-a8c4e38f3b54	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 01:58:34.831695	2025-09-30 01:58:34.831695	2025-09-30 01:58:34.831695	2025-09-30 01:58:34.831695	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
71372e02-4a82-4be1-b106-1d14c33bbf23	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:06:26.110889	2025-09-30 04:06:26.110889	2025-09-30 04:06:26.110889	2025-09-30 04:06:26.110889	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b2195f54-07d6-4fa5-ab42-1da104e0cc37	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:14:12.372162	2025-09-30 04:14:12.372162	2025-09-30 04:14:12.372162	2025-09-30 04:14:12.372162	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c010fb35-591a-42a0-b0b5-ca64e0e2618f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:18:07.709504	2025-09-30 04:18:07.709504	2025-09-30 04:18:07.709504	2025-09-30 04:18:07.709504	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c239e415-256a-4e17-b65d-979ec03f481f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:19:50.012021	2025-09-30 04:19:50.012021	2025-09-30 04:19:50.012021	2025-09-30 04:19:50.012021	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1410d8a3-ec73-4e43-970e-66ea3bab52fa	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:25:59.775899	2025-09-30 04:25:59.775899	2025-09-30 04:25:59.775899	2025-09-30 04:25:59.775899	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9deccf11-e5b9-4420-9abc-e1b1e339ed46	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:34:12.706143	2025-09-30 04:34:12.706143	2025-09-30 04:34:12.706143	2025-09-30 04:34:12.706143	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
62732768-2b35-40bd-9465-cdd6120333e6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:48:04.090628	2025-09-30 04:48:04.090628	2025-09-30 04:48:04.090628	2025-09-30 04:48:04.090628	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
4b7ea6dc-6fc3-4069-88a4-9a9246d0d387	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:52:58.015702	2025-09-30 04:52:58.015702	2025-09-30 04:52:58.015702	2025-09-30 04:52:58.015702	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
2de266bc-7426-4617-91ca-5c24f3b6c852	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:55:26.653233	2025-09-30 04:55:26.653233	2025-09-30 04:55:26.653233	2025-09-30 04:55:26.653233	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
14a66a72-59a2-41d9-aba6-b1516a6b4933	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 04:56:52.275472	2025-09-30 04:56:52.275472	2025-09-30 04:56:52.275472	2025-09-30 04:56:52.275472	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
60c03b48-2f22-49ef-ad3e-3ed0dde2da2e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:01:47.465501	2025-09-30 05:01:47.465501	2025-09-30 05:01:47.465501	2025-09-30 05:01:47.465501	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
294ff9c2-2a25-4e95-b1df-376b60f6938e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:04:56.412861	2025-09-30 05:04:56.412861	2025-09-30 05:04:56.412861	2025-09-30 05:04:56.412861	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
eac66b4e-0202-447a-a437-099ffdb47f73	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:05:33.456433	2025-09-30 05:05:33.456433	2025-09-30 05:05:33.456433	2025-09-30 05:05:33.456433	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6b9ace71-7bef-441b-a003-adbf5a359e6c	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:05:38.910876	2025-09-30 05:05:38.910876	2025-09-30 05:05:38.910876	2025-09-30 05:05:38.910876	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
58d83cea-bed6-4122-8c9c-b8dcd9baceef	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:06:07.67306	2025-09-30 05:06:07.67306	2025-09-30 05:06:07.67306	2025-09-30 05:06:07.67306	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
583c83ee-7f3f-42c2-83a7-5d8584bc6ff8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:08:14.361684	2025-09-30 05:08:14.361684	2025-09-30 05:08:14.361684	2025-09-30 05:08:14.361684	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9e6d1dc1-9e67-48d2-99d3-1c5392e515cc	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:17:27.368469	2025-09-30 05:17:27.368469	2025-09-30 05:17:27.368469	2025-09-30 05:17:27.368469	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1860e24e-487a-4fc5-9f18-a002e4efd20c	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 05:28:28.596138	2025-09-30 05:28:28.596138	2025-09-30 05:28:28.596138	2025-09-30 05:28:28.596138	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a6a6775d-ebbe-4668-aeb6-d0950b8e7c30	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 15:52:13.476845	2025-09-30 15:52:13.476845	2025-09-30 15:52:13.476845	2025-09-30 15:52:13.476845	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
809271b1-e5db-46da-a24b-6ad2f7ba19eb	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 16:39:44.841135	2025-09-30 16:39:44.841135	2025-09-30 16:39:44.841135	2025-09-30 16:39:44.841135	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
55558919-4c53-44cc-9ba6-ad02a3ec0eee	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 17:10:14.448154	2025-09-30 17:10:14.448154	2025-09-30 17:10:14.448154	2025-09-30 17:10:14.448154	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b4dc0993-8dd1-418f-9623-f9e0cf17307b	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 19:13:37.092101	2025-09-30 19:13:37.092101	2025-09-30 19:13:37.092101	2025-09-30 19:13:37.092101	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9de832c4-7c44-4dcc-bb86-be6877f6d6b5	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-30 19:18:08.104237	2025-09-30 19:18:08.104237	2025-09-30 19:18:08.104237	2025-09-30 19:18:08.104237	logout	Logout	::1	\N	\N	\N	\N	\N	\N	\N	\N
16d5c1b7-b145-4a7a-879c-d5980ecdd004	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 19:18:13.747732	2025-09-30 19:18:13.747732	2025-09-30 19:18:13.747732	2025-09-30 19:18:13.747732	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
27d210cb-e5a8-4ba2-bb50-25febd1c81d3	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 19:29:42.118341	2025-09-30 19:29:42.118341	2025-09-30 19:29:42.118341	2025-09-30 19:29:42.118341	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
868e1f94-560d-4332-a43a-454117231f94	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 19:39:06.216661	2025-09-30 19:39:06.216661	2025-09-30 19:39:06.216661	2025-09-30 19:39:06.216661	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0aa99920-402a-4180-a5ea-e22143da54dd	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 19:47:16.264328	2025-09-30 19:47:16.264328	2025-09-30 19:47:16.264328	2025-09-30 19:47:16.264328	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
5c8ed898-0bf7-4239-91ca-1f5b38d0f702	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 20:22:24.00538	2025-09-30 20:22:24.00538	2025-09-30 20:22:24.00538	2025-09-30 20:22:24.00538	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
5be559c9-b04a-41b9-8fc3-6d13871bf1cc	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 20:26:50.594307	2025-09-30 20:26:50.594307	2025-09-30 20:26:50.594307	2025-09-30 20:26:50.594307	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ffbe1cad-7ebf-4fd3-8b74-4cc2733be44e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 20:26:53.527018	2025-09-30 20:26:53.527018	2025-09-30 20:26:53.527018	2025-09-30 20:26:53.527018	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
4bab688d-c7ad-430d-8e09-e202f549682a	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-09-30 20:28:06.929656	2025-09-30 20:28:06.929656	2025-09-30 20:28:06.929656	2025-09-30 20:28:06.929656	logout	Logout	::1	\N	\N	\N	\N	\N	\N	\N	\N
10c9e0ed-e35e-4518-a097-911f14c23bc8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 20:28:50.585041	2025-09-30 20:28:50.585041	2025-09-30 20:28:50.585041	2025-09-30 20:28:50.585041	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b2f7f940-444d-4071-850e-09c91ff27303	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 20:35:23.786552	2025-09-30 20:35:23.786552	2025-09-30 20:35:23.786552	2025-09-30 20:35:23.786552	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ed70d2ff-23e9-4db2-8bf0-bc17623fba9a	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 22:27:59.996248	2025-09-30 22:27:59.996248	2025-09-30 22:27:59.996248	2025-09-30 22:27:59.996248	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
8e3e6747-eaad-46ea-9693-f12d72352e3d	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 23:19:47.374948	2025-09-30 23:19:47.374948	2025-09-30 23:19:47.374948	2025-09-30 23:19:47.374948	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
122e78d3-8365-425d-bb9d-ed04100ef023	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 23:22:01.543236	2025-09-30 23:22:01.543236	2025-09-30 23:22:01.543236	2025-09-30 23:22:01.543236	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1418e960-0dc2-4f35-b97a-c4ca495fa9b6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 23:26:19.674832	2025-09-30 23:26:19.674832	2025-09-30 23:26:19.674832	2025-09-30 23:26:19.674832	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f63ce46f-794b-454a-8e14-83cd6a6bc9aa	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-09-30 23:35:58.12348	2025-09-30 23:35:58.12348	2025-09-30 23:35:58.12348	2025-09-30 23:35:58.12348	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
3ca5ef70-8334-4f30-9d00-495bb8b7eaa1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 00:03:02.839497	2025-10-01 00:03:02.839497	2025-10-01 00:03:02.839497	2025-10-01 00:03:02.839497	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9a26c175-add7-4328-aef3-679e71bd5897	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:01:19.721677	2025-10-01 02:01:19.721677	2025-10-01 02:01:19.721677	2025-10-01 02:01:19.721677	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1178e0ad-960e-427a-b8a8-74df5a646f51	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-01 02:01:42.380446	2025-10-01 02:01:42.380446	2025-10-01 02:01:42.380446	2025-10-01 02:01:42.380446	logout	Logout	::1	\N	\N	\N	\N	\N	\N	\N	\N
63ce7f78-99a5-4202-9f82-498ae7df0ab3	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:01:59.40719	2025-10-01 02:01:59.40719	2025-10-01 02:01:59.40719	2025-10-01 02:01:59.40719	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
18aa9790-4ded-42f7-ac9d-481ed7c04c0c	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-01 02:02:10.980023	2025-10-01 02:02:10.980023	2025-10-01 02:02:10.980023	2025-10-01 02:02:10.980023	logout	Logout	::1	\N	\N	\N	\N	\N	\N	\N	\N
17a95819-fef0-428d-b0b9-6e03bacf3255	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:02:17.800126	2025-10-01 02:02:17.800126	2025-10-01 02:02:17.800126	2025-10-01 02:02:17.800126	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
18ef9769-4b63-48d4-894a-df353cb8563b	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:06:07.185267	2025-10-01 02:06:07.185267	2025-10-01 02:06:07.185267	2025-10-01 02:06:07.185267	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
067ccfa7-3485-4268-92ea-727647b70e11	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:09:05.128002	2025-10-01 02:09:05.128002	2025-10-01 02:09:05.128002	2025-10-01 02:09:05.128002	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d590b5ea-a362-4bdf-bc45-6f8bec2ea7bc	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:12:39.699011	2025-10-01 02:12:39.699011	2025-10-01 02:12:39.699011	2025-10-01 02:12:39.699011	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
cd1f22d5-ae05-45cc-b42d-88113ee31502	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:21:31.195035	2025-10-01 02:21:31.195035	2025-10-01 02:21:31.195035	2025-10-01 02:21:31.195035	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
a2f2171e-bdc1-4f45-b824-40ff366e9176	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:24:04.978099	2025-10-01 02:24:04.978099	2025-10-01 02:24:04.978099	2025-10-01 02:24:04.978099	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
888f8108-046c-4f0c-af2e-827ed129313f	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:27:31.301109	2025-10-01 02:27:31.301109	2025-10-01 02:27:31.301109	2025-10-01 02:27:31.301109	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c35bd63e-9c13-4e67-9e9e-3a25021bf1d0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 02:31:54.684669	2025-10-01 02:31:54.684669	2025-10-01 02:31:54.684669	2025-10-01 02:31:54.684669	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9f7490b3-9251-45a5-83a1-8effd4a04ad8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 03:24:13.548279	2025-10-01 03:24:13.548279	2025-10-01 03:24:13.548279	2025-10-01 03:24:13.548279	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f54f53c2-e01e-4c55-b4c6-ff42b8cbd7c1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 03:25:49.778289	2025-10-01 03:25:49.778289	2025-10-01 03:25:49.778289	2025-10-01 03:25:49.778289	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0b4565c3-c837-4670-82ca-11f80d91b0d6	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-01 03:27:11.95869	2025-10-01 03:27:11.95869	2025-10-01 03:27:11.95869	2025-10-01 03:27:11.95869	logout	Logout	::1	\N	\N	\N	\N	\N	\N	\N	\N
bbc8f3a2-fb1d-412e-bbce-e9259325c4f7	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 03:27:23.181141	2025-10-01 03:27:23.181141	2025-10-01 03:27:23.181141	2025-10-01 03:27:23.181141	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
00e60819-b683-4080-9343-a429460a34ee	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 03:28:55.287263	2025-10-01 03:28:55.287263	2025-10-01 03:28:55.287263	2025-10-01 03:28:55.287263	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c8363bf2-df83-4552-9cfd-d19917d6b33e	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 04:23:07.785095	2025-10-01 04:23:07.785095	2025-10-01 04:23:07.785095	2025-10-01 04:23:07.785095	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
cd31eeed-bf91-42f6-8a65-5d5233d80b10	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 04:34:55.698784	2025-10-01 04:34:55.698784	2025-10-01 04:34:55.698784	2025-10-01 04:34:55.698784	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6968b9d3-43b3-4f08-b46b-d5d3813b5a53	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 05:30:29.369226	2025-10-01 05:30:29.369226	2025-10-01 05:30:29.369226	2025-10-01 05:30:29.369226	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
e07c960e-6746-4dd4-8e59-5c7d23e9e73d	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 05:52:31.414974	2025-10-01 05:52:31.414974	2025-10-01 05:52:31.414974	2025-10-01 05:52:31.414974	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ef79320f-367d-4ff3-bf3f-3882265e0150	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 05:54:40.636276	2025-10-01 05:54:40.636276	2025-10-01 05:54:40.636276	2025-10-01 05:54:40.636276	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6cbcfd2f-d20d-437f-a283-e62eb509460b	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 05:56:43.364276	2025-10-01 05:56:43.364276	2025-10-01 05:56:43.364276	2025-10-01 05:56:43.364276	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
8ecd78db-1087-4318-8247-ae01d259cef4	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 06:00:55.922989	2025-10-01 06:00:55.922989	2025-10-01 06:00:55.922989	2025-10-01 06:00:55.922989	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
35dea3f4-43a5-41a8-9675-9f45bc035f64	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 06:03:36.923887	2025-10-01 06:03:36.923887	2025-10-01 06:03:36.923887	2025-10-01 06:03:36.923887	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b6d6a124-f44e-42d6-973a-9d8da114b14b	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 06:05:14.971477	2025-10-01 06:05:14.971477	2025-10-01 06:05:14.971477	2025-10-01 06:05:14.971477	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ec1dfb86-7d35-4d62-bad5-4558135db8de	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 06:25:08.406403	2025-10-01 06:25:08.406403	2025-10-01 06:25:08.406403	2025-10-01 06:25:08.406403	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b34cd771-8a19-4961-b474-65d2f7058809	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 06:32:03.522378	2025-10-01 06:32:03.522378	2025-10-01 06:32:03.522378	2025-10-01 06:32:03.522378	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
48a3bd2d-bbc2-46c5-b96a-69a2ba355d44	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 06:38:58.628038	2025-10-01 06:38:58.628038	2025-10-01 06:38:58.628038	2025-10-01 06:38:58.628038	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
53a23a62-f8ed-414f-9ea9-5efa8cbcc85a	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 06:43:38.356061	2025-10-01 06:43:38.356061	2025-10-01 06:43:38.356061	2025-10-01 06:43:38.356061	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9f3d2d48-315d-4de0-8824-ed356c9a4b9e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 14:38:28.958725	2025-10-01 14:38:28.958725	2025-10-01 14:38:28.958725	2025-10-01 14:38:28.958725	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
71ab5068-8a9b-458f-ade3-732accb3846d	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 16:39:54.210682	2025-10-01 16:39:54.210682	2025-10-01 16:39:54.210682	2025-10-01 16:39:54.210682	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
e5f23333-3874-446e-add8-ece42b724773	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-01 16:41:00.222932	2025-10-01 16:41:00.222932	2025-10-01 16:41:00.222932	2025-10-01 16:41:00.222932	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
cf7542b7-1c88-404e-8843-e6f02f219864	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 16:51:49.979503	2025-10-01 16:51:49.979503	2025-10-01 16:51:49.979503	2025-10-01 16:51:49.979503	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0910a140-12c2-4fb4-91bb-4ff4dbbf4262	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 16:54:53.620424	2025-10-01 16:54:53.620424	2025-10-01 16:54:53.620424	2025-10-01 16:54:53.620424	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
eef32788-d874-492a-beed-969e3be12007	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 16:58:49.933371	2025-10-01 16:58:49.933371	2025-10-01 16:58:49.933371	2025-10-01 16:58:49.933371	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
39162826-0bb2-4f02-92db-ed9de8936394	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:01:26.015534	2025-10-01 17:01:26.015534	2025-10-01 17:01:26.015534	2025-10-01 17:01:26.015534	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
e1593d00-f4ea-44e4-9954-7f66bd2acf95	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:02:26.681383	2025-10-01 17:02:26.681383	2025-10-01 17:02:26.681383	2025-10-01 17:02:26.681383	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
f7e74d07-16e5-40b9-9b7b-97113bbfbec1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:03:13.265681	2025-10-01 17:03:13.265681	2025-10-01 17:03:13.265681	2025-10-01 17:03:13.265681	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
289b6f63-b3cc-4c73-a600-ed0ad7193bb5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:03:20.809779	2025-10-01 17:03:20.809779	2025-10-01 17:03:20.809779	2025-10-01 17:03:20.809779	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
64323b76-1deb-46c2-9e70-66cbd4470922	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:05:40.251372	2025-10-01 17:05:40.251372	2025-10-01 17:05:40.251372	2025-10-01 17:05:40.251372	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
8e500502-39a4-4cde-8a90-91c611a6d363	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:09:10.962605	2025-10-01 17:09:10.962605	2025-10-01 17:09:10.962605	2025-10-01 17:09:10.962605	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
42ce0cbf-3345-4508-9035-55f9454a10f1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:10:29.932003	2025-10-01 17:10:29.932003	2025-10-01 17:10:29.932003	2025-10-01 17:10:29.932003	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
581d3f8d-368a-485d-abc3-a377ac4910c0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:12:10.252282	2025-10-01 17:12:10.252282	2025-10-01 17:12:10.252282	2025-10-01 17:12:10.252282	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
253ea1ec-aa3f-4a48-8c1f-8fbb41acd8c5	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:13:05.79534	2025-10-01 17:13:05.79534	2025-10-01 17:13:05.79534	2025-10-01 17:13:05.79534	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
6feb1f8a-09de-4bce-ae86-895aa7f63c39	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:15:22.125681	2025-10-01 17:15:22.125681	2025-10-01 17:15:22.125681	2025-10-01 17:15:22.125681	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
c72c0393-c349-433f-bd7b-5a0a5350c688	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:16:12.855333	2025-10-01 17:16:12.855333	2025-10-01 17:16:12.855333	2025-10-01 17:16:12.855333	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
be1c861f-1f52-49df-ad09-740c6d690b79	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:17:11.644951	2025-10-01 17:17:11.644951	2025-10-01 17:17:11.644951	2025-10-01 17:17:11.644951	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
51f4a3b8-31d6-446f-b949-14e395b543b0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:20:54.389285	2025-10-01 17:20:54.389285	2025-10-01 17:20:54.389285	2025-10-01 17:20:54.389285	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
ddf10ed4-7744-45d8-931a-0b927b3a7dff	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 17:23:54.094728	2025-10-01 17:23:54.094728	2025-10-01 17:23:54.094728	2025-10-01 17:23:54.094728	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0b57aa9e-6cba-4109-aa9c-4f8b407f66b8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 18:17:35.898173	2025-10-01 18:17:35.898173	2025-10-01 18:17:35.898173	2025-10-01 18:17:35.898173	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
90397f81-9c25-4add-8085-288898e7a496	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 19:29:08.339473	2025-10-01 19:29:08.339473	2025-10-01 19:29:08.339473	2025-10-01 19:29:08.339473	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d3c6ee33-1a20-4bc6-ac5c-d2f38536a7a8	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 19:40:17.713209	2025-10-01 19:40:17.713209	2025-10-01 19:40:17.713209	2025-10-01 19:40:17.713209	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
b8f071d7-521d-4f00-b6f2-62fb1ebbb34e	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 19:54:51.373544	2025-10-01 19:54:51.373544	2025-10-01 19:54:51.373544	2025-10-01 19:54:51.373544	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
1748da94-d314-40cd-a5e7-a3a2b430a7ea	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 22:03:26.524945	2025-10-01 22:03:26.524945	2025-10-01 22:03:26.524945	2025-10-01 22:03:26.524945	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
0267cf7c-7203-48a4-94c2-d152b6d3fdb6	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 23:02:38.889542	2025-10-01 23:02:38.889542	2025-10-01 23:02:38.889542	2025-10-01 23:02:38.889542	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
bc2dadd4-8c7c-46e9-bb37-a90dc7cdff46	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 23:05:14.536529	2025-10-01 23:05:14.536529	2025-10-01 23:05:14.536529	2025-10-01 23:05:14.536529	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
bb8c490e-1e35-4d4a-88f7-7d6f123054e1	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 23:13:12.520154	2025-10-01 23:13:12.520154	2025-10-01 23:13:12.520154	2025-10-01 23:13:12.520154	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
d81915d6-977b-4c48-bd10-f1a2b02d2cf0	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 23:14:29.791949	2025-10-01 23:14:29.791949	2025-10-01 23:14:29.791949	2025-10-01 23:14:29.791949	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
4bc92c45-ad81-44c8-aacc-d356fac2f837	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-01 23:15:37.156667	2025-10-01 23:15:37.156667	2025-10-01 23:15:37.156667	2025-10-01 23:15:37.156667	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
920c964d-b136-4966-b27d-4981c4fbb7f2	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-02 00:13:48.141392	2025-10-02 00:13:48.141392	2025-10-02 00:13:48.141392	2025-10-02 00:13:48.141392	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
677017b8-ec61-4c63-bec1-7b5867ea3a3c	\N	\N	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	\N	\N	2025-10-02 14:09:19.747521	2025-10-02 14:09:19.747521	2025-10-02 14:09:19.747521	2025-10-02 14:09:19.747521	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
e3709231-2fff-4bc9-8d24-6ec3e502a70f	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-02 14:20:38.193732	2025-10-02 14:20:38.193732	2025-10-02 14:20:38.193732	2025-10-02 14:20:38.193732	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
9033b432-fbb7-454e-a50f-1fb25564cf77	\N	\N	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	\N	\N	\N	\N	\N	\N	2025-10-02 14:31:09.61012	2025-10-02 14:31:09.61012	2025-10-02 14:31:09.61012	2025-10-02 14:31:09.61012	login	Login	::1	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: ai_financial_insights; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.ai_financial_insights (id, user_id, insight_type, category, title, description, recommendations, potential_savings, confidence_score, is_read, is_acted_upon, user_feedback, valid_from, valid_until, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.api_keys (id, user_id, key_hash, key_prefix, name, permissions, rate_limit, last_used_at, expires_at, is_active, created_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.audit_logs (id, entity_type, entity_id, action, actor_id, actor_role, changes, ip_address, user_agent, metadata, created_at) FROM stdin;
8d4c98dc-9a16-4584-bdb2-ce10f7edb429	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-09-30 23:30:00.861185-04
22385b21-d1fd-4d3b-b98d-813a2adcda24	user	enterprise-62cede32-e4af-4e06-8b82-8665bf396479	VERIFY_EMAIL	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Email manually verified by admin"}	2025-09-30 23:31:24.905512-04
e9902757-9803-4e20-8957-d85fa27584ca	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	VERIFY_EMAIL	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Email manually verified by admin"}	2025-09-30 23:31:29.870013-04
c90b873c-245b-45e9-adbf-2c9854a841a7	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	VERIFY_PHONE	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Phone manually verified by admin"}	2025-09-30 23:31:32.503339-04
639e645f-5a78-4adf-ae06-c06c75e3c956	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	UPDATE_KYC	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "KYC status updated by admin", "status": "verified"}	2025-09-30 23:31:35.349229-04
52df3bd5-7806-4071-a337-63e58a055f86	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	UPDATE_KYC	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "KYC status updated by admin", "status": "verified"}	2025-09-30 23:31:42.90507-04
2c2b266f-1dc5-4ae5-907c-69eca8a187f9	user	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	UPDATE_KYC	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "KYC status updated by admin", "status": "verified"}	2025-10-01 00:36:26.284452-04
99db31d2-4168-4e91-8611-b03d9bc0e041	user	enterprise-a69956ea-a23c-4e0b-bc5b-5c4547b9511e	VERIFY_EMAIL	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Email manually verified by admin"}	2025-10-01 01:32:13.881659-04
a67dcd6a-7d65-4c34-b8a1-6000524d9378	user	enterprise-a69956ea-a23c-4e0b-bc5b-5c4547b9511e	VERIFY_PHONE	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Phone manually verified by admin"}	2025-10-01 01:32:17.58402-04
f44fba2d-5986-4e36-8044-36cc1b42211c	user	enterprise-a69956ea-a23c-4e0b-bc5b-5c4547b9511e	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 01:32:29.345721-04
0c7db3ed-f709-4d97-9bae-7507bfc0c21c	user	individual-ef768a41-728e-4b7a-80cf-56b745341df1	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 15:55:12.064419-04
de58c1b2-9958-4a6d-9aa4-c0336be8fc0d	user	individual-f63c93a8-1277-4476-98c0-46dea83198f5	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 19:02:59.589124-04
ff09ee8a-c690-4cdc-809c-659d5b5d7502	user	individual-89657414-6f28-41b4-bff4-693d93d067fd	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 19:05:35.214596-04
eebce080-22a6-444a-86b8-efde817f4f2d	user	individual-c5246706-e142-43c2-b8d1-b3c3e03fe2c7	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 19:13:33.180178-04
aaf6ac91-4e60-4a9c-9d33-848c63a88aef	user	individual-328036f6-239f-444c-afb5-c80c064e4463	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 19:14:50.471571-04
6730a43a-c035-445a-b6f2-5ad738c6f09b	user	individual-dd48f73e-a7f9-4907-ba90-0f233a794133	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-01 19:15:57.862335-04
662ffa27-1b9d-40b6-8467-7b15bdbd1cc0	user	individual-dd48f73e-a7f9-4907-ba90-0f233a794133	RESET_PASSWORD	admin-88da2d60-98f1-4161-9329-f51e340f8248	\N	\N	\N	\N	{"note": "Password reset by admin"}	2025-10-02 10:11:05.881782-04
\.


--
-- Data for Name: auth_audit_log; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_audit_log (id, user_id, event_type, auth_method, device_id, session_id, ip_address, location, success, failure_reason, risk_score, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: auth_challenges; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_challenges (id, user_key, challenge, challenge_type, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: auth_risk_analysis; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_risk_analysis (id, user_id, session_id, risk_score, risk_level, risk_factors, location_risk, device_risk, behavior_risk, velocity_risk, required_auth_level, is_blocked, analyzed_at) FROM stdin;
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auth_sessions (id, user_id, session_token, refresh_token, device_id, ip_address, user_agent, location, risk_score, is_active, last_activity, expires_at, created_at, revoked_at, revoked_reason) FROM stdin;
\.


--
-- Data for Name: auto_topup_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.auto_topup_rules (id, user_id, wallet_id, trigger_threshold, topup_amount, max_monthly_amount, source_payment_method_id, is_active, last_triggered_at, next_check_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: batch_transfer_recipients; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.batch_transfer_recipients (id, batch_id, recipient_address, amount, currency, status, transaction_id, created_at) FROM stdin;
\.


--
-- Data for Name: batch_transfers; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.batch_transfers (id, batch_id, sender_id, total_amount, total_recipients, status, provider, fee, metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: bill_payments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bill_payments (id, bill_id, user_id, amount, payment_date, payment_method_id, transaction_id, status, confirmation_number, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: billing_metrics; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.billing_metrics (id, tenant_id, period_start, period_end, transaction_count, transaction_volume_cents, computation_units_used, api_calls_count, storage_used_bytes, bandwidth_used_bytes, overage_charges_cents, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bills (id, user_id, biller_name, biller_category, account_number, amount_due, due_date, is_recurring, recurrence_pattern, auto_pay_enabled, auto_pay_amount, payment_method_id, status, last_paid_date, next_due_date, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blockchain_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.blockchain_transactions (id, user_id, wallet_id, chain, transaction_hash, from_address, to_address, value, token_address, token_symbol, gas_used, gas_price, nonce, block_number, status, type, metadata, created_at, confirmed_at) FROM stdin;
\.


--
-- Data for Name: blockchain_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.blockchain_wallets (id, user_id, wallet_type, chain_id, network, address, public_key, encrypted_private_key, derivation_path, is_primary, is_imported, custody_type, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bridge_swaps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.bridge_swaps (id, swap_id, user_id, from_chain, to_chain, from_token_address, to_token_address, from_amount, to_amount, fee_amount, from_tx_hash, to_tx_hash, status, error_message, metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: business_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.business_rules (id, rule_name, rule_type, entity_type, entity_id, conditions, actions, priority, is_active, created_by, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.businesses (id, organization_id, business_name, business_type, industry, annual_revenue, employee_count, founded_date, description, logo_url, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: charity_donations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.charity_donations (id, user_id, charity_id, amount, currency, is_recurring, recurrence_pattern, transaction_id, receipt_url, tax_receipt_sent, tax_year, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: charity_organizations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.charity_organizations (id, name, ein, category, cause, description, website, logo_url, is_verified, tax_deductible, verification_date, impact_metrics, transparency_score, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: child_parents; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.child_parents (id, parent_id, child_id, relationship, daily_limit, monthly_limit, auto_topup_enabled, auto_topup_threshold, auto_topup_amount, permissions, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: compliance_checks; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.compliance_checks (id, user_id, transaction_id, check_type, check_status, risk_score, risk_factors, reviewed_by, notes, metadata, created_at, reviewed_at) FROM stdin;
\.


--
-- Data for Name: consumer_preferences; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.consumer_preferences (id, user_id, preferred_currency, auto_balance, smart_routing, instant_notifications, theme, language, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consumer_rewards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.consumer_rewards (id, user_id, reward_type, points_earned, points_redeemed, points_balance, tier, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: consumer_subscriptions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.consumer_subscriptions (id, user_id, merchant_name, amount, currency, frequency, status, next_payment_date, last_payment_date, metadata, created_at, updated_at, cancelled_at) FROM stdin;
\.


--
-- Data for Name: consumer_virtual_cards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.consumer_virtual_cards (id, user_id, card_id, last_four, brand, status, spending_limit, daily_spent, monthly_spent, provider, metadata, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: contract_interactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.contract_interactions (id, contract_id, user_id, function_name, parameters, transaction_hash, gas_used, status, result, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.countries (id, code, name, "countryCallingCode", "currencyCode", status, created_at, updated_at) FROM stdin;
1	US	United States	+1	USD	active	2025-09-30 02:53:03.188538	2025-09-30 02:53:03.188538
2	CA	Canada	+1	CAD	active	2025-09-30 02:53:03.188538	2025-09-30 02:53:03.188538
3	GB	United Kingdom	+44	GBP	active	2025-09-30 02:53:03.188538	2025-09-30 02:53:03.188538
4	AU	Australia	+61	AUD	active	2025-09-30 02:53:03.188538	2025-09-30 02:53:03.188538
\.


--
-- Data for Name: custody_configurations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.custody_configurations (id, user_id, custody_type, key_shares, threshold, user_shard_encrypted, server_shard_location, recovery_method, recovery_shares, backup_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customer_credits; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.customer_credits (id, customer_id, organization_id, amount, source_invoice_id, applied_to_invoice_id, status, created_at, applied_at, expires_at) FROM stdin;
\.


--
-- Data for Name: enterprise_ramps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.enterprise_ramps (id, organization_id, type, amount, method, provider, reference_id, bank_account_id, status, created_at, completed_at, metadata) FROM stdin;
\.


--
-- Data for Name: enterprise_treasuries; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.enterprise_treasuries (id, organization_id, wallet_address, solana_tree_address, tree_capacity, invoices_created, tempo_balance, circle_balance, tempo_wallet_id, circle_wallet_id, total_minted, total_burned, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gift_cards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.gift_cards (id, code, initial_value, current_balance, currency, purchaser_id, recipient_id, recipient_email, is_activated, is_redeemed, expires_at, design_template, personal_message, metadata, created_at, activated_at, redeemed_at) FROM stdin;
\.


--
-- Data for Name: invoice_attachments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_attachments (id, invoice_id, file_name, file_type, file_size, storage_url, ipfs_hash, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_batch_items; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_batch_items (id, batch_id, invoice_id, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_batches; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_batches (id, batch_id, user_id, total_invoices, total_amount, currency, status, blockchain_tx_hash, processed_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_events (id, invoice_id, event_type, event_data, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_line_items (id, invoice_id, line_number, description, quantity, unit_price, tax_rate, tax_amount, discount_rate, discount_amount, line_total, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_payment_methods; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_payment_methods (id, invoice_id, method_type, is_enabled, fee_percentage, fee_fixed, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_payments (id, invoice_id, payer_id, amount, payment_type, provider, transaction_hash, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: invoice_templates; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_templates (id, organization_id, name, description, default_terms, default_notes, line_items_template, tax_rate, is_recurring, recurrence_pattern, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_tokens (id, invoice_id, token_id, chain, tx_hash, from_user_id, to_user_id, amount, currency, description, due_date, ipfs_hash, smart_contract_address, status, paid_at, payment_tx_hash, paid_by_user_id, line_items, metadata, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoice_wallets (id, invoice_id, wallet_address, blockchain, mode, is_ephemeral, persistence_threshold, auto_sweep_enabled, quantum_resistant, quantum_key_id, quantum_algorithm, status, activated_at, expires_at, swept_at, transaction_count, total_received, total_swept, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.invoices (id, invoice_number, user_id, organization_id, type, amount, currency, status, client_name, vendor_name, description, payment_method, due_date, paid_date, is_recurring, create_ephemeral_wallet, ephemeral_wallet_created, wallet_mode, metadata, created_at, updated_at, solana_address, recipient_id, paid_amount, invoice_type, metadata_uri, paid_at, last_payment_at) FROM stdin;
\.


--
-- Data for Name: kyc_sessions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.kyc_sessions (id, user_id, provider, session_id, inquiry_id, status, verification_level, risk_score, checks_completed, documents_submitted, rejection_reasons, metadata, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: loyalty_rewards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.loyalty_rewards (id, program_name, program_type, tiers, point_value, earning_rules, redemption_rules, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: loyalty_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.loyalty_transactions (id, user_id, reward_program_id, transaction_type, points_earned, points_redeemed, points_balance, reference_transaction_id, description, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: magic_links; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.magic_links (id, user_id, token, email, purpose, used, expires_at, created_at, used_at, ip_address) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.migrations (id, name, executed_at) FROM stdin;
1	20250929_add_dual_phone_support	2025-09-29 11:24:52.152436
2	20250929_enhanced_contact_preferences	2025-09-29 11:30:54.489155
\.


--
-- Data for Name: multi_sig_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.multi_sig_transactions (id, wallet_id, transaction_data, signatures, status, executed_tx_hash, created_by, metadata, created_at, executed_at, expires_at) FROM stdin;
\.


--
-- Data for Name: multi_sig_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.multi_sig_wallets (id, wallet_name, enterprise_id, chain, address, threshold, signers, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.notifications (id, type, title, message, "receiverRead", "notificationData", "fromUserId", "toUserId", created_at, updated_at) FROM stdin;
1	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5bskpq0002a1jh6iore11f","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5bskpq0002a1jh6iore11f	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:11:07.37	2025-09-29 16:11:07.37
2	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5bt8cq0003a1jh42lyeegb","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5bt8cq0003a1jh42lyeegb	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:11:38.01	2025-09-29 16:11:38.01
3	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5btj1o0004a1jhfnto7ctp","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5btj1o0004a1jhfnto7ctp	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:11:51.865	2025-09-29 16:11:51.865
4	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5bwv5v0005a1jhch2dggfh","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5bwv5v0005a1jhch2dggfh	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:14:27.55	2025-09-29 16:14:27.55
5	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5c4nom0000mdjhcai1fmre","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5c4nom0000mdjhcai1fmre	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:20:31.116	2025-09-29 16:20:31.116
6	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5ce4ry0001mdjh2ukt2ofm","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5ce4ry0001mdjh2ukt2ofm	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:27:53.163	2025-09-29 16:27:53.163
7	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5ce4v10002mdjhaahhfh7v","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5ce4v10002mdjhaahhfh7v	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:27:53.254	2025-09-29 16:27:53.254
8	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5ce4xj0003mdjhbfcecrqe","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5ce4xj0003mdjhbfcecrqe	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 16:27:53.345	2025-09-29 16:27:53.345
9	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5onf4h0000o6jhgix0hz46","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5onf4h0000o6jhgix0hz46	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 22:11:01.891	2025-09-29 22:11:01.891
10	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5oqg320001o6jhd8138jjr","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5oqg320001o6jhd8138jjr	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 22:13:23.082	2025-09-29 22:13:23.082
11	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5pddno000001jh3q7j89qc","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5pddno000001jh3q7j89qc	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 22:31:13.043	2025-09-29 22:31:13.043
12	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5pddrb000101jhhifedxu8","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5pddrb000101jhhifedxu8	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 22:31:13.137	2025-09-29 22:31:13.137
13	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5pddtu000301jhgeng758s","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5pddtu000301jhgeng758s	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 22:31:13.23	2025-09-29 22:31:13.23
14	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5qnnd50000bnjh1dj73vxg","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5qnnd50000bnjh1dj73vxg	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-29 23:07:11.804	2025-09-29 23:07:11.804
15	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5u20800000frjhe9ajgv7y","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5u20800000frjhe9ajgv7y	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 00:42:20.485	2025-09-30 00:42:20.485
16	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5u611k0001frjh7sby5f01","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5u611k0001frjh7sby5f01	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 00:45:28.17	2025-09-30 00:45:28.17
17	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5uevq10000udjh9tpfebmb","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5uevq10000udjh9tpfebmb	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 00:52:21.184	2025-09-30 00:52:21.184
18	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5urqtj0000s1jh7faz66wg","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5urqtj0000s1jh7faz66wg	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 01:02:21.367	2025-09-30 01:02:21.367
19	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5vbs260000hajhhjz2a0dc","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5vbs260000hajhhjz2a0dc	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 01:17:56.164	2025-09-30 01:17:56.164
20	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg5vkur70000hqjh38wvdo4p","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg5vkur70000hqjh38wvdo4p	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 01:24:59.487	2025-09-30 01:24:59.487
21	NEW_USER	New User	A new user {name} ({email}) has signed up.	unread	{"fromId":"cmg62s3uc0000rsjhakg7fvc3","toId":"admin-88da2d60-98f1-4161-9329-f51e340f8248","followId":null,"type":"NEW_USER","title":"New User","message":"A new user {name} ({email}) has signed up."}	cmg62s3uc0000rsjhakg7fvc3	admin-88da2d60-98f1-4161-9329-f51e340f8248	2025-09-30 04:46:35.212	2025-09-30 04:46:35.212
\.


--
-- Data for Name: organization_users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.organization_users (id, organization_id, user_id, role, permissions, is_primary, joined_at, invited_by, invitation_status, created_at, updated_at) FROM stdin;
32f29a45-6188-4fcd-b02b-f121e1db3dd0	266ea6a9-ed0f-4feb-a58b-b5530dfe3f37	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
8947da1d-9054-498a-8933-16fed16cffad	de03686f-4452-4bcb-b4cf-f9fa103d6faa	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
c62c5c26-6131-4ee7-b729-be6e29d6242e	3a06d6e2-57c9-4455-9481-06ae30fe8f86	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
fce85150-44cd-48ca-af9b-52b32619d570	f51ebb46-052f-42bf-952b-9fa2adeb6bf1	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
fc6624c0-e198-44e4-b16a-bda55192121a	8d14163d-71b1-4802-a2a0-c89542e66dc4	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
2e31bc8a-60ed-4327-9471-08469ced4903	fe6b687d-4c2c-4c8d-ac7f-c1ea7cc35a35	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
4d766651-c990-4aa3-b5a4-405bf9a0f26d	77a7d074-3cfe-47ae-8c40-e4213bac1cfd	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
4bfa2808-2b17-4fbf-ab79-dcf747019817	8d47ded7-56a4-4377-a37e-c8c5e83b1407	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
b0f9c2b0-a0db-4dc6-86f4-c5969064ecd7	876e5cc5-cb69-4297-8319-355724c36ca6	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
777d880c-2a89-4f1c-b98d-a967b14f8c57	46354ac8-d63b-48f9-b064-02395138f2ea	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
15170751-ffb0-4c4d-af3c-297ac479ad15	a2811c4f-584a-4948-970f-708d22388314	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
b33350e6-5506-4382-b40f-e6e94654ddb6	57257ead-ee68-41de-8a61-3f2b467543e0	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
15744b44-4aad-4508-ab23-84b20fba1f60	c84ec463-563f-4868-8978-4322fe18f9c0	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
42514b09-dbaa-416f-8c10-0e23155e1a26	2be4f049-9a44-4922-b955-964ac500c4f5	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
7d7141a9-ff8b-47ee-9646-579a8a95f349	4d57f359-6c61-454b-b56b-15dec41e0677	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
b05e9865-9947-4e8c-b41a-4be136f2d1ee	334d4d10-616c-4579-94ea-d5aec541061d	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
b4457b54-4efb-4ca8-bf87-0262bb7c7af2	148ffafb-1e76-4fef-9b27-1f05b9727ad2	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
e76c3408-ba21-4965-b1f9-355d7766d6aa	356aa63a-460f-48e4-9632-711afa22a11c	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
3b3ec570-d245-4dbe-84c2-31044b550085	27b4c81f-c944-4914-a9c6-4a85acd7f569	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
34181b34-2a09-4640-ad8c-1ad40ba8650e	307c5074-467e-4905-a1c2-25847f83fc99	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
8328307c-9f47-4fa1-b927-1f4768c6bbf8	0cca5c14-6a2c-4854-b8b9-d471e1d525a4	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
b86e1f55-bd74-4b20-a319-2e1bdfaf833a	4b2e8644-8170-4b15-bc76-0da3ac9c9d3d	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
e1f23f56-62a3-4147-a473-343f4f68f1e8	3b6164ad-f10f-4675-ae17-a1476c75a852	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
4feb281e-2d39-4962-89b5-f0b29e18c752	4d9371eb-6e6d-49f2-a7d0-db8464e17ba3	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
dfbc9777-442e-4463-95be-8a2287a9bc39	a2617731-ba4e-4a0d-bcbc-03c17ee0d39e	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
e54a1a44-60ab-40f7-a30f-93c988973581	80806438-a16f-4148-9670-f88a1d2bad7e	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
c0f2f686-292a-4458-a928-18de0089cc61	3280987c-8258-4fc2-8b6d-5f4fcf622a9a	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
cd22ab6b-85f8-4344-ac00-d5b88911405b	ae9c9cae-a882-45e8-ad2f-fbbe2df1b4fe	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
1aabe610-2f5f-4631-a997-9a2e3c291035	cffa7cbe-11b6-4633-81dc-d28d4baf454d	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
872dccb1-9688-4f13-abfc-54675fe98e45	e5826292-63e4-4592-96ed-9c8dbeee8ea4	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
d50e8b03-a9da-4612-8456-4ac9b3a80ec4	445b7b08-02e7-4a00-8efc-fde8cd6ee2d4	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:18:51.09453-04	\N	active	2025-09-30 00:18:51.09453-04	2025-09-30 00:18:51.09453-04
3c6ef916-b5e4-428e-bbc6-263f7f7e372e	a3dfb40c-27a1-4d1c-8eeb-e5c30e828b02	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{"admin": true, "manage_users": true, "manage_wallets": true, "view_analytics": true, "manage_settings": true}	t	2025-09-30 00:41:39.458813-04	\N	active	2025-09-30 00:41:39.458813-04	2025-09-30 00:41:39.458813-04
d55ab37f-a4be-4c88-892c-b4d760cc7f00	83b1ac7a-71f7-40d3-9dcf-3fcdcb45c08d	enterprise-62cede32-e4af-4e06-8b82-8665bf396479	admin	["*"]	t	2025-09-30 21:07:57.917821-04	\N	active	2025-09-30 21:07:57.917821-04	2025-09-30 21:07:57.917821-04
3e98f2bc-849d-405e-bb10-6a871edf1168	e2f00e12-a8ff-45df-8ad8-4308182f4f7b	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	admin	["*"]	t	2025-09-30 23:20:11.027125-04	\N	active	2025-09-30 23:20:11.027125-04	2025-09-30 23:20:11.027125-04
17d3703b-68a4-4cc5-b381-9d4b258b1da8	c0e60bb3-74fc-4559-b7e3-974131b5fd09	enterprise-a69956ea-a23c-4e0b-bc5b-5c4547b9511e	admin	["*"]	t	2025-10-01 01:31:57.931291-04	\N	active	2025-10-01 01:31:57.931291-04	2025-10-01 01:31:57.931291-04
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.organizations (id, org_id, name, legal_name, tax_id, registration_number, parent_id, org_type, path_ids, hierarchy_level, email, phone, website, address_line1, address_line2, city, state, postal_code, country, kyb_status, aml_risk_score, compliance_status, verified, verified_at, erp_customer_id, erp_vendor_id, erp_cost_center, erp_sync_enabled, erp_last_sync, metadata, created_at, updated_at, wallet_type, feature_tier, can_upgrade, upgraded_from_consumer, consumer_limits, parent_organization_id, organization_type, email_verified, phone_verified, mfa_enabled, mfa_methods, type, industry, status, kyc_status, compliance_score, description, tenant_id) FROM stdin;
a2811c4f-584a-4948-970f-708d22388314	ORG_ENT-345FA4D1_1759197923573	Tilli Software	\N		\N	\N	standalone	\N	0	contact@tillisoftware.com	+3307019988			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-29 22:05:23.57051-04	2025-09-29 22:05:23.57051-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for Tilli Software	a00b7c16-d380-429a-87f5-72f7a92e5624
356aa63a-460f-48e4-9632-711afa22a11c	ORG_ENT-3BBFAD5B_1759205447758	Microsoft	\N		\N	\N	standalone	\N	0	contact@microsoft.com	+12345688899			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:10:47.751936-04	2025-09-30 00:10:47.751936-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for Microsoft	4b3bb733-ed10-4189-946d-6f1f344f8fb4
2be4f049-9a44-4922-b955-964ac500c4f5	ORG_ENT-MG5JFZDH-1_1759205619	TechCorp Solutions Inc	\N		\N	\N	standalone	\N	0	contact@techcorpsolutionsinc.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for TechCorp Solutions Inc	35b99d8b-9d44-40f7-9c90-1eb13c39d675
4d57f359-6c61-454b-b56b-15dec41e0677	ORG_ENT-MG5JFZDM-2_1759205619	Global Finance Partners	\N		\N	\N	standalone	\N	0	contact@globalfinancepartners.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Global Finance Partners	b6a5579e-bffe-4024-ac45-3323858bd98a
cffa7cbe-11b6-4633-81dc-d28d4baf454d	ORG_ENT-MG5JFZDN-3_1759205619	Healthcare Systems United	\N		\N	\N	standalone	\N	0	contact@healthcaresystemsunited.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Healthcare Systems United	ac375a8d-9e07-4f26-a4e1-bff10baf4a80
de03686f-4452-4bcb-b4cf-f9fa103d6faa	ORG_ENT-MG5JFZDN-4_1759205619	Manufacturing Dynamics Corp	\N		\N	\N	standalone	\N	0	contact@manufacturingdynamicscorp.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Manufacturing Dynamics Corp	71b7a0fe-c955-42ae-8f12-c9e67b9b3a07
266ea6a9-ed0f-4feb-a58b-b5530dfe3f37	ORG_ENT-MG5JFZDN-5_1759205619	Retail Chain International	\N		\N	\N	standalone	\N	0	contact@retailchaininternational.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Retail Chain International	8545de2d-ab13-4197-a765-b10ffc9f7694
3280987c-8258-4fc2-8b6d-5f4fcf622a9a	ORG_SMB-MG5JFZDO-6_1759205619	Sunrise Bakery & Cafe	\N		\N	\N	standalone	\N	0	contact@sunrisebakery&cafe.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Sunrise Bakery & Cafe	5d49dd5d-db4d-4357-8274-5e4d980388d6
4d9371eb-6e6d-49f2-a7d0-db8464e17ba3	ORG_SMB-MG5JFZDP-7_1759205619	Digital Marketing Pro	\N		\N	\N	standalone	\N	0	contact@digitalmarketingpro.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Digital Marketing Pro	05457fc6-aae5-4cf1-952c-f1488c0ad4a5
27b4c81f-c944-4914-a9c6-4a85acd7f569	ORG_SMB-MG5JFZDP-8_1759205619	Green Lawn Services	\N		\N	\N	standalone	\N	0	contact@greenlawnservices.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Green Lawn Services	f09eb73e-8b5f-4cee-9f20-33cc0ce2767b
4b2e8644-8170-4b15-bc76-0da3ac9c9d3d	ORG_SMB-MG5JFZDQ-9_1759205619	Boutique Law Associates	\N		\N	\N	standalone	\N	0	contact@boutiquelawassociates.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Boutique Law Associates	23c042f1-9d43-4ccb-a83f-95aefd908086
334d4d10-616c-4579-94ea-d5aec541061d	ORG_SMB-MG5JFZDQ-10_1759205619	Auto Repair Excellence	\N		\N	\N	standalone	\N	0	contact@autorepairexcellence.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Auto Repair Excellence	77a7c7b9-26f3-459c-ac73-356f52c6ada7
c84ec463-563f-4868-8978-4322fe18f9c0	ORG_SMB-MG5JFZDR-11_1759205619	Creative Design Studio	\N		\N	\N	standalone	\N	0	contact@creativedesignstudio.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Creative Design Studio	46885f6e-5910-403a-abe8-b02a0fdc5601
e5826292-63e4-4592-96ed-9c8dbeee8ea4	ORG_SMB-MG5JFZDR-12_1759205619	Fitness Plus Gym	\N		\N	\N	standalone	\N	0	contact@fitnessplusgym.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Fitness Plus Gym	8e4cce0f-3151-4a99-bd06-59ae697d1fba
148ffafb-1e76-4fef-9b27-1f05b9727ad2	ORG_SMB-MG5JFZDS-13_1759205619	Pet Care Paradise	\N		\N	\N	standalone	\N	0	contact@petcareparadise.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Pet Care Paradise	a8ef762f-fd75-4345-b19c-1f1e09583580
ae9c9cae-a882-45e8-ad2f-fbbe2df1b4fe	ORG_HLD-MG5JFZDT-14_1759205619	Apex Holdings Group	\N		\N	\N	standalone	\N	0	contact@apexholdingsgroup.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	holding_company	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Apex Holdings Group	109fc302-91ad-4244-81df-ae26468e7477
307c5074-467e-4905-a1c2-25847f83fc99	ORG_HLD-MG5JFZDT-15_1759205619	Diversified Ventures LLC	\N		\N	\N	standalone	\N	0	contact@diversifiedventuresllc.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	holding_company	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Diversified Ventures LLC	a9e167bf-6576-4224-b40a-e13dcb326449
876e5cc5-cb69-4297-8319-355724c36ca6	ORG_IND-MG5JFZDU-16_1759205619	John Smith Consulting	\N		\N	\N	standalone	\N	0	contact@johnsmithconsulting.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for John Smith Consulting	77bb623f-e6f7-4fc9-bf4c-c857f99b2a42
0cca5c14-6a2c-4854-b8b9-d471e1d525a4	ORG_IND-MG5JFZDU-17_1759205619	Sarah Johnson Freelance	\N		\N	\N	standalone	\N	0	contact@sarahjohnsonfreelance.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Sarah Johnson Freelance	3c340bd0-2850-48b9-b4f8-588cbd44ea47
f51ebb46-052f-42bf-952b-9fa2adeb6bf1	ORG_IND-MG5JFZDU-18_1759205619	Michael Chen Trading	\N		\N	\N	standalone	\N	0	contact@michaelchentrading.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Michael Chen Trading	9fae3aa1-e18c-4d1c-9bbe-c344a8878b3b
a2617731-ba4e-4a0d-bcbc-03c17ee0d39e	ORG_IND-MG5JFZDV-19_1759205619	Emily Davis Photography	\N		\N	\N	standalone	\N	0	contact@emilydavisphotography.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Emily Davis Photography	c10f4b20-15b1-483e-8115-5168e672c850
3b6164ad-f10f-4675-ae17-a1476c75a852	ORG_IND-MG5JFZDV-20_1759205619	Robert Wilson Investments	\N		\N	\N	standalone	\N	0	contact@robertwilsoninvestments.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Robert Wilson Investments	7698fcbe-b9f9-4940-a096-894eeb05e312
8d47ded7-56a4-4377-a37e-c8c5e83b1407	ORG_HHM-MG5JFZDV-21_1759205619	The Martinez Family	\N		\N	\N	standalone	\N	0	contact@themartinezfamily.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for The Martinez Family	d6dc6dcd-f6e8-4a92-95fc-ca6deb0d00a4
80806438-a16f-4148-9670-f88a1d2bad7e	ORG_HHM-MG5JFZDV-22_1759205619	Johnson Household	\N		\N	\N	standalone	\N	0	contact@johnsonhousehold.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Johnson Household	84da93f6-9eb5-4a36-9221-bbc304fed924
57257ead-ee68-41de-8a61-3f2b467543e0	ORG_HHM-MG5JFZDW-23_1759205619	The Kim Family Trust	\N		\N	\N	standalone	\N	0	contact@thekimfamilytrust.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for The Kim Family Trust	ee76d02c-503f-4158-a253-40ce39259472
fe6b687d-4c2c-4c8d-ac7f-c1ea7cc35a35	ORG_SMB-MG5JFZDW-24_1759205619	EduTech Learning Platform	\N		\N	\N	standalone	\N	0	contact@edutechlearningplatform.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for EduTech Learning Platform	b9aa9d81-78d7-4efb-953f-cae8daef6464
8d14163d-71b1-4802-a2a0-c89542e66dc4	ORG_ENT-MG5JFZDW-25_1759205619	Sustainable Energy Co	\N		\N	\N	standalone	\N	0	contact@sustainableenergyco.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Sustainable Energy Co	1bc1ff09-cba9-4eab-a86a-f9000207c07c
77a7d074-3cfe-47ae-8c40-e4213bac1cfd	ORG_SMB-MG5JFZDY-26_1759205619	Crypto Trading Desk	\N		\N	\N	standalone	\N	0	contact@cryptotradingdesk.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	standard	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Crypto Trading Desk	b377556e-d461-4559-bfdf-70ec58238dce
3a06d6e2-57c9-4455-9481-06ae30fe8f86	ORG_TNT-user-cd0_1759205619	Test User	\N		\N	\N	standalone	\N	0	contact@testuser.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Test User	f4b450a6-72c1-40ed-8b9c-c15bbbc08234
46354ac8-d63b-48f9-b064-02395138f2ea	ORG_TNT-enterpri_1759205619	Enterprise Admin	\N		\N	\N	standalone	\N	0	contact@enterpriseadmin.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Technology	pending	not_started	75	Organization for Enterprise Admin	a50b762f-b9ce-42a0-98da-7525e9277cc0
445b7b08-02e7-4a00-8efc-fde8cd6ee2d4	ORG_ENT-912368CC_1759205619	Tilli Pro	\N		\N	\N	standalone	\N	0	contact@tillipro.com				\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:13:38.52025-04	2025-09-30 00:13:38.52025-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Technology	pending	not_started	75	Organization for Tilli Pro	1a6de6ee-912d-442c-9fa1-4a5ef8f5e32f
a3dfb40c-27a1-4d1c-8eeb-e5c30e828b02	ORG_ENT-G9AR1947_1759207299388	Test Organization API	\N	12-3456789	\N	\N	standalone	\N	0	test@testorg.com	+1-555-0123	https://testorg.com	123 Test Street	\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 00:41:39.388827-04	2025-09-30 00:41:39.388827-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "per_transaction_max": 5000, "daily_transaction_limit": 100000, "monthly_transaction_limit": 1000000}	\N	standalone	f	f	t	["email", "sms"]	enterprise	technology	pending	not_started	75	Test organization for API testing	35b99d8b-9d44-40f7-9c90-1eb13c39d675
1639be77-c591-4270-a1e0-3a81788fd073	ORG_ENT-A28926EC_1759275901491	Microstrategy	\N		\N	\N	standalone	\N	0	contact@microstrategy.com	+1234567888			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 19:45:01.484266-04	2025-09-30 19:45:01.484266-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for Microstrategy	49e7f16a-bbdc-4b3f-8fea-25f9cfcb888a
83b1ac7a-71f7-40d3-9dcf-3fcdcb45c08d	ORG_ENT-77CD1517_1759280877789	T-Mobile	\N		\N	\N	standalone	\N	0	contact@t-mobile.com	+13307011235			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 21:07:57.785341-04	2025-09-30 21:07:57.785341-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for T-Mobile	62cede32-e4af-4e06-8b82-8665bf396479
e2f00e12-a8ff-45df-8ad8-4308182f4f7b	ORG_ENT-71CA97CB_1759288810879	Sysco	\N		\N	\N	standalone	\N	0	contact@sysco.com	+13307018877			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-09-30 23:20:10.876272-04	2025-09-30 23:20:10.876272-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for Sysco	2c354613-9e2f-414b-bea5-183646d253a9
c0e60bb3-74fc-4559-b7e3-974131b5fd09	ORG_ENT-7E814B17_1759296717803	Walmart	\N		\N	\N	standalone	\N	0	contact@walmart.com	+13307018866			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 01:31:57.795112-04	2025-10-01 01:31:57.795112-04	enterprise	premium	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	corporation	Other	pending	not_started	75	Organization for Walmart	a69956ea-a23c-4e0b-bc5b-5c4547b9511e
027912c5-ab9d-423f-b8ad-faf75acb644e	ORG_IND-5E1F4FF9_1759339040798	Healthcare Corp 1759339027958	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759339027958.com	5552559074			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 13:17:20.793697-04	2025-10-01 13:17:20.793697-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759339027958	7b735c61-fe78-4b1f-8af6-5360ff09deb1
82d4e7fa-c4f0-4fa1-b7f4-5ff90e72f617	ORG_IND-FA7E4B61_1759339443239	Healthcare Corp 1759339430312	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759339430312.com	5551428716			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 13:24:03.237114-04	2025-10-01 13:24:03.237114-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759339430312	c2841e36-b242-4763-8d8d-84f21fee145a
70cc26c9-6800-4ea2-81cc-758ee2da670f	ORG_IND-E3A4E74E_1759346958497	Healthcare Corp 1759346953258	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759346953258.com	5559056574			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 15:29:18.492821-04	2025-10-01 15:29:18.492821-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759346953258	88cd7d83-8bb6-4f97-ab45-8ae0a0a9b34f
485aacb7-9c48-4f55-9c98-aa5a207020cc	ORG_IND-CCA11821_1759347627869	Healthcare Corp 1759347622682	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759347622682.com	5554397758			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 15:40:27.864351-04	2025-10-01 15:40:27.864351-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759347622682	33eadcdd-82e6-4091-80d1-492cf42a209a
61f27526-62e6-4442-a73b-f656b7dbeaaa	ORG_IND-8601F91B_1759348501456	Healthcare Corp 1759348496283	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759348496283.com	5553042027			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 15:55:01.454558-04	2025-10-01 15:55:01.454558-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759348496283	ef768a41-728e-4b7a-80cf-56b745341df1
5ad8cf42-0497-4b3e-8055-1d54fda7d596	ORG_IND-D7C58BFA_1759359769013	Healthcare Corp 1759359763822	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759359763822.com	5551950653			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 19:02:49.010767-04	2025-10-01 19:02:49.010767-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759359763822	f63c93a8-1277-4476-98c0-46dea83198f5
97faf077-e87d-40f2-b371-64383abe9aab	ORG_IND-08FFA87F_1759359924672	Healthcare Corp 1759359919511	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759359919511.com	5558088872			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 19:05:24.671037-04	2025-10-01 19:05:24.671037-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759359919511	89657414-6f28-41b4-bff4-693d93d067fd
e70b607d-d8fe-42c3-807d-4e47dc157bc4	ORG_IND-A4F8FEBA_1759360402626	Healthcare Corp 1759360397470	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759360397470.com	5557462406			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 19:13:22.624215-04	2025-10-01 19:13:22.624215-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759360397470	c5246706-e142-43c2-b8d1-b3c3e03fe2c7
9e972ec1-8279-4706-8fb3-49f0b0659a36	ORG_IND-81958E61_1759360479904	Healthcare Corp 1759360474730	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759360474730.com	5551574195			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 19:14:39.903479-04	2025-10-01 19:14:39.903479-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759360474730	328036f6-239f-444c-afb5-c80c064e4463
75cd98e9-edba-49fb-8807-bbaaa49fd2af	ORG_IND-67A494D3_1759360547303	Healthcare Corp 1759360542136	\N		\N	\N	standalone	\N	0	contact@healthcarecorp1759360542136.com	5556852180			\N	\N	\N	\N	\N	not_started	\N	\N	f	\N	\N	\N	\N	f	\N	{}	2025-10-01 19:15:47.301558-04	2025-10-01 19:15:47.301558-04	business	basic	t	f	{"max_cards": 5, "max_users": 10, "daily_transaction_limit": 10000, "monthly_transaction_limit": 100000}	\N	standalone	f	f	t	["email", "sms"]	business	Other	pending	not_started	75	Organization for Healthcare Corp 1759360542136	dd48f73e-a7f9-4907-ba90-0f233a794133
\.


--
-- Data for Name: p2p_transfers; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.p2p_transfers (id, sender_id, recipient_address, recipient_id, amount, currency, status, provider, settlement_time_ms, fee, memo, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.payment_methods (id, user_id, method_type, card_last_four, card_brand, exp_month, exp_year, bank_name, account_last_four, routing_number, wallet_address, blockchain_network, is_default, is_active, verified, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment_requests; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.payment_requests (id, requester_id, payer_id, amount, description, status, qr_code, solana_address, created_at, paid_at, declined_at, decline_reason, expires_at) FROM stdin;
\.


--
-- Data for Name: price_feeds; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.price_feeds (id, token_symbol, base_currency, price, source, confidence, volume_24h, market_cap, metadata, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: quantum_key_registry; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.quantum_key_registry (id, wallet_id, algorithm, public_key, key_hash, lattice_params, security_level, is_active, created_at, rotated_at) FROM stdin;
\.


--
-- Data for Name: ready_cash_loans; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.ready_cash_loans (id, user_id, loan_amount, interest_rate, term_days, total_repayment, amount_paid, next_payment_date, status, approved_at, disbursed_at, fully_paid_at, credit_score, risk_assessment, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recurring_invoice_templates; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.recurring_invoice_templates (id, user_id, template_name, to_user_id, amount, currency, description, frequency, interval_count, next_invoice_date, end_date, is_active, auto_send, auto_charge, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sage_bank_reconciliations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_bank_reconciliations (id, account_id, bank_account_id, statement_date, statement_balance, reconciled_balance, difference, status, reconciled_items, outstanding_items, reconciled_by, reconciled_at, created_at) FROM stdin;
\.


--
-- Data for Name: sage_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_connections (id, account_id, company_id, company_name, access_token, refresh_token, token_expiry, subscription_type, region, features, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sage_entities; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_entities (id, account_id, entity_type, sage_id, data, attachments, audit_trail, synced_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: sage_journal_entries; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_journal_entries (id, account_id, journal_id, reference, date, description, total_amount, currency_code, journal_lines, attachments, posted, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: sage_ledger_accounts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_ledger_accounts (id, account_id, ledger_account_id, display_id, nominal_code, name, account_type, category, tax_rate_id, is_control, is_active, balance, currency_code, created_at) FROM stdin;
\.


--
-- Data for Name: sage_sync_queue; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_sync_queue (id, account_id, entity_type, operation, data, priority, status, attempts, max_attempts, error_message, scheduled_at, processed_at) FROM stdin;
\.


--
-- Data for Name: sage_tax_returns; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sage_tax_returns (id, account_id, return_id, tax_type, period_start, period_end, status, total_sales, total_purchases, tax_due, submission_date, reference_number, created_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.settings (id, name, key, value, "settingType", status, created_at, updated_at) FROM stdin;
1	Country Phone Code	country_phone_code	+1	public	active	2025-09-30 02:43:27.081637-04	2025-09-30 02:43:27.081637-04
2	Currency Abbreviation	currency_abbr	USD	public	active	2025-09-30 02:43:27.081637-04	2025-09-30 02:43:27.081637-04
3	KYC Required	kyc_required	true	public	active	2025-09-30 02:43:27.081637-04	2025-09-30 02:43:27.081637-04
4	Transaction Limit	transaction_limit	10000	public	active	2025-09-30 02:43:27.081637-04	2025-09-30 02:43:27.081637-04
5	Is Country Setting	is_country_setting	1	private	active	2025-09-30 02:43:27.081637-04	2025-09-30 02:43:27.081637-04
\.


--
-- Data for Name: smart_contracts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.smart_contracts (id, owner_id, contract_name, contract_type, chain, address, abi, bytecode, source_code, compiler_version, optimization_enabled, is_verified, is_upgradeable, solana_program_type, metadata, deployed_at, created_at) FROM stdin;
\.


--
-- Data for Name: spending_limit_history; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.spending_limit_history (id, spending_limit_id, action, changed_fields, old_values, new_values, changed_by, change_reason, changed_at) FROM stdin;
\.


--
-- Data for Name: spending_limit_overrides; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.spending_limit_overrides (id, spending_limit_id, original_amount, override_amount, reason, requested_by, approved_by, approval_status, approval_date, valid_from, valid_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: spending_limit_violations; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.spending_limit_violations (id, spending_limit_id, entity_type, entity_id, transaction_id, attempted_amount, limit_amount, current_usage, violation_type, transaction_type, merchant_name, merchant_category, action_taken, override_applied, occurred_at, metadata) FROM stdin;
\.


--
-- Data for Name: spending_limits; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.spending_limits (id, entity_type, entity_id, limit_type, limit_amount, current_usage, currency, time_window, reset_time, last_reset, condition_type, condition_value, can_be_overridden, override_requires_approval, override_approval_level, temporary_override_amount, temporary_override_expires, is_active, priority, enforcement_action, notification_threshold, created_by, updated_by, created_at, updated_at, deleted_at, description, compliance_category, regulatory_requirement) FROM stdin;
d42cc4da-0c33-486e-a15f-1a6a3104cb11	role	00000000-0000-0000-0000-000000000001	daily_transaction	1000.00	0.00	USD	daily	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Basic user daily transaction limit	standard	f
4704aec8-20b8-4e6a-a3fc-b6d35fd0c535	role	00000000-0000-0000-0000-000000000001	single_transaction	500.00	0.00	USD	per_transaction	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Basic user single transaction limit	standard	f
59f7e16b-c085-4b3d-892c-8b6fe6930893	role	00000000-0000-0000-0000-000000000001	daily_withdrawal	500.00	0.00	USD	daily	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Basic user daily withdrawal limit	standard	f
e8f8797a-4e70-4611-832f-0f41cb0e1985	role	00000000-0000-0000-0000-000000000002	daily_transaction	50000.00	0.00	USD	daily	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Verified user daily transaction limit	enhanced	f
e1d1ecf2-bc13-4b16-a4da-ac54bf9741fd	role	00000000-0000-0000-0000-000000000002	single_transaction	10000.00	0.00	USD	per_transaction	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Verified user single transaction limit	enhanced	f
666ef77d-7c6f-429a-beb6-bfa1b9e4c935	role	00000000-0000-0000-0000-000000000002	monthly_transaction	250000.00	0.00	USD	monthly	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Verified user monthly transaction limit	enhanced	f
f6a9eb35-b6ab-4859-a243-bef9a7901c3c	role	00000000-0000-0000-0000-000000000003	daily_transaction	250000.00	0.00	USD	daily	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Premium user daily transaction limit	premium	f
000a55fb-42e2-4bfe-a7a8-4920440f44eb	role	00000000-0000-0000-0000-000000000003	single_transaction	100000.00	0.00	USD	per_transaction	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Premium user single transaction limit	premium	f
aa4a27ae-2976-4faa-93ed-48a18f4490f3	role	00000000-0000-0000-0000-000000000003	monthly_transaction	5000000.00	0.00	USD	monthly	\N	2025-09-28 14:14:10.778319	\N	\N	f	t	1	\N	\N	t	0	block	80.00	\N	\N	2025-09-28 14:14:10.778319	2025-09-28 14:14:10.778319	\N	Premium user monthly transaction limit	premium	f
\.


--
-- Data for Name: split_bill_participants; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.split_bill_participants (id, split_bill_id, user_id, email, phone, name, amount_owed, amount_paid, payment_status, payment_date, transaction_id, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: split_bills; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.split_bills (id, creator_id, title, total_amount, currency, split_method, custom_splits, status, settled_at, category, description, receipt_url, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.sso_providers (id, provider_name, provider_type, client_id, client_secret_encrypted, authorization_url, token_url, user_info_url, jwks_url, scopes, metadata, is_active, created_at, updated_at) FROM stdin;
df1bb1ef-d62c-4816-b4b8-4ef3071a4487	google	oauth2	\N	\N	https://accounts.google.com/o/oauth2/v2/auth	https://oauth2.googleapis.com/token	https://www.googleapis.com/oauth2/v2/userinfo	\N	{openid,email,profile}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
9102507f-f20b-41a5-9b87-85186c49be23	apple	oauth2	\N	\N	https://appleid.apple.com/auth/authorize	https://appleid.apple.com/auth/token	\N	\N	{name,email}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
91fb7f51-736f-4b47-9649-a12ca66296d8	microsoft	oauth2	\N	\N	https://login.microsoftonline.com/common/oauth2/v2.0/authorize	https://login.microsoftonline.com/common/oauth2/v2.0/token	https://graph.microsoft.com/v1.0/me	\N	{openid,email,profile}	\N	t	2025-09-22 22:47:16.986578-04	2025-09-22 22:47:16.986578-04
\.


--
-- Data for Name: stablecoin_balances; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.stablecoin_balances (id, user_id, currency, amount, provider, last_synced, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: super_app_bookings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.super_app_bookings (id, user_id, booking_type, service_provider, booking_reference, booking_date, service_date, total_amount, currency, payment_status, booking_details, status, cancellation_policy, cancelled_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_audit_logs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_audit_logs (id, tenant_id, user_id, action, resource_type, resource_id, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: tenant_billing; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_billing (id, tenant_id, billing_period_start, billing_period_end, subscription_fee, transaction_fees, api_usage_fees, storage_fees, total_amount, status, invoice_url, paid_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_settings (id, tenant_id, setting_key, setting_value, setting_type, is_encrypted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_transactions (id, tenant_id, wallet_id, transaction_type, amount, currency, status, external_reference, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_users (id, tenant_id, user_id, role, permissions, is_primary, status, joined_at, removed_at) FROM stdin;
4ca7f01a-a42f-4bb9-9c6c-1dfb011e87ba	f4b450a6-72c1-40ed-8b9c-c15bbbc08234	user-cd06a4f0-b5fd-4c33-b0a2-79a518d62567	owner	{}	t	active	2025-09-29 16:32:09.167237	\N
a910660d-8321-4dcb-b3cf-0b7d943cc2c6	a50b762f-b9ce-42a0-98da-7525e9277cc0	enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	owner	{}	t	active	2025-09-29 16:32:09.167237	\N
\.


--
-- Data for Name: tenant_vault_keys; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_vault_keys (id, tenant_id, key_type, public_key, encrypted_private_key, key_metadata, rotation_date, expiration_date, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenant_wallets (id, tenant_id, wallet_type, currency, balance, available_balance, pending_balance, blockchain_address, circle_wallet_id, tempo_wallet_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tenants (id, tenant_code, name, type, isolation_level, billing_tier, metadata, wallet_derivation_path, status, gross_margin_percent, subscription_expires_at, created_at, updated_at) FROM stdin;
35b99d8b-9d44-40f7-9c90-1eb13c39d675	ENT-MG5JFZDH-1	TechCorp Solutions Inc	enterprise	database	enterprise	{"phone": "+14155551234", "industry": "Technology", "employees": 5000, "contact_email": "finance@techcorp.com", "annual_revenue": "500M"}	m/44'/501'/717020736'/0'/0	active	27.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
b6a5579e-bffe-4024-ac45-3323858bd98a	ENT-MG5JFZDM-2	Global Finance Partners	enterprise	database	custom	{"phone": "+12125555678", "industry": "Financial Services", "employees": 10000, "contact_email": "treasury@globalfinance.com", "annual_revenue": "2B"}	m/44'/501'/471002010'/0'/0	active	35.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
ac375a8d-9e07-4f26-a4e1-bff10baf4a80	ENT-MG5JFZDN-3	Healthcare Systems United	enterprise	database	enterprise	{"phone": "+13125559876", "industry": "Healthcare", "employees": 8000, "contact_email": "admin@healthsystems.com", "annual_revenue": "1.2B"}	m/44'/501'/945516829'/0'/0	active	25.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
71b7a0fe-c955-42ae-8f12-c9e67b9b3a07	ENT-MG5JFZDN-4	Manufacturing Dynamics Corp	enterprise	database	enterprise	{"phone": "+13135554321", "industry": "Manufacturing", "employees": 15000, "contact_email": "ops@mfgdynamics.com", "annual_revenue": "3B"}	m/44'/501'/1027394610'/0'/0	active	19.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
8545de2d-ab13-4197-a765-b10ffc9f7694	ENT-MG5JFZDN-5	Retail Chain International	enterprise	database	custom	{"phone": "+14045556789", "industry": "Retail", "employees": 50000, "contact_email": "corporate@retailchain.com", "annual_revenue": "10B"}	m/44'/501'/2043501048'/0'/0	active	10.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
5d49dd5d-db4d-4357-8274-5e4d980388d6	SMB-MG5JFZDO-6	Sunrise Bakery & Cafe	small_business	row	small_business	{"phone": "+14155552345", "industry": "Food Service", "employees": 25, "contact_email": "owner@sunrisebakery.com", "annual_revenue": "2M"}	m/44'/501'/1439061281'/0'/0	active	43.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
05457fc6-aae5-4cf1-952c-f1488c0ad4a5	SMB-MG5JFZDP-7	Digital Marketing Pro	small_business	row	small_business	{"phone": "+16505553456", "industry": "Marketing", "employees": 15, "contact_email": "hello@digitalmarketingpro.com", "annual_revenue": "5M"}	m/44'/501'/298788475'/0'/0	active	57.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
f09eb73e-8b5f-4cee-9f20-33cc0ce2767b	SMB-MG5JFZDP-8	Green Lawn Services	small_business	row	free	{"phone": "+19165554567", "industry": "Landscaping", "employees": 10, "contact_email": "info@greenlawn.com", "annual_revenue": "800K"}	m/44'/501'/925883877'/0'/0	active	27.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
23c042f1-9d43-4ccb-a83f-95aefd908086	SMB-MG5JFZDQ-9	Boutique Law Associates	small_business	row	small_business	{"phone": "+12135555678", "industry": "Legal Services", "employees": 8, "contact_email": "partners@boutiquelaw.com", "annual_revenue": "3M"}	m/44'/501'/8002381'/0'/0	active	70.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
77a7c7b9-26f3-459c-ac73-356f52c6ada7	SMB-MG5JFZDQ-10	Auto Repair Excellence	small_business	row	small_business	{"phone": "+15105556789", "industry": "Automotive", "employees": 12, "contact_email": "service@autoexcellence.com", "annual_revenue": "1.5M"}	m/44'/501'/994214167'/0'/0	active	24.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
46885f6e-5910-403a-abe8-b02a0fdc5601	SMB-MG5JFZDR-11	Creative Design Studio	small_business	row	small_business	{"phone": "+14087891", "industry": "Design", "employees": 6, "contact_email": "studio@creativedesign.com", "annual_revenue": "1M"}	m/44'/501'/1644775857'/0'/0	active	56.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
8e4cce0f-3151-4a99-bd06-59ae697d1fba	SMB-MG5JFZDR-12	Fitness Plus Gym	small_business	row	small_business	{"phone": "+18185558912", "industry": "Health & Fitness", "employees": 20, "contact_email": "manager@fitnessplus.com", "annual_revenue": "2.5M"}	m/44'/501'/410663554'/0'/0	active	39.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
a8ef762f-fd75-4345-b19c-1f1e09583580	SMB-MG5JFZDS-13	Pet Care Paradise	small_business	row	free	{"phone": "+16195559123", "industry": "Pet Services", "employees": 5, "contact_email": "care@petparadise.com", "annual_revenue": "500K"}	m/44'/501'/1390811728'/0'/0	active	46.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
109fc302-91ad-4244-81df-ae26468e7477	HLD-MG5JFZDT-14	Apex Holdings Group	holding_company	database	custom	{"phone": "+12125551111", "industry": "Investment", "subsidiaries": 12, "contact_email": "investors@apexholdings.com", "portfolio_value": "5B"}	m/44'/501'/1893437043'/0'/0	active	15.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
a9e167bf-6576-4224-b40a-e13dcb326449	HLD-MG5JFZDT-15	Diversified Ventures LLC	holding_company	database	enterprise	{"phone": "+13125552222", "industry": "Conglomerate", "subsidiaries": 8, "contact_email": "board@diversifiedventures.com", "portfolio_value": "2B"}	m/44'/501'/1829978781'/0'/0	active	28.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
77bb623f-e6f7-4fc9-bf4c-c857f99b2a42	IND-MG5JFZDU-16	John Smith Consulting	individual	row	free	{"phone": "+14155553333", "profession": "Business Consultant", "annual_income": "150K", "contact_email": "john@smithconsulting.com"}	m/44'/501'/570844031'/0'/0	active	70.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
3c340bd0-2850-48b9-b4f8-588cbd44ea47	IND-MG5JFZDU-17	Sarah Johnson Freelance	individual	row	free	{"phone": "+16505554444", "profession": "Graphic Designer", "annual_income": "80K", "contact_email": "sarah@sjdesigns.com"}	m/44'/501'/1492276271'/0'/0	active	76.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
9fae3aa1-e18c-4d1c-9bbe-c344a8878b3b	IND-MG5JFZDU-18	Michael Chen Trading	individual	row	small_business	{"phone": "+14085555555", "profession": "Day Trader", "annual_income": "250K", "contact_email": "michael@chentrading.com"}	m/44'/501'/943922308'/0'/0	active	37.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
c10f4b20-15b1-483e-8115-5168e672c850	IND-MG5JFZDV-19	Emily Davis Photography	individual	row	free	{"phone": "+18185556666", "profession": "Photographer", "annual_income": "60K", "contact_email": "emily@davisphotos.com"}	m/44'/501'/769900698'/0'/0	active	53.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
7698fcbe-b9f9-4940-a096-894eeb05e312	IND-MG5JFZDV-20	Robert Wilson Investments	individual	row	small_business	{"phone": "+19255557777", "profession": "Real Estate Investor", "annual_income": "500K", "contact_email": "robert@wilsoninvest.com"}	m/44'/501'/178884925'/0'/0	active	26.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
d6dc6dcd-f6e8-4a92-95fc-ca6deb0d00a4	HHM-MG5JFZDV-21	The Martinez Family	household_member	row	free	{"phone": "+13235558888", "members": 4, "contact_email": "martinez.family@email.com", "primary_contact": "Carlos Martinez"}	m/44'/501'/479719287'/0'/0	active	18.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
84da93f6-9eb5-4a36-9221-bbc304fed924	HHM-MG5JFZDV-22	Johnson Household	household_member	row	free	{"phone": "+17145559999", "members": 3, "contact_email": "ljohnson@email.com", "primary_contact": "Linda Johnson"}	m/44'/501'/946378332'/0'/0	active	12.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
ee76d02c-503f-4158-a253-40ce39259472	HHM-MG5JFZDW-23	The Kim Family Trust	household_member	row	small_business	{"phone": "+14245550000", "members": 5, "contact_email": "kimfamily@email.com", "primary_contact": "David Kim"}	m/44'/501'/126214470'/0'/0	active	25.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
b9aa9d81-78d7-4efb-953f-cae8daef6464	SMB-MG5JFZDW-24	EduTech Learning Platform	small_business	row	small_business	{"phone": "+16465551234", "industry": "Education Technology", "employees": 30, "contact_email": "support@edutech.com", "annual_revenue": "8M"}	m/44'/501'/1947526807'/0'/0	active	42.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
1bc1ff09-cba9-4eab-a86a-f9000207c07c	ENT-MG5JFZDW-25	Sustainable Energy Co	enterprise	database	enterprise	{"phone": "+15125552345", "industry": "Renewable Energy", "employees": 200, "contact_email": "info@sustainableenergy.com", "annual_revenue": "50M"}	m/44'/501'/947849111'/0'/0	active	31.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
b377556e-d461-4559-bfdf-70ec58238dce	SMB-MG5JFZDY-26	Crypto Trading Desk	small_business	row	small_business	{"phone": "+13055553456", "industry": "Cryptocurrency", "employees": 8, "contact_email": "trades@cryptodesk.com", "annual_revenue": "10M"}	m/44'/501'/642170580'/0'/0	pending	50.00	\N	2025-09-29 15:45:16.756456	2025-09-29 15:45:16.756456
f4b450a6-72c1-40ed-8b9c-c15bbbc08234	TNT-user-cd0	Test User	individual	row	free	{"email": "test@monay.com", "migrated_at": "2025-09-29T16:32:09.167237-04:00"}	\N	active	0.00	\N	2025-09-29 16:32:09.167237	2025-09-29 16:32:09.167237
a50b762f-b9ce-42a0-98da-7525e9277cc0	TNT-enterpri	Enterprise Admin	individual	row	free	{"email": "enterprise@monay.com", "migrated_at": "2025-09-29T16:32:09.167237-04:00"}	\N	active	0.00	\N	2025-09-29 16:32:09.167237	2025-09-29 16:32:09.167237
1a6de6ee-912d-442c-9fa1-4a5ef8f5e32f	ENT-912368CC	Tilli Pro	enterprise	schema	enterprise	{"phone": "+13002999999", "address": "", "description": "", "contact_email": "ali+1@tilli.pro"}	m/44'/501'/1234355819'/0'/0	active	80.00	\N	2025-09-29 21:34:51.864071	2025-09-29 21:34:51.864071
a00b7c16-d380-429a-87f5-72f7a92e5624	ENT-345FA4D1	Tilli Software	enterprise	schema	enterprise	{"phone": "+3307019988", "address": "8760 Main Stret, bethesda MD 20818", "description": "", "contact_email": "ali+13@tilli.pro"}	m/44'/501'/768339288'/0'/0	active	80.00	\N	2025-09-29 22:05:23.57051	2025-09-29 22:05:23.57051
4b3bb733-ed10-4189-946d-6f1f344f8fb4	ENT-3BBFAD5B	Microsoft	enterprise	schema	enterprise	{"phone": "+12345688899", "address": "1 Microsoft Dr, Somewhere, WA 123456", "description": "", "contact_email": "bill@microsoft.com"}	m/44'/501'/1765947692'/0'/0	active	80.00	\N	2025-09-30 00:10:47.751936	2025-09-30 00:10:47.751936
694c5c2a-62fb-4b56-b930-911b97c3128e	TNT-MG62F0R0	Test Org Tenant	enterprise	row	free	{"created_from": "org_creation", "organization_name": "Test Org"}	\N	active	0.00	\N	2025-09-30 00:36:24.589576	2025-09-30 00:36:24.589576
da8d6b37-1410-4ed6-83d0-e0c9b3f0cccb	TNT-MG62GNJE	Test Org Tenant	enterprise	row	free	{"created_from": "org_creation", "organization_name": "Test Org"}	\N	active	0.00	\N	2025-09-30 00:37:40.778428	2025-09-30 00:37:40.778428
49e7f16a-bbdc-4b3f-8fea-25f9cfcb888a	ENT-A28926EC	Microstrategy	enterprise	schema	enterprise	{"phone": "+1234567888", "address": "1800 Main Street, Cabin John MD 20818", "description": "Microstrategy", "contact_email": "ali@microstrategy.com"}	m/44'/501'/1006113731'/0'/0	active	80.00	\N	2025-09-30 19:45:01.484266	2025-09-30 19:45:01.484266
62cede32-e4af-4e06-8b82-8665bf396479	ENT-77CD1517	T-Mobile	enterprise	schema	enterprise	{"phone": "+13307011235", "address": "1800 Church St, McLean, VA 22012", "description": "Telco", "contact_email": "ali+1@t-mobile.com"}	m/44'/501'/778594785'/0'/0	active	80.00	\N	2025-09-30 21:07:57.785341	2025-09-30 21:07:57.785341
2c354613-9e2f-414b-bea5-183646d253a9	ENT-71CA97CB	Sysco	enterprise	schema	enterprise	{"phone": "+13307018877", "address": "1800 Main Street, Mclean VA 22012", "description": "Groceries Distribution Services", "contact_email": "ali@sysco.com"}	m/44'/501'/1667325742'/0'/0	active	80.00	\N	2025-09-30 23:20:10.876272	2025-09-30 23:20:10.876272
a69956ea-a23c-4e0b-bc5b-5c4547b9511e	ENT-7E814B17	Walmart	enterprise	schema	enterprise	{"phone": "+13307018866", "description": "Mart and Groceries", "contact_email": "ali@walmart.com"}	m/44'/501'/1188421387'/0'/0	active	80.00	\N	2025-10-01 01:31:57.795112	2025-10-01 01:31:57.795112
7b735c61-fe78-4b1f-8af6-5360ff09deb1	IND-5E1F4FF9	Healthcare Corp 1759339027958	individual	row	free	{"phone": "5552559074", "description": "", "contact_email": "healthcare_1759339027958@test.com"}	m/44'/501'/2129378209'/0'/0	active	60.00	\N	2025-10-01 13:17:20.793697	2025-10-01 13:17:20.793697
c2841e36-b242-4763-8d8d-84f21fee145a	IND-FA7E4B61	Healthcare Corp 1759339430312	individual	row	free	{"phone": "5551428716", "description": "", "contact_email": "healthcare_1759339430312@test.com"}	m/44'/501'/658790555'/0'/0	active	60.00	\N	2025-10-01 13:24:03.237114	2025-10-01 13:24:03.237114
88cd7d83-8bb6-4f97-ab45-8ae0a0a9b34f	IND-E3A4E74E	Healthcare Corp 1759346953258	individual	row	free	{"phone": "5559056574", "description": "", "contact_email": "healthcare_1759346953258@test.com"}	m/44'/501'/1838568121'/0'/0	active	60.00	\N	2025-10-01 15:29:18.492821	2025-10-01 15:29:18.492821
33eadcdd-82e6-4091-80d1-492cf42a209a	IND-CCA11821	Healthcare Corp 1759347622682	individual	row	free	{"phone": "5554397758", "description": "", "contact_email": "healthcare_1759347622682@test.com"}	m/44'/501'/480081868'/0'/0	active	60.00	\N	2025-10-01 15:40:27.864351	2025-10-01 15:40:27.864351
ef768a41-728e-4b7a-80cf-56b745341df1	IND-8601F91B	Healthcare Corp 1759348496283	individual	row	free	{"phone": "5553042027", "description": "", "contact_email": "healthcare_1759348496283@test.com"}	m/44'/501'/871800570'/0'/0	active	60.00	\N	2025-10-01 15:55:01.454558	2025-10-01 15:55:01.454558
f63c93a8-1277-4476-98c0-46dea83198f5	IND-D7C58BFA	Healthcare Corp 1759359763822	individual	row	free	{"phone": "5551950653", "description": "", "contact_email": "healthcare_1759359763822@test.com"}	m/44'/501'/1195614'/0'/0	active	60.00	\N	2025-10-01 19:02:49.010767	2025-10-01 19:02:49.010767
89657414-6f28-41b4-bff4-693d93d067fd	IND-08FFA87F	Healthcare Corp 1759359919511	individual	row	free	{"phone": "5558088872", "description": "", "contact_email": "healthcare_1759359919511@test.com"}	m/44'/501'/269514213'/0'/0	active	60.00	\N	2025-10-01 19:05:24.671037	2025-10-01 19:05:24.671037
c5246706-e142-43c2-b8d1-b3c3e03fe2c7	IND-A4F8FEBA	Healthcare Corp 1759360397470	individual	row	free	{"phone": "5557462406", "description": "", "contact_email": "healthcare_1759360397470@test.com"}	m/44'/501'/909775030'/0'/0	active	60.00	\N	2025-10-01 19:13:22.624215	2025-10-01 19:13:22.624215
328036f6-239f-444c-afb5-c80c064e4463	IND-81958E61	Healthcare Corp 1759360474730	individual	row	free	{"phone": "5551574195", "description": "", "contact_email": "healthcare_1759360474730@test.com"}	m/44'/501'/2057798704'/0'/0	active	60.00	\N	2025-10-01 19:14:39.903479	2025-10-01 19:14:39.903479
dd48f73e-a7f9-4907-ba90-0f233a794133	IND-67A494D3	Healthcare Corp 1759360542136	individual	row	free	{"phone": "5556852180", "description": "", "contact_email": "healthcare_1759360542136@test.com"}	m/44'/501'/247420086'/0'/0	active	60.00	\N	2025-10-01 19:15:47.301558	2025-10-01 19:15:47.301558
\.


--
-- Data for Name: tillipay_cards; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tillipay_cards (id, user_id, tillipay_card_id, card_number_masked, card_type, card_network, card_status, expiry_month, expiry_year, billing_address, spending_limits, metadata, created_at, activated_at, deactivated_at) FROM stdin;
\.


--
-- Data for Name: tillipay_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tillipay_transactions (id, card_id, tillipay_tx_id, transaction_type, amount, currency, merchant_name, merchant_category, status, authorization_code, decline_reason, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.tokens (id, enterprise_id, token_name, token_symbol, token_type, chain, contract_address, mint_address, decimals, total_supply, max_supply, is_paused, is_compliant, compliance_standard, stablecoin_type, stablecoin_peg, asset_type, metadata, created_at, updated_at, deployed_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.transactions (id, user_id, wallet_id, type, amount, currency, from_address, to_address, from_user_id, to_user_id, blockchain_network, transaction_hash, block_number, gas_used, gas_price, status, status_message, compliance_checked, compliance_status, risk_score, metadata, created_at, updated_at, completed_at, batch_id, "actionType", "createdAt", "updatedAt", "transactionUserId", "senderId", "receiverId", "transactionId", "transactionType", "paymentMethod", "paymentStatus", "cardType", "cardName", "bankName", "last4Digit", "apiReponse", "cnpToken", "paymentRequestId", "parentId") FROM stdin;
\.


--
-- Data for Name: treasury_accounts; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_accounts (id, enterprise_id, account_name, chain, address, balance, locked_balance, reserve_ratio, account_type, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: treasury_swaps; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_swaps (id, organization_id, amount, from_provider, to_provider, from_balance_before, from_balance_after, to_balance_before, to_balance_after, swap_reason, transaction_hash, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: treasury_transactions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.treasury_transactions (id, treasury_account_id, transaction_type, amount, token_id, from_address, to_address, blockchain_tx_id, status, executed_by, metadata, created_at, executed_at) FROM stdin;
\.


--
-- Data for Name: user_biometrics; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_biometrics (id, user_id, device_id, biometric_type, biometric_hash, salt, algorithm, is_active, enrolled_at, last_verified_at, failed_attempts, locked_until) FROM stdin;
\.


--
-- Data for Name: user_devices; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_devices (id, "userId", "deviceId", "deviceName", "deviceType", "deviceModel", "osVersion", "appVersion", timezone, "biometricEnabled", "isTrusted", created_at, "lastSeen", updated_at) FROM stdin;
a688f845-61d7-4b6c-b3b2-9a2c31bcc4eb	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184534116	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:22:14.204-04	\N	2025-09-29 18:22:14.204-04
ecc82ce5-3e19-497d-bb59-34366844bb0b	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184621977	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:23:42.075-04	\N	2025-09-29 18:23:42.075-04
541ec640-a7fb-409b-8c89-99b2d6d5e133	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184654289	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:24:14.401-04	\N	2025-09-29 18:24:14.401-04
4bd9471b-27e8-499a-a916-aeea5e89fc15	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184687698	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:24:47.806-04	\N	2025-09-29 18:24:47.806-04
9765252f-6b4c-43e1-af31-43f62c1bd5f2	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184720777	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:25:20.854-04	\N	2025-09-29 18:25:20.854-04
cec83264-1a7e-4552-b9a5-c6e193b18734	cmg5c4nom0000mdjhcai1fmre	web-browser-1759184747438	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-29 18:25:47.514-04	\N	2025-09-29 18:25:47.514-04
027529b2-6293-49bf-a632-6f8b1519470e	cmg5vkur70000hqjh38wvdo4p	web-1759195787734	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-29 21:29:47.859-04	\N	2025-09-29 21:29:47.859-04
50306e24-e0a7-4e59-b37c-2eef69ef5005	cmg5bdspj0000lajh2ypvcdlf	web-browser-1759255581983	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-30 14:06:22.231-04	\N	2025-09-30 14:06:22.231-04
1fadda9f-25d3-4c30-8234-11dfecf76754	cmg5bdspj0000lajh2ypvcdlf	web-1759255658835	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-30 14:07:38.958-04	\N	2025-09-30 14:07:38.958-04
cce62e95-9eaf-4133-bfba-077655e4aeb5	cmg5bdspj0000lajh2ypvcdlf	web-1759256239783	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-30 14:17:19.921-04	\N	2025-09-30 14:17:19.921-04
1ab3779d-00a5-43e7-a257-2b112ffe488c	cmg5bdspj0000lajh2ypvcdlf	web-browser-1759257241029	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-30 14:34:01.109-04	\N	2025-09-30 14:34:01.109-04
2f4d84fc-3e1d-4a01-b922-596c3b7f73c2	cmg5bdspj0000lajh2ypvcdlf	web-browser-1759258046039	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-30 14:47:26.15-04	\N	2025-09-30 14:47:26.15-04
e6a755fa-385a-42a7-becc-ab255168efab	cmg5bdspj0000lajh2ypvcdlf	web-1759258912990	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-30 15:01:53.176-04	\N	2025-09-30 15:01:53.176-04
93ac4c04-1092-4ef8-a648-43aa701e1dcd	cmg5bdspj0000lajh2ypvcdlf	web-1759260116622	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-30 15:21:56.752-04	\N	2025-09-30 15:21:56.752-04
c28bd32a-3fed-4b36-aa31-4b6eeeed1c59	cmg5bdspj0000lajh2ypvcdlf	web-1759262459082	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-09-30 16:00:59.231-04	\N	2025-09-30 16:00:59.231-04
c586d7e8-5a94-45a5-a365-c196dbfc8713	cmg5bdspj0000lajh2ypvcdlf	web-browser-1759275017776	\N	WEB	Web Browser	Web	1.0.0	\N	\N	\N	2025-09-30 19:30:17.901-04	\N	2025-09-30 19:30:17.901-04
5b6c0ca6-da22-44d6-9ced-7a8cb041ae5a	cmg5bdspj0000lajh2ypvcdlf	web-1759329782520	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-10-01 10:43:03.118-04	\N	2025-10-01 10:43:03.118-04
f18e584f-7193-45dd-9f76-2b0601b2f26f	cmg5bdspj0000lajh2ypvcdlf	web-1759343242032	\N	WEB	Web Browser	Web	1.0.0	America/New_York	\N	\N	2025-10-01 14:27:22.167-04	\N	2025-10-01 14:27:22.167-04
\.


--
-- Data for Name: user_devices_enhanced; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_devices_enhanced (id, user_id, device_id, device_name, device_type, device_model, os_version, app_version, push_token, biometric_enabled, biometric_type, device_fingerprint, trust_level, is_trusted, last_seen, created_at, blocked_at, blocked_reason) FROM stdin;
\.


--
-- Data for Name: user_mfa_settings; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_mfa_settings (id, user_id, mfa_type, is_primary, is_enabled, secret_encrypted, phone_number, email, backup_codes, last_used_at, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_profiles (id, user_id, profile_type, date_of_birth, ssn_last_four, personal_address, emergency_contact, job_title, department, employee_id, business_email, business_phone, profile_picture_url, preferences, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sso_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_sso_connections (id, user_id, provider_id, external_user_id, access_token_encrypted, refresh_token_encrypted, token_expires_at, profile_data, last_login_at, created_at) FROM stdin;
\.


--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.user_tokens (id, user_id, token, refresh_token, type, expires_at, created_at, updated_at) FROM stdin;
d5bf29bf-758b-4905-950f-6be025cd627b	cmg5vkur70000hqjh38wvdo4p	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZU51bWJlciI6Ijk5OTk5OTgiLCJzdGF0dXMiOiJhY3RpdmUiLCJ1c2VyVHlwZSI6InVzZXIiLCJ1bmlxdWVDb2RlIjoiY21nNXZrdXI3MDAwMGhxamgzOHd2ZG80cCIsInByb2ZpbGVQaWN0dXJlVXJsIjoiaHR0cDovL2xvY2FsaG9zdDozMDAxL3B1YmxpYy9kZWZhdWx0LWltYWdlcy91c2VyLnBuZyIsInFyQ29kZVVybCI6Imh0dHBzOi8vbG9jYWxob3N0OjMwMDEvcHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5MWNocW1nNXZrdXJ1LnBuZyIsInByb2ZpbGVQaWN0dXJlIjpudWxsLCJyZXF1aXJlZFZlcmlmaWNhdGlvbnMiOlsibW9iaWxlIl0sImlzRnVsbHlWZXJpZmllZCI6dHJ1ZSwiaWQiOiJjbWc1dmt1cjcwMDAwaHFqaDM4d3ZkbzRwIiwiZmlyc3ROYW1lIjoiWmFraSAiLCJsYXN0TmFtZSI6IlNhYmVyaSIsImVtYWlsIjoiYWxpKzEwQHNhYmVyaS51cyIsIm1vYmlsZSI6IisxOTk5OTk5OTk5OCIsInBob25lIjpudWxsLCJwcmltYXJ5Q29udGFjdCI6Im1vYmlsZSIsIm1waW4iOm51bGwsIndhbGxldEJhbGFuY2UiOjAsInByb2ZpbGVJbWFnZSI6bnVsbCwiZGF0ZU9mQmlydGgiOm51bGwsImdlbmRlciI6bnVsbCwiYWRkcmVzcyI6bnVsbCwiY2l0eSI6bnVsbCwic3RhdGUiOm51bGwsImNvdW50cnkiOm51bGwsInppcENvZGUiOm51bGwsImlzRW1haWxWZXJpZmllZCI6dHJ1ZSwid2hhdHNhcHBFbmFibGVkIjp0cnVlLCJ3aGF0c2FwcE51bWJlciI6IisxOTk5OTk5OTk5OCIsIm5vdGlmaWNhdGlvblByZWZlcmVuY2VzIjp7ImF1dGgiOlsibW9iaWxlIl0sInVyZ2VudCI6WyJtb2JpbGUiLCJ3aGF0c2FwcCJdLCJ1cGRhdGVzIjpbImVtYWlsIiwid2hhdHNhcHAiXSwibWFya2V0aW5nIjpbImVtYWlsIiwid2hhdHNhcHAiXSwidHJhbnNhY3Rpb25zIjpbIm1vYmlsZSIsImVtYWlsIiwid2hhdHNhcHAiXX0sImNvbnRhY3RNZXRhZGF0YSI6eyJsYXN0VXBkYXRlZCI6IjIwMjUtMDktMzBUMDE6MjQ6NTkuNDQzWiIsInByZWZlcnJlZENoYW5uZWwiOiJzbXMiLCJhbHRlcm5hdGl2ZUNoYW5uZWxzIjpbIndoYXRzYXBwIl0sInZlcmlmaWNhdGlvblJlcXVpcmVkIjpbIm1vYmlsZSJdfSwiaXNNb2JpbGVWZXJpZmllZCI6dHJ1ZSwiaXNQaG9uZVZlcmlmaWVkIjpmYWxzZSwiaXNLeWNWZXJpZmllZCI6ZmFsc2UsImlzQWN0aXZlIjp0cnVlLCJpc0RlbGV0ZWQiOmZhbHNlLCJpc0Jsb2NrZWQiOmZhbHNlLCJibG9ja2VkUmVhc29uIjpudWxsLCJhY2NvdW50VHlwZSI6ImNvbnN1bWVyIiwicmVmZXJyYWxDb2RlIjoiNjA4Njg5IiwicmVmZXJyZWRCeSI6bnVsbCwicXJDb2RlIjoicHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5MWNocW1nNXZrdXJ1LnBuZyIsInR3b0ZhY3RvckVuYWJsZWQiOmZhbHNlLCJsYXN0TG9naW5BdCI6bnVsbCwicm9sZSI6ImJhc2ljX2NvbnN1bWVyIiwiY3JlYXRlZF9hdCI6IjIwMjUtMDktMzBUMDE6MjQ6NTkuNDQ1WiIsInVwZGF0ZWRfYXQiOiIyMDI1LTA5LTMwVDAxOjI4OjQ5LjU0N1oiLCJ1c2VySWQiOiJjbWc1dmt1cjcwMDAwaHFqaDM4d3ZkbzRwIiwiaWF0IjoxNzU5MTk1Nzg3LCJleHAiOjE3NTk0NTQ5ODd9.bRysAz-rjQ8ka7PYi7MsL8lSlqhQDIrUAxp_qujVRYU	\N	WEB	2025-10-29 21:29:47.851-04	2025-09-29 21:29:47.851698-04	2025-09-29 21:29:47.851698-04
3cb381b8-25ff-4b8c-a3ed-89ad281a6e6f	enterprise-2c354613-9e2f-414b-bea5-183646d253a9	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZU51bWJlciI6IjcwMTg4NzciLCJzdGF0dXMiOiJhY3RpdmUiLCJ1c2VyVHlwZSI6InVzZXIiLCJ1bmlxdWVDb2RlIjoiZW50ZXJwcmlzZS0yYzM1NDYxMy05ZTJmLTQxNGItYmVhNS0xODM2NDZkMjUzYTkiLCJwcm9maWxlUGljdHVyZVVybCI6Imh0dHA6Ly9sb2NhbGhvc3Q6MzAwMS9wdWJsaWMvZGVmYXVsdC1pbWFnZXMvdXNlci5wbmciLCJxckNvZGVVcmwiOiJodHRwczovL2xvY2FsaG9zdDozMDAxL3B1YmxpYy91cGxvYWRzL3FyY29kZS9xcmNvZGVfa2l1OW9nNm1nN2hkc2t4LnBuZyIsInByb2ZpbGVQaWN0dXJlIjpudWxsLCJyZXF1aXJlZFZlcmlmaWNhdGlvbnMiOlsibW9iaWxlIl0sImlzRnVsbHlWZXJpZmllZCI6ZmFsc2UsImlkIjoiZW50ZXJwcmlzZS0yYzM1NDYxMy05ZTJmLTQxNGItYmVhNS0xODM2NDZkMjUzYTkiLCJmaXJzdE5hbWUiOiJTeXNjbyIsImxhc3ROYW1lIjoiQWRtaW4iLCJlbWFpbCI6ImFsaUBzeXNjby5jb20iLCJtb2JpbGUiOiIrMTMzMDcwMTg4NzciLCJwaG9uZSI6IisxMzMwNzAxODg3NyIsInByaW1hcnlDb250YWN0IjoibW9iaWxlIiwibXBpbiI6bnVsbCwid2FsbGV0QmFsYW5jZSI6MCwicHJvZmlsZUltYWdlIjpudWxsLCJkYXRlT2ZCaXJ0aCI6bnVsbCwiZ2VuZGVyIjpudWxsLCJhZGRyZXNzIjpudWxsLCJjaXR5IjpudWxsLCJzdGF0ZSI6bnVsbCwiY291bnRyeSI6bnVsbCwiemlwQ29kZSI6bnVsbCwiaXNFbWFpbFZlcmlmaWVkIjpmYWxzZSwid2hhdHNhcHBFbmFibGVkIjpmYWxzZSwid2hhdHNhcHBOdW1iZXIiOm51bGwsIm5vdGlmaWNhdGlvblByZWZlcmVuY2VzIjp7ImF1dGgiOlsibW9iaWxlIl0sInVyZ2VudCI6WyJtb2JpbGUiLCJ3aGF0c2FwcCJdLCJ1cGRhdGVzIjpbImVtYWlsIiwid2hhdHNhcHAiXSwibWFya2V0aW5nIjpbImVtYWlsIl0sInZvaWNlX2F1dGgiOlsicGhvbmUiXSwidHJhbnNhY3Rpb25zIjpbImVtYWlsIiwid2hhdHNhcHAiXX0sImNvbnRhY3RNZXRhZGF0YSI6e30sImlzTW9iaWxlVmVyaWZpZWQiOmZhbHNlLCJpc1Bob25lVmVyaWZpZWQiOmZhbHNlLCJpc0t5Y1ZlcmlmaWVkIjpmYWxzZSwiaXNBY3RpdmUiOnRydWUsImlzRGVsZXRlZCI6ZmFsc2UsImlzQmxvY2tlZCI6ZmFsc2UsImJsb2NrZWRSZWFzb24iOm51bGwsImFjY291bnRUeXBlIjoiZW50ZXJwcmlzZSIsInJlZmVycmFsQ29kZSI6bnVsbCwicmVmZXJyZWRCeSI6bnVsbCwicXJDb2RlIjoicHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5b2c2bWc3aGRza3gucG5nIiwidHdvRmFjdG9yRW5hYmxlZCI6ZmFsc2UsImxhc3RMb2dpbkF0IjpudWxsLCJyb2xlIjoiZW50ZXJwcmlzZV9hZG1pbiIsImNyZWF0ZWRfYXQiOiIyMDI1LTEwLTAxVDAzOjIwOjEwLjk1NloiLCJ1cGRhdGVkX2F0IjoiMjAyNS0xMC0wMVQwNjowNDozMC4wMjhaIiwidXNlcklkIjoiZW50ZXJwcmlzZS0yYzM1NDYxMy05ZTJmLTQxNGItYmVhNS0xODM2NDZkMjUzYTkiLCJpYXQiOjE3NTk0MTU0NjksImV4cCI6MTc1OTQxNzI2OX0.94BiKN7hoxxYgm4h2e3KrVOl2z3paMO9M0pBNXzKu7Q	\N	web	2025-10-31 00:23:07.726-04	2025-10-01 00:23:07.728029-04	2025-10-02 10:31:09.598577-04
d628762b-a8c9-43f8-af82-c2059b7412ac	cmg5c4nom0000mdjhcai1fmre	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZU51bWJlciI6IjEyMzQ1NjciLCJzdGF0dXMiOiJhY3RpdmUiLCJ1c2VyVHlwZSI6InVzZXIiLCJ1bmlxdWVDb2RlIjoiY21nNWM0bm9tMDAwMG1kamhjYWkxZm1yZSIsInByb2ZpbGVQaWN0dXJlVXJsIjoiaHR0cDovL2xvY2FsaG9zdDozMDAxL3B1YmxpYy9kZWZhdWx0LWltYWdlcy91c2VyLnBuZyIsInFyQ29kZVVybCI6Imh0dHBzOi8vbG9jYWxob3N0OjMwMDEvcHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5aW1kbWc1YzRucDcucG5nIiwicHJvZmlsZVBpY3R1cmUiOm51bGwsInJlcXVpcmVkVmVyaWZpY2F0aW9ucyI6WyJtb2JpbGUiXSwiaXNGdWxseVZlcmlmaWVkIjp0cnVlLCJpZCI6ImNtZzVjNG5vbTAwMDBtZGpoY2FpMWZtcmUiLCJmaXJzdE5hbWUiOiJVbmlmaWVkIiwibGFzdE5hbWUiOiJUZXN0IiwiZW1haWwiOiJ1bmlmaWVkLnRlc3RAbW9uYXkuY29tIiwibW9iaWxlIjoiKzE1NTUxMjM0NTY3IiwicGhvbmUiOm51bGwsInByaW1hcnlDb250YWN0IjoibW9iaWxlIiwibXBpbiI6bnVsbCwid2FsbGV0QmFsYW5jZSI6MCwicHJvZmlsZUltYWdlIjpudWxsLCJkYXRlT2ZCaXJ0aCI6bnVsbCwiZ2VuZGVyIjpudWxsLCJhZGRyZXNzIjpudWxsLCJjaXR5IjpudWxsLCJzdGF0ZSI6bnVsbCwiY291bnRyeSI6bnVsbCwiemlwQ29kZSI6bnVsbCwiaXNFbWFpbFZlcmlmaWVkIjp0cnVlLCJ3aGF0c2FwcEVuYWJsZWQiOnRydWUsIndoYXRzYXBwTnVtYmVyIjoiKzE1NTUxMjM0NTY3Iiwibm90aWZpY2F0aW9uUHJlZmVyZW5jZXMiOnsiYXV0aCI6WyJtb2JpbGUiXSwidXJnZW50IjpbIm1vYmlsZSIsIndoYXRzYXBwIl0sInVwZGF0ZXMiOlsiZW1haWwiLCJ3aGF0c2FwcCJdLCJtYXJrZXRpbmciOlsiZW1haWwiLCJ3aGF0c2FwcCJdLCJ0cmFuc2FjdGlvbnMiOlsibW9iaWxlIiwiZW1haWwiLCJ3aGF0c2FwcCJdfSwiY29udGFjdE1ldGFkYXRhIjp7Imxhc3RVcGRhdGVkIjoiMjAyNS0wOS0yOVQxNjoyMDozMS4wNzhaIiwicHJlZmVycmVkQ2hhbm5lbCI6InNtcyIsImFsdGVybmF0aXZlQ2hhbm5lbHMiOlsid2hhdHNhcHAiXSwidmVyaWZpY2F0aW9uUmVxdWlyZWQiOlsibW9iaWxlIl19LCJpc01vYmlsZVZlcmlmaWVkIjp0cnVlLCJpc1Bob25lVmVyaWZpZWQiOnRydWUsImlzS3ljVmVyaWZpZWQiOmZhbHNlLCJpc0FjdGl2ZSI6dHJ1ZSwiaXNEZWxldGVkIjpmYWxzZSwiaXNCbG9ja2VkIjpmYWxzZSwiYmxvY2tlZFJlYXNvbiI6bnVsbCwiYWNjb3VudFR5cGUiOiJiYXNpY19jb25zdW1lciIsInJlZmVycmFsQ29kZSI6IjM3NTY1MCIsInJlZmVycmVkQnkiOm51bGwsInFyQ29kZSI6InB1YmxpYy91cGxvYWRzL3FyY29kZS9xcmNvZGVfa2l1OWltZG1nNWM0bnA3LnBuZyIsInR3b0ZhY3RvckVuYWJsZWQiOmZhbHNlLCJsYXN0TG9naW5BdCI6bnVsbCwicm9sZSI6ImJhc2ljX2NvbnN1bWVyIiwiY3JlYXRlZF9hdCI6IjIwMjUtMDktMjlUMTY6MjA6MzEuMDc5WiIsInVwZGF0ZWRfYXQiOiIyMDI1LTA5LTI5VDIyOjE5OjI5LjE0NloiLCJ1c2VySWQiOiJjbWc1YzRub20wMDAwbWRqaGNhaTFmbXJlIiwiaWF0IjoxNzU5MTg0NzQ3LCJleHAiOjE3NTk0NDM5NDd9.QOtrJz_GwIvJqNUH7U8hd-fzsI0Bzq3Z7A7JeJ2hRJk	\N	WEB	2025-10-29 18:19:33.409-04	2025-09-29 18:19:33.412192-04	2025-09-29 18:25:47.509781-04
704d46ed-864a-450c-9739-bd4134d0c5d8	cmg5bdspj0000lajh2ypvcdlf	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZU51bWJlciI6IjIyMjMzMzMiLCJzdGF0dXMiOiJhY3RpdmUiLCJ1c2VyVHlwZSI6InVzZXIiLCJ1bmlxdWVDb2RlIjoiY21nNWJkc3BqMDAwMGxhamgyeXB2Y2RsZiIsInByb2ZpbGVQaWN0dXJlVXJsIjoiaHR0cDovL2xvY2FsaG9zdDozMDAxL3B1YmxpYy9kZWZhdWx0LWltYWdlcy91c2VyLnBuZyIsInFyQ29kZVVybCI6Imh0dHBzOi8vbG9jYWxob3N0OjMwMDEvcHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5YmxhbWc1YmRzc3AucG5nIiwicHJvZmlsZVBpY3R1cmUiOm51bGwsInJlcXVpcmVkVmVyaWZpY2F0aW9ucyI6WyJtb2JpbGUiXSwiaXNGdWxseVZlcmlmaWVkIjp0cnVlLCJpZCI6ImNtZzViZHNwajAwMDBsYWpoMnlwdmNkbGYiLCJmaXJzdE5hbWUiOiJEZWJyYSIsImxhc3ROYW1lIjoiQnVkaWFuaSIsImVtYWlsIjoibmV3dGVzdEBtb25heS5jb20iLCJtb2JpbGUiOiIrMTU1NTIyMjMzMzMiLCJwaG9uZSI6bnVsbCwicHJpbWFyeUNvbnRhY3QiOiJtb2JpbGUiLCJtcGluIjoiJDJhJDEwJFRoMVpqRC5wVGRDenpwbUMwNWwzd3VzQ1hjRDR6ak1uUjBZc3lTM25uMmM0N2ZrazNLNGJ5Iiwid2FsbGV0QmFsYW5jZSI6MCwicHJvZmlsZUltYWdlIjpudWxsLCJkYXRlT2ZCaXJ0aCI6bnVsbCwiZ2VuZGVyIjpudWxsLCJhZGRyZXNzIjpudWxsLCJjaXR5IjpudWxsLCJzdGF0ZSI6ImFjdGl2ZSIsImNvdW50cnkiOm51bGwsInppcENvZGUiOm51bGwsImlzRW1haWxWZXJpZmllZCI6ZmFsc2UsIndoYXRzYXBwRW5hYmxlZCI6dHJ1ZSwid2hhdHNhcHBOdW1iZXIiOiIrMTU1NTIyMjMzMzMiLCJub3RpZmljYXRpb25QcmVmZXJlbmNlcyI6eyJhdXRoIjpbIm1vYmlsZSJdLCJ1cmdlbnQiOlsibW9iaWxlIiwid2hhdHNhcHAiXSwidXBkYXRlcyI6WyJlbWFpbCIsIndoYXRzYXBwIl0sIm1hcmtldGluZyI6WyJlbWFpbCJdLCJ2b2ljZV9hdXRoIjpbInBob25lIl0sInRyYW5zYWN0aW9ucyI6WyJlbWFpbCIsIndoYXRzYXBwIl19LCJjb250YWN0TWV0YWRhdGEiOnt9LCJpc01vYmlsZVZlcmlmaWVkIjp0cnVlLCJpc1Bob25lVmVyaWZpZWQiOmZhbHNlLCJpc0t5Y1ZlcmlmaWVkIjpmYWxzZSwiaXNBY3RpdmUiOnRydWUsImlzRGVsZXRlZCI6ZmFsc2UsImlzQmxvY2tlZCI6ZmFsc2UsImJsb2NrZWRSZWFzb24iOm51bGwsImFjY291bnRUeXBlIjoiYmFzaWNfY29uc3VtZXIiLCJyZWZlcnJhbENvZGUiOiIzOTA1NzYiLCJyZWZlcnJlZEJ5IjpudWxsLCJxckNvZGUiOiJwdWJsaWMvdXBsb2Fkcy9xcmNvZGUvcXJjb2RlX2tpdTlibGFtZzViZHNzcC5wbmciLCJ0d29GYWN0b3JFbmFibGVkIjpmYWxzZSwibGFzdExvZ2luQXQiOm51bGwsInJvbGUiOiJjb25zdW1lciIsImNyZWF0ZWRfYXQiOiIyMDI1LTA5LTI5VDE1OjU5OjM3Ljg4MFoiLCJ1cGRhdGVkX2F0IjoiMjAyNS0wOS0zMFQxOTo1Nzo1Ny4zMTFaIiwidXNlcklkIjoiY21nNWJkc3BqMDAwMGxhamgyeXB2Y2RsZiIsImlhdCI6MTc1OTM0MzI0MiwiZXhwIjoxNzU5MzQ1MDQyfQ.X1BoXwgMMRDH0_5bF79sy86r7kqOQaws_VHBdSxex_Y	\N	WEB	2025-10-30 14:06:22.188-04	2025-09-30 14:06:22.190536-04	2025-10-01 14:27:22.152187-04
872c6fbf-a734-4cce-8cc1-9d96c9227bd8	admin-88da2d60-98f1-4161-9329-f51e340f8248	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwaG9uZU51bWJlciI6IjU1NTEyMzQiLCJzdGF0dXMiOiJhY3RpdmUiLCJ1c2VyVHlwZSI6ImFkbWluIiwidW5pcXVlQ29kZSI6ImFkbWluLTg4ZGEyZDYwLTk4ZjEtNDE2MS05MzI5LWY1MWUzNDBmODI0OCIsInByb2ZpbGVQaWN0dXJlVXJsIjoiaHR0cDovL2xvY2FsaG9zdDozMDAxL3B1YmxpYy9kZWZhdWx0LWltYWdlcy91c2VyLnBuZyIsInFyQ29kZVVybCI6Imh0dHBzOi8vbG9jYWxob3N0OjMwMDEvcHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5MXlkaG1nNHd5ZjVqLnBuZyIsInByb2ZpbGVQaWN0dXJlIjoiaHR0cHM6Ly91aS1hdmF0YXJzLmNvbS9hcGkvP25hbWU9QWRtaW4rTW9uYXkmYmFja2dyb3VuZD0wRDhBQkMmY29sb3I9ZmZmIiwicmVxdWlyZWRWZXJpZmljYXRpb25zIjpbIm1vYmlsZSJdLCJpc0Z1bGx5VmVyaWZpZWQiOnRydWUsImlkIjoiYWRtaW4tODhkYTJkNjAtOThmMS00MTYxLTkzMjktZjUxZTM0MGY4MjQ4IiwiZmlyc3ROYW1lIjoiQWRtaW4iLCJsYXN0TmFtZSI6Ik1vbmF5IiwiZW1haWwiOiJhZG1pbkBtb25heS5jb20iLCJtb2JpbGUiOiIrMTIwMjU1NTEyMzQiLCJwaG9uZSI6bnVsbCwicHJpbWFyeUNvbnRhY3QiOiJtb2JpbGUiLCJtcGluIjoiJDJhJDEwJFRoMVpqRC5wVGRDenpwbUMwNWwzd3VzQ1hjRDR6ak1uUjBZc3lTM25uMmM0N2ZrazNLNGJ5Iiwid2FsbGV0QmFsYW5jZSI6MCwicHJvZmlsZUltYWdlIjoiaHR0cHM6Ly91aS1hdmF0YXJzLmNvbS9hcGkvP25hbWU9QWRtaW4rTW9uYXkmYmFja2dyb3VuZD0wRDhBQkMmY29sb3I9ZmZmIiwiZGF0ZU9mQmlydGgiOiIxOTkwLTAxLTAxIiwiZ2VuZGVyIjpudWxsLCJhZGRyZXNzIjpudWxsLCJjaXR5IjpudWxsLCJzdGF0ZSI6ImFjdGl2ZSIsImNvdW50cnkiOm51bGwsInppcENvZGUiOm51bGwsImlzRW1haWxWZXJpZmllZCI6ZmFsc2UsIndoYXRzYXBwRW5hYmxlZCI6dHJ1ZSwid2hhdHNhcHBOdW1iZXIiOiIrMTIwMjU1NTEyMzQiLCJub3RpZmljYXRpb25QcmVmZXJlbmNlcyI6eyJhdXRoIjpbIm1vYmlsZSJdLCJ1cmdlbnQiOlsibW9iaWxlIiwid2hhdHNhcHAiXSwidXBkYXRlcyI6WyJlbWFpbCIsIndoYXRzYXBwIl0sIm1hcmtldGluZyI6WyJlbWFpbCJdLCJ2b2ljZV9hdXRoIjpbInBob25lIl0sInRyYW5zYWN0aW9ucyI6WyJlbWFpbCIsIndoYXRzYXBwIl19LCJjb250YWN0TWV0YWRhdGEiOnt9LCJpc01vYmlsZVZlcmlmaWVkIjp0cnVlLCJpc1Bob25lVmVyaWZpZWQiOmZhbHNlLCJpc0t5Y1ZlcmlmaWVkIjp0cnVlLCJpc0FjdGl2ZSI6dHJ1ZSwiaXNEZWxldGVkIjpmYWxzZSwiaXNCbG9ja2VkIjpmYWxzZSwiYmxvY2tlZFJlYXNvbiI6bnVsbCwiYWNjb3VudFR5cGUiOiJwbGF0Zm9ybV9hZG1pbiIsInJlZmVycmFsQ29kZSI6bnVsbCwicmVmZXJyZWRCeSI6bnVsbCwicXJDb2RlIjoicHVibGljL3VwbG9hZHMvcXJjb2RlL3FyY29kZV9raXU5MXlkaG1nNHd5ZjVqLnBuZyIsInR3b0ZhY3RvckVuYWJsZWQiOmZhbHNlLCJsYXN0TG9naW5BdCI6IjIwMjUtMDktMjlUMDM6MjA6MDguNjUzWiIsInJvbGUiOiJwbGF0Zm9ybV9hZG1pbiIsImNyZWF0ZWRfYXQiOiIyMDI1LTA5LTIzVDEyOjAyOjMyLjY0MloiLCJ1cGRhdGVkX2F0IjoiMjAyNS0xMC0wMVQxNzoxMDoyNS4yNjhaIiwidXNlcklkIjoiYWRtaW4tODhkYTJkNjAtOThmMS00MTYxLTkzMjktZjUxZTM0MGY4MjQ4IiwiaWF0IjoxNzU5NDE0MTU5LCJleHAiOjE3NTk0MTU5NTl9.Ljgl_isHyaL-O-xfKBgB4KAT42EtQr9oa1HeSTQcCXQ	\N	WEB	2025-10-29 05:02:54.166-04	2025-09-29 05:02:54.166724-04	2025-10-02 10:09:19.734995-04
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.users (id, email, username, first_name, last_name, mobile, password_hash, profile_image, date_of_birth, auth_level, require_mfa, mfa_grace_period_until, biometric_enabled, custody_type, risk_profile, last_risk_assessment, passwordless_enabled, recovery_email, recovery_phone, security_questions, trusted_ips, allowed_countries, blocked_countries, failed_login_attempts, last_failed_login, account_locked_until, password_changed_at, password_history, session_timeout_minutes, mobile_verified, is_active, kyc_verified, kyc_level, metadata, created_at, updated_at, last_login, user_type, primary_organization_id, consumer_kyc_level, consumer_daily_limit, consumer_monthly_limit, preferred_provider, family_group_id, is_primary_user, mpin, wallet_balance, is_deleted, is_blocked, blocked_reason, referral_code, referred_by, qr_code, gender, address, city, state, country, zip_code, phone, primary_contact, phone_verified, email_verified, whatsapp_enabled, whatsapp_number, notification_preferences, contact_metadata, role, onboarding_completed, onboarding_step) FROM stdin;
enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	enterprise@monay.com	enterprise	Enterprise	Admin	\N	$2a$06$AWmU.2SDQQ9q1p90XdXeGeHgeP.Uv3aLYRUnj8vOOuHGvAaUm2DlS	\N	\N	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:09:44.670034-04	\N	30	t	t	t	\N	{}	2025-09-23 08:09:44.670034-04	2025-09-23 08:09:44.670034-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5b274u0000j6jhcz790jsw	testuser@monay.com	\N	Test	User	+13016821633	$2b$10$DKKxVNnm./giMoqc4GJQIOGF8YkuoxO3kIp19tS4xGRz8RRZilAX2	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 11:50:36.70861-04	\N	30	f	t	f	\N	{}	2025-09-29 11:50:36.703-04	2025-09-29 11:50:36.800332-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	472700	\N	public/uploads/qrcode/qrcode_kiu98j6mg5b2775.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+13016821633	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5b8so00001j6jh45901h4r	testuser2@monay.com	\N	Test	User	+15559876543	$2b$10$Gu27FapAfG6X3x62BCXfPuqsET5LGbZgYGSw0WZYOneSaMzjNYmLC	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 11:55:44.551476-04	\N	30	f	t	f	\N	{}	2025-09-29 11:55:44.545-04	2025-09-29 11:55:44.573131-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	386749	\N	public/uploads/qrcode/qrcode_kiu98j6mg5b8son.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15559876543	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bfn1300007vjhgp1ua6q3	test1759161663@monay.com	\N	Test	Registration	+15559161663	$2b$10$HA88dXstIb6FXWPg5//RyOe8iNI0dByFqi3fgoHKOhgbiE.tO3Ykq	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:01:03.834765-04	\N	30	f	t	f	\N	{}	2025-09-29 12:01:03.832-04	2025-09-29 12:01:03.903219-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	286661	\N	public/uploads/qrcode/qrcode_kiu9c7vmg5bfn2r.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15559161663	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bq84k0000a0jhcrc158qm	testconsumer@monay.com	\N	Test	Consumer	+15554444444	$2b$10$JGqiAdpp9wqtlPlb4nh3MuILntSAa2ob1ZSoenACG6WtllWGsYHbS	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:09:17.736671-04	\N	30	f	t	f	\N	{}	2025-09-29 12:09:17.734-04	2025-09-29 12:09:17.761983-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	663042	\N	public/uploads/qrcode/qrcode_kiu9ea0mg5bq852.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15554444444	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5brdtp0000a1jhca6995dg	testconsumer2@monay.com	\N	Test	Consumer2	+15555555555	$2b$10$3s/6t8ecYVkzeTgzEFY35e0V1Ocps2D.hx83wz8fxtXhodorja8MW	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:10:11.776715-04	\N	30	f	t	f	\N	{}	2025-09-29 12:10:11.774-04	2025-09-29 12:10:11.83638-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	693474	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5brdv3.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15555555555	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bs6430001a1jh3ucsg6so	johndoe@monay.com	\N	John	Doe	+15556667777	$2b$10$RJXbHeBVeV2OmBlvZN0.ouJQzupIIrzU1EyWhS.CjqQ2ekMTmhvWK	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:10:48.436804-04	\N	30	f	t	f	\N	{}	2025-09-29 12:10:48.436-04	2025-09-29 12:10:48.450384-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	748630	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5bs64d.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15556667777	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bskpq0002a1jh6iore11f	janesmith@monay.com	\N	Jane	Smith	+15558889999	$2b$10$b1mib5uDkDJnbgFSycENrusNyH/HydVjEhO0DTnur1Cz0KRLg4qhe	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:11:07.359125-04	\N	30	f	t	f	\N	{}	2025-09-29 12:11:07.358-04	2025-09-29 12:11:07.368162-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	436912	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5bskpw.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15558889999	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bt8cq0003a1jh42lyeegb	enterprise.manager@monay.com	\N	Enterprise	Manager	+15551113333	$2b$10$bG9Vak2v.brPO3tfN88NOu37y3mV5VxVy71CQW6n9Hn5s152H1fO.	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:11:37.995023-04	\N	30	f	t	f	\N	{}	2025-09-29 12:11:37.994-04	2025-09-29 12:11:38.007922-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	809558	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5bt8cz.png	\N	\N	\N	\N	\N	\N	\N	email	f	f	t	+15551113333	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5btj1o0004a1jhfnto7ctp	admin.user@monay.com	\N	Admin	User	+15551114444	$2b$10$b8gpSzZQHjyTzjIHXr5mpu5bAU6zRdIlKGTWzu2n5VADZxgasG2Ha	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:11:51.853132-04	\N	30	f	t	f	\N	{}	2025-09-29 12:11:51.852-04	2025-09-29 12:11:51.862563-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	982478	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5btj1u.png	\N	\N	\N	\N	\N	\N	\N	email	f	f	t	+15551114444	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
user-cd06a4f0-b5fd-4c33-b0a2-79a518d62567	test@monay.com	testuser	Test	User	\N	$2a$06$zNOUyI7ox4Q.cxvXx82jrOnHBu7qIBBGdgXdkOiulO7Ks2FEYPgaW	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:01:08.473516-04	\N	30	t	t	f	\N	{}	2025-09-23 08:01:08.473516-04	2025-09-30 02:35:19.652316-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	fAtrCA==	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5bdspj0000lajh2ypvcdlf	newtest@monay.com	\N	Debra	Budiani	+15552223333	$2b$10$0BZ7hdm6tJ0mVhO.TeVgk.ufqKxbdCEWx0dqlALy2wURwOLRiyvYS	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 11:59:37.882822-04	\N	30	t	t	f	\N	{}	2025-09-29 11:59:37.88-04	2025-09-30 15:57:57.311709-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	$2a$10$Th1ZjD.pTdCzzpmC05l3wusCXcD4zjMnR0YsyS3nn2c47fkk3K4by	0	f	f	\N	390576	\N	public/uploads/qrcode/qrcode_kiu9blamg5bdssp.png	\N	\N	\N	active	\N	\N	\N	mobile	f	f	t	+15552223333	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	consumer	f	\N
cmg5bwv5v0005a1jhch2dggfh	secondary.child@monay.com	\N	Secondary	Child	+15559991111	$2b$10$GmBvq4njAy76/WVvrQXmM.QGb3rQmfYDRxe/BU8HsAB3fXAbApmhG	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:14:27.525001-04	\N	30	f	t	f	\N	{}	2025-09-29 12:14:27.524-04	2025-09-29 12:14:27.544096-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	123209	\N	public/uploads/qrcode/qrcode_kiu9fa1mg5bwv68.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15559991111	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5ce4ry0001mdjh2ukt2ofm	test.consumer.1759163273@test.com	\N	Test	Consumer	+15559163273	$2b$10$77DL1j8ozyjmPDPLeFV52OH5wnnIgc12p6Vdy3AJuppyJ2UW38cQy	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:27:53.135547-04	\N	30	f	t	f	\N	{}	2025-09-29 12:27:53.134-04	2025-09-29 12:27:53.159399-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	874586	\N	public/uploads/qrcode/qrcode_kiu9imdmg5ce4se.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15559163273	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T16:27:53.134Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	\N	f	\N
cmg5ce4v10002mdjhaahhfh7v	test.enterprise.1759163273@test.com	\N	Test	Enterprise	+15569163273	$2b$10$yuavtaQXAIjMyhkqRyqTEujN9pDnp/GVjbuHGG7zGA1JPgz4DccTC	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:27:53.246503-04	\N	30	f	t	f	\N	{}	2025-09-29 12:27:53.245-04	2025-09-29 12:27:53.253153-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	342262	\N	public/uploads/qrcode/qrcode_kiu9imdmg5ce4v4.png	\N	\N	\N	\N	\N	\N	\N	email	f	f	t	+15569163273	{"auth": ["email", "mobile"], "urgent": ["email", "mobile"], "updates": ["email"], "marketing": ["email"], "transactions": ["email"]}	{"lastUpdated": "2025-09-29T16:27:53.245Z", "preferredChannel": "email", "alternativeChannels": ["whatsapp"], "verificationRequired": ["email"]}	\N	f	\N
cmg5ce4xj0003mdjhbfcecrqe	test.admin.1759163273@test.com	\N	Test	Admin	+15579163273	$2b$10$eMsBUWPWs/4AZkWkLlXZ4OechJ9SeKwmcimWCVW1WxAwyUGUj030G	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:27:53.336435-04	\N	30	f	t	f	\N	{}	2025-09-29 12:27:53.335-04	2025-09-29 12:27:53.34328-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	687972	\N	public/uploads/qrcode/qrcode_kiu9imdmg5ce4xn.png	\N	\N	\N	\N	\N	\N	\N	email	f	f	t	+15579163273	{"auth": ["email", "mobile"], "urgent": ["email", "mobile"], "updates": ["email"], "marketing": ["email"], "transactions": ["email"]}	{"lastUpdated": "2025-09-29T16:27:53.335Z", "preferredChannel": "email", "alternativeChannels": ["whatsapp"], "verificationRequired": ["email"]}	\N	f	\N
admin-88da2d60-98f1-4161-9329-f51e340f8248	admin@monay.com	admin	Admin	Monay	+12025551234	$2a$12$78phADLyeSo0RO/FmZBkneEaalNJviBHolDwvwfv8iC4zLbaRvHB6	https://ui-avatars.com/api/?name=Admin+Monay&background=0D8ABC&color=fff	1990-01-01	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-28 22:57:55.804411-04	\N	30	t	t	t	\N	{}	2025-09-23 08:02:32.642268-04	2025-10-01 13:10:25.268125-04	2025-09-28 23:20:08.653-04	platform_admin	\N	3	1000000.000000000000000000	10000000.000000000000000000	tempo	\N	t	$2a$10$Th1ZjD.pTdCzzpmC05l3wusCXcD4zjMnR0YsyS3nn2c47fkk3K4by	0	f	f	\N	\N	\N	public/uploads/qrcode/qrcode_kiu91ydhmg4wyf5j.png	\N	\N	\N	active	\N	\N	\N	mobile	f	f	t	+12025551234	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	platform_admin	f	\N
cmg5onf4h0000o6jhgix0hz46	ali@saberi.us	\N	ali	Saberi	+13016821632	$2b$10$qpVuRixYi4NWnMUtn8TUruWCCyiXXQcw1jhojkSlbVR3IYfHx6fse	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 18:11:01.844462-04	\N	30	f	t	f	\N	{}	2025-09-29 18:11:01.842-04	2025-09-29 18:11:01.886971-04	\N	personal	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	490947	\N	public/uploads/qrcode/qrcode_kiu9so6mg5onf55.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+13016821632	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T22:11:01.841Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5oqg320001o6jhd8138jjr	ali+1@saberi.us	\N	Ali	Saberi	+13016821634	$2b$10$unKKKiLanwsqcEzdRj9EY.sm5QkSKOfHYuKMSiLWyi5CZvcOtn5Ki	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 18:13:23.058421-04	\N	30	f	t	f	\N	{}	2025-09-29 18:13:23.057-04	2025-09-29 18:13:23.079736-04	\N	personal	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	654659	\N	public/uploads/qrcode/qrcode_kiu9so6mg5oqg3h.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+13016821634	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T22:13:23.054Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5pddno000001jh3q7j89qc	test1759185072@example.com	\N	Test	User	+15559185072	$2b$10$eCjCR6GIq0qeuB8/F3HHo.nMBYsoR/7iKgBU1dh8H7ZPA92KOpUua	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 18:31:12.998654-04	\N	30	f	t	f	\N	{}	2025-09-29 18:31:12.997-04	2025-09-29 18:31:13.037153-04	\N	personal	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	251962	\N	public/uploads/qrcode/qrcode_kiu91w01mg5pddo9.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15559185072	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T22:31:12.996Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5c4nom0000mdjhcai1fmre	unified.test@monay.com	\N	Unified	Test	+15551234567	$2b$10$hsSTFx1cHhG/tTodRI7A2OsKXfvullOCokGgIH4Sg5s8ezdH/6Aha	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 12:20:31.081143-04	\N	30	t	t	f	\N	{}	2025-09-29 12:20:31.079-04	2025-09-29 18:19:29.146062-04	\N	basic_consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	375650	\N	public/uploads/qrcode/qrcode_kiu9imdmg5c4np7.png	\N	\N	\N	\N	\N	\N	\N	mobile	t	t	t	+15551234567	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T16:20:31.078Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
individual-328036f6-239f-444c-afb5-c80c064e4463	healthcare_1759360474730@test.com	\N	Healthcare	Corp 1759360474730	5551574195	$2b$10$eMmpensOlR2bz5qqx49U3eOaVWy7XCji7M4OSDsusFky/Qmoev0Hy	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 19:14:39.967889-04	\N	30	f	t	f	\N	{}	2025-10-01 19:14:39.967889-04	2025-10-01 19:14:50.460042-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5551574195	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
cmg5pddrb000101jhhifedxu8	consumer1759185072@example.com	\N	Consumer	Test	+15569185072	$2b$10$dWyzXxgGd8jSfEApbQG8vO7V5vGxKGopPIAWOFrOZo9tK.be/5tT.	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 18:31:13.128432-04	\N	30	f	t	f	\N	{}	2025-09-29 18:31:13.127-04	2025-09-29 18:31:13.135855-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	146174	\N	public/uploads/qrcode/qrcode_kiu91w01mg5pddrf.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15569185072	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T22:31:13.127Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5pddtu000301jhgeng758s	business1759185072@example.com	\N	Business	Owner	+15579185072	$2b$10$kXSuFU8j837u1exOAMwlVelJj0vUKYD.H8meUp1y8DJoJtz80KnQK	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 18:31:13.2191-04	\N	30	f	t	f	\N	{}	2025-09-29 18:31:13.218-04	2025-09-29 18:31:13.225078-04	\N	small_business	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	436236	\N	public/uploads/qrcode/qrcode_kiu91w01mg5pddtx.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15579185072	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T22:31:13.218Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5vkur70000hqjh38wvdo4p	ali+10@saberi.us	\N	Zaki 	Saberi	+19999999998	$2b$10$MY8c1cKh2eRgKZHFZsBCgOLvUxYyo4GoDIipZomsk6nF6TeW5IVtC	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 21:24:59.448873-04	\N	30	t	t	f	\N	{}	2025-09-29 21:24:59.445-04	2025-09-29 21:28:49.547985-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	608689	\N	public/uploads/qrcode/qrcode_kiu91chqmg5vkuru.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	t	t	+19999999998	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T01:24:59.443Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5u20800000frjhe9ajgv7y	newtest888@example.com	\N	Jane	Smith	+15551234888	$2b$10$e3E/2kOfsrCj1Y3UA0ehme7cEKCA5/E2dJlzQLuIUebX9E6inGfUG	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 20:42:20.450881-04	\N	30	f	t	f	\N	{}	2025-09-29 20:42:20.448-04	2025-09-29 20:42:20.485498-04	\N	personal	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	443607	\N	public/uploads/qrcode/qrcode_kiu9qfrmg5u208h.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15551234888	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T00:42:20.448Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5u611k0001frjh7sby5f01	john.doe.1759193124464@example.com	\N	John	Doe	+15551481482	$2b$10$hOCO4LRu3NYZPm6K19g6Vu6p88VCufj9SRdDioac9gmD8jryC1num	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 20:45:28.139225-04	\N	30	f	t	f	\N	{}	2025-09-29 20:45:28.137-04	2025-09-29 20:45:28.165214-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	804910	\N	public/uploads/qrcode/qrcode_kiu9qfrmg5u6123.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15551481482	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T00:45:28.136Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5uevq10000udjh9tpfebmb	ali+7@saberi.us	\N	Zaki	Saberi	+1234567895	$2b$10$sTMOfvNb/d0149VJJKh1nePvjozhu6sAc9nGP9Vz/UX7V5firr4p2	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 20:52:21.151361-04	\N	30	f	t	f	\N	{}	2025-09-29 20:52:21.147-04	2025-09-29 20:52:21.184708-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	128572	\N	public/uploads/qrcode/qrcode_kiu9uudmg5uevqm.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+1234567895	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T00:52:21.145Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5urqtj0000s1jh7faz66wg	jane.smith.1759194134456@example.com	\N	Jane	Smith	+15554846925	$2b$10$Trli6XmpH5a0rjRvWeIZvueyhg0Qidbd1Yvu2J65j8c2Y9vQFJVfu	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 21:02:21.323727-04	\N	30	f	t	f	\N	{}	2025-09-29 21:02:21.321-04	2025-09-29 21:02:21.363411-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	401671	\N	public/uploads/qrcode/qrcode_kiu910s1mg5urqub.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15554846925	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T01:02:21.319Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5vbs260000hajhhjz2a0dc	user.test.2025@example.com	\N	Ali	Saberi	+15551234999	$2b$10$2Kz2lFII8xqLOXMi8zL.lu0ckYeAGL3JUslYn9Z6b1zMhGWTRtAEG	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 21:17:56.050609-04	\N	30	t	t	t	\N	{}	2025-09-29 21:17:56.048-04	2025-09-30 22:28:26.363408-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	400277	\N	public/uploads/qrcode/qrcode_kiu919hamg5vbs4w.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+15551234999	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-30T01:17:56.047Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg5qnnd50000bnjh1dj73vxg	ali+4@saberi.us	\N	Ali	Saberi	+1234567896	$2b$10$PZS2qjSz8gwkMIvtZe89ie62G4Zb0G0GYpjGGzG3XUlOtH60z1VBm	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-29 19:07:11.758736-04	\N	30	t	t	f	\N	{}	2025-09-29 19:07:11.755-04	2025-09-29 21:22:36.997904-04	\N	consumer	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	918277	\N	public/uploads/qrcode/qrcode_kiu98bnmg5qnndy.png	\N	\N	\N	\N	\N	\N	\N	mobile	f	f	t	+1234567896	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email", "whatsapp"], "transactions": ["mobile", "email", "whatsapp"]}	{"lastUpdated": "2025-09-29T23:07:11.753Z", "preferredChannel": "sms", "alternativeChannels": ["whatsapp"], "verificationRequired": ["mobile"]}	basic_consumer	f	\N
cmg62s3uc0000rsjhakg7fvc3	ali+17@tilli.pro	\N	Ali	Saberi	+19923459999	$2b$10$p9gpbhNIIe5TESwVXExxpuNCVxvSEDo8cTQf1osfki1ne8Fqqt5gi	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-30 00:46:35.134463-04	\N	30	f	t	f	\N	{}	2025-09-30 00:46:35.128-04	2025-09-30 00:46:35.202186-04	\N	enterprise	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	477440	\N	public/uploads/qrcode/qrcode_kiu9grsmg62s3w1.png	\N	\N	\N	\N	\N	\N	\N	email	f	f	t	+19923459999	{"auth": ["email", "mobile"], "urgent": ["email", "mobile"], "updates": ["email"], "marketing": ["email"], "transactions": ["email"]}	{"lastUpdated": "2025-09-30T04:46:35.125Z", "preferredChannel": "email", "alternativeChannels": ["whatsapp"], "verificationRequired": ["email"]}	basic_consumer	f	\N
individual-c2841e36-b242-4763-8d8d-84f21fee145a	healthcare_1759339430312@test.com	\N	Healthcare	Corp 1759339430312	5551428716	$2b$10$tfCn5D1IvNtKQSEkevuvEe4RcFJNQ7WMYgbFIxppXGS78OCW2JgqS	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 13:24:03.301034-04	\N	30	f	t	f	\N	{}	2025-10-01 13:24:03.301034-04	2025-10-01 13:24:03.301034-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5551428716	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
enterprise-62cede32-e4af-4e06-8b82-8665bf396479	ali+1@t-mobile.com	\N	T-Mobile	Admin	+13307011235	$2b$10$omIgUDBSHInO5MEvZrcdMuso3ifmwDxqkd6oB0/9tvOjgp6lhzLKu	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-30 21:07:57.86619-04	\N	30	f	t	f	\N	{}	2025-09-30 21:07:57.86619-04	2025-09-30 23:31:24.898128-04	\N	enterprise	83b1ac7a-71f7-40d3-9dcf-3fcdcb45c08d	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	+13307011235	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-88cd7d83-8bb6-4f97-ab45-8ae0a0a9b34f	healthcare_1759346953258@test.com	\N	Healthcare	Corp 1759346953258	5559056574	$2b$10$tjgEoP29e5j2cM3myTTvg.aAFVINJA3q68.UZzxjxI3vnjaeUjvwC	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 15:29:18.581568-04	\N	30	f	t	f	\N	{}	2025-10-01 15:29:18.581568-04	2025-10-01 15:29:18.581568-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5559056574	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-33eadcdd-82e6-4091-80d1-492cf42a209a	healthcare_1759347622682@test.com	\N	Healthcare	Corp 1759347622682	5554397758	$2b$10$WUbWVY0Il00NDQF5q1hyG.lAoHenshwaQvPQlc7Y3Abdnu81WmIHu	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 15:40:27.937999-04	\N	30	f	t	f	\N	{}	2025-10-01 15:40:27.937999-04	2025-10-01 15:40:27.937999-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5554397758	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
enterprise-a69956ea-a23c-4e0b-bc5b-5c4547b9511e	ali@walmart.com	\N	Walmart	Admin	+13307018866	$2b$10$la4WTR7qAjryqbc01cKM5uoYtOaeCoGGU5rnvjqz3IEIRk0CJcSHm	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 01:31:57.907899-04	\N	30	t	t	f	\N	{}	2025-10-01 01:31:57.907899-04	2025-10-01 01:32:29.336612-04	\N	enterprise	c0e60bb3-74fc-4559-b7e3-974131b5fd09	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	+13307018866	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
enterprise-2c354613-9e2f-414b-bea5-183646d253a9	ali@sysco.com	\N	Sysco	Admin	+13307018877	$2b$10$3o3v7eOv7czVKw.xqPFcievZuosqjhN4B5MwsduBtjq66Ja2tIeVq	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-30 23:20:10.956778-04	\N	30	f	t	f	\N	{}	2025-09-30 23:20:10.956778-04	2025-10-01 02:04:30.028672-04	\N	enterprise	e2f00e12-a8ff-45df-8ad8-4308182f4f7b	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	public/uploads/qrcode/qrcode_kiu9og6mg7hdskx.png	\N	\N	\N	\N	\N	\N	+13307018877	mobile	f	f	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	enterprise_admin	f	skipped
individual-ef768a41-728e-4b7a-80cf-56b745341df1	healthcare_1759348496283@test.com	\N	Healthcare	Corp 1759348496283	5553042027	$2b$10$ZxccOFpH3b.XCoqRuLB0KeJ62UnHz3sp8XtOqdXlapfft3S/5P9q.	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 15:55:01.52458-04	\N	30	f	t	f	\N	{}	2025-10-01 15:55:01.52458-04	2025-10-01 15:55:12.052107-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5553042027	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-7b735c61-fe78-4b1f-8af6-5360ff09deb1	healthcare_1759339027958@test.com	\N	Healthcare	Corp 1759339027958	5552559074	$2b$10$alWtjhSxZF/yG2KaQHWDF.iRiXysN/rZsAbdZKM4XGj6eeTvKnKgy	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 13:17:20.865182-04	\N	30	f	t	f	\N	{}	2025-10-01 13:17:20.865182-04	2025-10-01 13:17:20.865182-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5552559074	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-f63c93a8-1277-4476-98c0-46dea83198f5	healthcare_1759359763822@test.com	\N	Healthcare	Corp 1759359763822	5551950653	$2b$10$ZFP8Zjymzid7BlzV/tmS6uFzhX4Z.oBms1pHiK5PMWIgepqE8FQLW	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 19:02:49.082681-04	\N	30	f	t	f	\N	{}	2025-10-01 19:02:49.082681-04	2025-10-01 19:02:59.577195-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5551950653	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-89657414-6f28-41b4-bff4-693d93d067fd	healthcare_1759359919511@test.com	\N	Healthcare	Corp 1759359919511	5558088872	$2b$10$v8xWreocQLzrLslwj8MdaOmqcMifgiET7R3d23oo7B/YvH0wYnjnu	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 19:05:24.733833-04	\N	30	f	t	f	\N	{}	2025-10-01 19:05:24.733833-04	2025-10-01 19:05:35.205499-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5558088872	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-c5246706-e142-43c2-b8d1-b3c3e03fe2c7	healthcare_1759360397470@test.com	\N	Healthcare	Corp 1759360397470	5557462406	$2b$10$C/HjhTC2U6hKdQqjun9nFulI5i4.49g37h.LIxz7YWa89MFdZtqF2	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 19:13:22.691536-04	\N	30	f	t	f	\N	{}	2025-10-01 19:13:22.691536-04	2025-10-01 19:13:33.16955-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5557462406	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
individual-dd48f73e-a7f9-4907-ba90-0f233a794133	healthcare_1759360542136@test.com	\N	Healthcare	Corp 1759360542136	5556852180	$2b$10$26D6pQhux5on5gtjKnQUsu55JWXSalyFpZCi5GrEX3KkWmgX.xokK	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-10-01 19:15:47.366654-04	\N	30	f	t	f	\N	{}	2025-10-01 19:15:47.366654-04	2025-10-02 10:11:05.814503-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5556852180	mobile	f	t	f	\N	{"auth": ["mobile"], "urgent": ["mobile", "whatsapp"], "updates": ["email", "whatsapp"], "marketing": ["email"], "voice_auth": ["phone"], "transactions": ["email", "whatsapp"]}	{}	\N	f	\N
\.


--
-- Data for Name: users_backup_20250929; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.users_backup_20250929 (id, email, username, first_name, last_name, mobile, password_hash, profile_image, date_of_birth, auth_level, require_mfa, mfa_grace_period_until, biometric_enabled, custody_type, risk_profile, last_risk_assessment, passwordless_enabled, recovery_email, recovery_phone, security_questions, trusted_ips, allowed_countries, blocked_countries, failed_login_attempts, last_failed_login, account_locked_until, password_changed_at, password_history, session_timeout_minutes, mobile_verified, is_active, kyc_verified, kyc_level, metadata, created_at, updated_at, last_login, user_type, primary_organization_id, consumer_kyc_level, consumer_daily_limit, consumer_monthly_limit, preferred_provider, family_group_id, is_primary_user, mpin, wallet_balance, is_deleted, is_blocked, blocked_reason, referral_code, referred_by, qr_code, gender, address, city, state, country, zip_code, phone, primary_contact, phone_verified) FROM stdin;
user-cd06a4f0-b5fd-4c33-b0a2-79a518d62567	test@monay.com	testuser	Test	User	\N	$2a$06$zNOUyI7ox4Q.cxvXx82jrOnHBu7qIBBGdgXdkOiulO7Ks2FEYPgaW	\N	\N	basic	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:01:08.473516-04	\N	30	t	t	f	\N	{}	2025-09-23 08:01:08.473516-04	2025-09-23 08:01:08.473516-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	mobile	f
enterprise-605d2407-08f1-4afc-b911-3b3abb859ba5	enterprise@monay.com	enterprise	Enterprise	Admin	\N	$2a$06$AWmU.2SDQQ9q1p90XdXeGeHgeP.Uv3aLYRUnj8vOOuHGvAaUm2DlS	\N	\N	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-23 08:09:44.670034-04	\N	30	t	t	t	\N	{}	2025-09-23 08:09:44.670034-04	2025-09-23 08:09:44.670034-04	\N	individual	\N	1	1000.000000000000000000	30000.000000000000000000	tempo	\N	t	\N	0	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	mobile	f
admin-88da2d60-98f1-4161-9329-f51e340f8248	admin@monay.com	admin	Admin	Monay	+12025551234	$2a$10$Xl5/PJ/0cY8bzUk7K.Y8HO25mo5ULAow5ScOPSXh/kJRLJVjol60C	https://ui-avatars.com/api/?name=Admin+Monay&background=0D8ABC&color=fff	1990-01-01	high_security	f	\N	f	self	low	\N	f	\N	\N	\N	\N	\N	\N	0	\N	\N	2025-09-28 22:57:55.804411-04	\N	30	t	t	t	\N	{}	2025-09-23 08:02:32.642268-04	2025-09-29 05:15:45.862235-04	2025-09-28 23:20:08.653-04	platform_admin	\N	3	1000000.000000000000000000	10000000.000000000000000000	tempo	\N	t	$2a$10$Th1ZjD.pTdCzzpmC05l3wusCXcD4zjMnR0YsyS3nn2c47fkk3K4by	0	f	f	\N	\N	\N	public/uploads/qrcode/qrcode_kiu91ydhmg4wyf5j.png	\N	\N	\N	\N	\N	\N	\N	mobile	f
\.


--
-- Data for Name: wallet_lifecycle_events; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_lifecycle_events (id, wallet_id, event_type, event_data, blockchain_tx_hash, created_at) FROM stdin;
\.


--
-- Data for Name: wallet_mode_decisions; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallet_mode_decisions (id, wallet_id, decision_type, from_mode, to_mode, confidence_score, factors, created_at) FROM stdin;
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.wallets (id, user_id, organization_id, wallet_name, wallet_type, wallet_address, public_key, blockchain, chain_id, is_smart_wallet, contract_address, balance, locked_balance, kyc_status, aml_verified, sanctions_checked, is_active, is_primary, metadata, created_at, updated_at, provider, type) FROM stdin;
d3a75236-c8ae-45d0-bca9-4c665031831b	\N	266ea6a9-ed0f-4feb-a58b-b5530dfe3f37	Retail Chain International Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
8a28833b-a726-4bc8-a0f5-b6d61fe63bdd	\N	de03686f-4452-4bcb-b4cf-f9fa103d6faa	Manufacturing Dynamics Corp Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
4340eef6-a12c-4504-ac88-033227e53e7d	\N	3a06d6e2-57c9-4455-9481-06ae30fe8f86	Test User Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
f26c4b45-33d5-40cd-a3dd-527f479f0c02	\N	f51ebb46-052f-42bf-952b-9fa2adeb6bf1	Michael Chen Trading Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
45adf1b5-3724-45f3-bd9d-49edde611d9b	\N	8d14163d-71b1-4802-a2a0-c89542e66dc4	Sustainable Energy Co Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
665ad3d5-3ee4-421d-b2dc-7e2705750883	\N	fe6b687d-4c2c-4c8d-ac7f-c1ea7cc35a35	EduTech Learning Platform Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
04cab0c6-6a81-4d03-b57b-ef656fc45fc8	\N	77a7d074-3cfe-47ae-8c40-e4213bac1cfd	Crypto Trading Desk Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
8f9be8a0-3e08-448a-9b70-5039ce89a21b	\N	8d47ded7-56a4-4377-a37e-c8c5e83b1407	The Martinez Family Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
b6750a62-e0d4-4a52-ae1c-a19c11b4dcd1	\N	876e5cc5-cb69-4297-8319-355724c36ca6	John Smith Consulting Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
46c8b021-9457-49d1-aa9e-04a1204ea7da	\N	46354ac8-d63b-48f9-b064-02395138f2ea	Enterprise Admin Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
f0bb4973-a06c-4cf1-9701-a59e29380d67	\N	a2811c4f-584a-4948-970f-708d22388314	Tilli Software Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
daf46c54-f0a5-48d5-92b5-4ae69aa91cb4	\N	57257ead-ee68-41de-8a61-3f2b467543e0	The Kim Family Trust Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
f78f8414-32d7-47df-84cf-57acb1801241	\N	c84ec463-563f-4868-8978-4322fe18f9c0	Creative Design Studio Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
06eba2ad-84a8-4e3e-9197-ae77a2b4a0a6	\N	2be4f049-9a44-4922-b955-964ac500c4f5	TechCorp Solutions Inc Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
6aa3280c-d2a4-47d0-9dc8-a32100454ab8	\N	4d57f359-6c61-454b-b56b-15dec41e0677	Global Finance Partners Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
2ee30242-df83-40b6-b58a-dc069289f2cb	\N	334d4d10-616c-4579-94ea-d5aec541061d	Auto Repair Excellence Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
a5fb0d1b-cc6b-4c86-b57b-3d1f984b1413	\N	148ffafb-1e76-4fef-9b27-1f05b9727ad2	Pet Care Paradise Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
a7b03363-d89c-4376-b2c3-93cc1b1daec6	\N	356aa63a-460f-48e4-9632-711afa22a11c	Microsoft Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
28720b42-d2a2-4421-9624-3594088cb602	\N	27b4c81f-c944-4914-a9c6-4a85acd7f569	Green Lawn Services Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
be67083e-1446-41d6-b094-6c7facef0f48	\N	307c5074-467e-4905-a1c2-25847f83fc99	Diversified Ventures LLC Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
bc1444f6-00de-449c-9559-f0f862b843ec	\N	0cca5c14-6a2c-4854-b8b9-d471e1d525a4	Sarah Johnson Freelance Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
65de5f63-ec65-4e35-b64f-0d75e8ce27b0	\N	4b2e8644-8170-4b15-bc76-0da3ac9c9d3d	Boutique Law Associates Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
a72e81b5-1687-44f4-97b2-e05991abee85	\N	3b6164ad-f10f-4675-ae17-a1476c75a852	Robert Wilson Investments Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
791263f6-9f2e-4269-88a3-7f585925eb84	\N	4d9371eb-6e6d-49f2-a7d0-db8464e17ba3	Digital Marketing Pro Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
29e2aa99-0cb4-4053-a283-8304bc77a1a7	\N	a2617731-ba4e-4a0d-bcbc-03c17ee0d39e	Emily Davis Photography Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
d3e00f3e-f8a5-489f-9d28-ff8ae3196dfa	\N	80806438-a16f-4148-9670-f88a1d2bad7e	Johnson Household Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
5d8fcc2c-e639-4014-8014-57bdf149ea2f	\N	3280987c-8258-4fc2-8b6d-5f4fcf622a9a	Sunrise Bakery & Cafe Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
0d4f59b7-c5cc-4f5d-b05c-52ba5e91e3b1	\N	ae9c9cae-a882-45e8-ad2f-fbbe2df1b4fe	Apex Holdings Group Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
45541bda-bdad-4e23-81ef-bbd47a20319d	\N	cffa7cbe-11b6-4633-81dc-d28d4baf454d	Healthcare Systems United Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
418371d5-9697-4003-84e1-de5dd35afbb1	\N	e5826292-63e4-4592-96ed-9c8dbeee8ea4	Fitness Plus Gym Primary Wallet	consumer	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
aab97edc-1ddf-4695-9929-3c497c3d6c30	\N	445b7b08-02e7-4a00-8efc-fde8cd6ee2d4	Tilli Pro Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:18:59.042112-04	2025-09-30 00:18:59.042112-04	\N	\N
56db22bb-faff-46e7-9198-8359f6e64366	\N	a3dfb40c-27a1-4d1c-8eeb-e5c30e828b02	Test Organization API Primary Wallet	enterprise	\N	\N	base	\N	t	\N	0.000000000000000000	0.000000000000000000	not_started	f	f	t	f	{}	2025-09-30 00:41:39.538012-04	2025-09-30 00:41:39.538012-04	\N	\N
8111b527-425b-4c2a-9037-b2f3f706cef6	cmg5bdspj0000lajh2ypvcdlf	\N	Primary Wallet	consumer	0x742d35Cc6635C0532925a3b8D5c6cd00ad7e4f8f	\N	base	\N	f	\N	2500.000000000000000000	0.000000000000000000	not_started	f	f	t	t	{}	2025-09-30 12:03:54.459133-04	2025-09-30 12:03:54.459133-04	\N	consumer
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.webauthn_credentials (id, user_id, credential_id, public_key, counter, device_type, name, transports, backup_eligible, backup_state, last_used_at, created_at) FROM stdin;
\.


--
-- Data for Name: zk_compliance_proofs; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zk_compliance_proofs (id, wallet_id, proof_type, proof_data, verification_key, is_valid, verified_at, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_automation_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_automation_rules (id, account_id, rule_name, trigger_type, conditions, actions, enabled, priority, last_triggered, execution_count, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_connections; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_connections (id, organization_id, account_id, organization_name, access_token, refresh_token, token_expiry, scope, region, features, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zoho_entities; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_entities (id, account_id, entity_type, entity_id, data, custom_fields, tags, attachments, synced_at, updated_at) FROM stdin;
\.


--
-- Data for Name: zoho_recurring_profiles; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_recurring_profiles (id, account_id, profile_id, profile_type, customer_id, frequency, start_date, end_date, next_invoice_date, total_amount, currency_code, status, line_items, created_at) FROM stdin;
\.


--
-- Data for Name: zoho_sync_history; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_sync_history (id, account_id, entity_type, sync_type, status, records_synced, errors, started_at, completed_at, error_details, metadata) FROM stdin;
\.


--
-- Data for Name: zoho_tax_rules; Type: TABLE DATA; Schema: public; Owner: alisaberi
--

COPY public.zoho_tax_rules (id, account_id, tax_id, tax_name, tax_percentage, tax_type, is_compound, is_inclusive, region_codes, product_categories, exemptions, created_at) FROM stdin;
\.


--
-- Name: countries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.countries_id_seq', 4, true);


--
-- Name: invoice_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_attachments_id_seq', 1, false);


--
-- Name: invoice_batch_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_batch_items_id_seq', 1, false);


--
-- Name: invoice_batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_batches_id_seq', 1, false);


--
-- Name: invoice_payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_payment_methods_id_seq', 1, false);


--
-- Name: invoice_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.invoice_tokens_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.migrations_id_seq', 2, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.notifications_id_seq', 21, true);


--
-- Name: recurring_invoice_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.recurring_invoice_templates_id_seq', 1, false);


--
-- Name: sage_bank_reconciliations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_bank_reconciliations_id_seq', 1, false);


--
-- Name: sage_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_connections_id_seq', 1, false);


--
-- Name: sage_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_entities_id_seq', 1, false);


--
-- Name: sage_journal_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_journal_entries_id_seq', 1, false);


--
-- Name: sage_ledger_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_ledger_accounts_id_seq', 1, false);


--
-- Name: sage_sync_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_sync_queue_id_seq', 1, false);


--
-- Name: sage_tax_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.sage_tax_returns_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.settings_id_seq', 5, true);


--
-- Name: zoho_automation_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_automation_rules_id_seq', 1, false);


--
-- Name: zoho_connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_connections_id_seq', 1, false);


--
-- Name: zoho_entities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_entities_id_seq', 1, false);


--
-- Name: zoho_recurring_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_recurring_profiles_id_seq', 1, false);


--
-- Name: zoho_sync_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_sync_history_id_seq', 1, false);


--
-- Name: zoho_tax_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alisaberi
--

SELECT pg_catalog.setval('public.zoho_tax_rules_id_seq', 1, false);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: ai_financial_insights ai_financial_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ai_financial_insights
    ADD CONSTRAINT ai_financial_insights_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_log auth_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_pkey PRIMARY KEY (id);


--
-- Name: auth_challenges auth_challenges_user_key_challenge_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_challenges
    ADD CONSTRAINT auth_challenges_user_key_challenge_type_key UNIQUE (user_key, challenge_type);


--
-- Name: auth_risk_analysis auth_risk_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: auth_sessions auth_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_session_token_key UNIQUE (session_token);


--
-- Name: auto_topup_rules auto_topup_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_pkey PRIMARY KEY (id);


--
-- Name: batch_transfer_recipients batch_transfer_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.batch_transfer_recipients
    ADD CONSTRAINT batch_transfer_recipients_pkey PRIMARY KEY (id);


--
-- Name: batch_transfers batch_transfers_batch_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.batch_transfers
    ADD CONSTRAINT batch_transfers_batch_id_key UNIQUE (batch_id);


--
-- Name: batch_transfers batch_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.batch_transfers
    ADD CONSTRAINT batch_transfers_pkey PRIMARY KEY (id);


--
-- Name: bill_payments bill_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_pkey PRIMARY KEY (id);


--
-- Name: billing_metrics billing_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.billing_metrics
    ADD CONSTRAINT billing_metrics_pkey PRIMARY KEY (id);


--
-- Name: billing_metrics billing_metrics_tenant_id_period_start_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.billing_metrics
    ADD CONSTRAINT billing_metrics_tenant_id_period_start_key UNIQUE (tenant_id, period_start);


--
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_pkey PRIMARY KEY (id);


--
-- Name: blockchain_transactions blockchain_transactions_transaction_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_transaction_hash_key UNIQUE (transaction_hash);


--
-- Name: blockchain_wallets blockchain_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_pkey PRIMARY KEY (id);


--
-- Name: blockchain_wallets blockchain_wallets_user_id_address_wallet_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_user_id_address_wallet_type_key UNIQUE (user_id, address, wallet_type);


--
-- Name: bridge_swaps bridge_swaps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_pkey PRIMARY KEY (id);


--
-- Name: bridge_swaps bridge_swaps_swap_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_swap_id_key UNIQUE (swap_id);


--
-- Name: business_rules business_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.business_rules
    ADD CONSTRAINT business_rules_pkey PRIMARY KEY (id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (id);


--
-- Name: charity_donations charity_donations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_pkey PRIMARY KEY (id);


--
-- Name: charity_organizations charity_organizations_ein_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_organizations
    ADD CONSTRAINT charity_organizations_ein_key UNIQUE (ein);


--
-- Name: charity_organizations charity_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_organizations
    ADD CONSTRAINT charity_organizations_pkey PRIMARY KEY (id);


--
-- Name: child_parents child_parents_parent_id_child_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_parent_id_child_id_key UNIQUE (parent_id, child_id);


--
-- Name: child_parents child_parents_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_pkey PRIMARY KEY (id);


--
-- Name: compliance_checks compliance_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_pkey PRIMARY KEY (id);


--
-- Name: consumer_preferences consumer_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_preferences
    ADD CONSTRAINT consumer_preferences_pkey PRIMARY KEY (id);


--
-- Name: consumer_preferences consumer_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_preferences
    ADD CONSTRAINT consumer_preferences_user_id_key UNIQUE (user_id);


--
-- Name: consumer_rewards consumer_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_rewards
    ADD CONSTRAINT consumer_rewards_pkey PRIMARY KEY (id);


--
-- Name: consumer_subscriptions consumer_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_subscriptions
    ADD CONSTRAINT consumer_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: consumer_virtual_cards consumer_virtual_cards_card_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_virtual_cards
    ADD CONSTRAINT consumer_virtual_cards_card_id_key UNIQUE (card_id);


--
-- Name: consumer_virtual_cards consumer_virtual_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_virtual_cards
    ADD CONSTRAINT consumer_virtual_cards_pkey PRIMARY KEY (id);


--
-- Name: contract_interactions contract_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_pkey PRIMARY KEY (id);


--
-- Name: countries countries_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.countries
    ADD CONSTRAINT countries_pkey PRIMARY KEY (id);


--
-- Name: custody_configurations custody_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_pkey PRIMARY KEY (id);


--
-- Name: custody_configurations custody_configurations_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_user_id_key UNIQUE (user_id);


--
-- Name: customer_credits customer_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_pkey PRIMARY KEY (id);


--
-- Name: enterprise_ramps enterprise_ramps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_ramps
    ADD CONSTRAINT enterprise_ramps_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries enterprise_treasuries_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries enterprise_treasuries_solana_tree_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_solana_tree_address_key UNIQUE (solana_tree_address);


--
-- Name: gift_cards gift_cards_code_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_code_key UNIQUE (code);


--
-- Name: gift_cards gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_pkey PRIMARY KEY (id);


--
-- Name: invoice_attachments invoice_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments
    ADD CONSTRAINT invoice_attachments_pkey PRIMARY KEY (id);


--
-- Name: invoice_batch_items invoice_batch_items_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_batches invoice_batches_batch_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_batch_id_key UNIQUE (batch_id);


--
-- Name: invoice_batches invoice_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_pkey PRIMARY KEY (id);


--
-- Name: invoice_events invoice_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_pkey PRIMARY KEY (id);


--
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- Name: invoice_payment_methods invoice_payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods
    ADD CONSTRAINT invoice_payment_methods_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoice_templates invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: invoice_tokens invoice_tokens_invoice_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_invoice_id_key UNIQUE (invoice_id);


--
-- Name: invoice_tokens invoice_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_pkey PRIMARY KEY (id);


--
-- Name: invoice_wallets invoice_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_solana_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_solana_address_key UNIQUE (solana_address);


--
-- Name: kyc_sessions kyc_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.kyc_sessions
    ADD CONSTRAINT kyc_sessions_pkey PRIMARY KEY (id);


--
-- Name: loyalty_rewards loyalty_rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_rewards
    ADD CONSTRAINT loyalty_rewards_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_token_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_token_key UNIQUE (token);


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: multi_sig_transactions multi_sig_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_pkey PRIMARY KEY (id);


--
-- Name: multi_sig_wallets multi_sig_wallets_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_chain_address_key UNIQUE (chain, address);


--
-- Name: multi_sig_wallets multi_sig_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: organization_users organization_users_organization_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_user_id_key UNIQUE (organization_id, user_id);


--
-- Name: organization_users organization_users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_org_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_org_id_key UNIQUE (org_id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: p2p_transfers p2p_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.p2p_transfers
    ADD CONSTRAINT p2p_transfers_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_pkey PRIMARY KEY (id);


--
-- Name: payment_requests payment_requests_solana_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_solana_address_key UNIQUE (solana_address);


--
-- Name: price_feeds price_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.price_feeds
    ADD CONSTRAINT price_feeds_pkey PRIMARY KEY (id);


--
-- Name: quantum_key_registry quantum_key_registry_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_key_hash_key UNIQUE (key_hash);


--
-- Name: quantum_key_registry quantum_key_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_pkey PRIMARY KEY (id);


--
-- Name: ready_cash_loans ready_cash_loans_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ready_cash_loans
    ADD CONSTRAINT ready_cash_loans_pkey PRIMARY KEY (id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_pkey PRIMARY KEY (id);


--
-- Name: sage_bank_reconciliations sage_bank_reconciliations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations
    ADD CONSTRAINT sage_bank_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: sage_connections sage_connections_account_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections
    ADD CONSTRAINT sage_connections_account_id_key UNIQUE (account_id);


--
-- Name: sage_connections sage_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_connections
    ADD CONSTRAINT sage_connections_pkey PRIMARY KEY (id);


--
-- Name: sage_entities sage_entities_account_id_entity_type_sage_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_account_id_entity_type_sage_id_key UNIQUE (account_id, entity_type, sage_id);


--
-- Name: sage_entities sage_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_pkey PRIMARY KEY (id);


--
-- Name: sage_journal_entries sage_journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries
    ADD CONSTRAINT sage_journal_entries_pkey PRIMARY KEY (id);


--
-- Name: sage_ledger_accounts sage_ledger_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts
    ADD CONSTRAINT sage_ledger_accounts_pkey PRIMARY KEY (id);


--
-- Name: sage_sync_queue sage_sync_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue
    ADD CONSTRAINT sage_sync_queue_pkey PRIMARY KEY (id);


--
-- Name: sage_tax_returns sage_tax_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns
    ADD CONSTRAINT sage_tax_returns_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: smart_contracts smart_contracts_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_chain_address_key UNIQUE (chain, address);


--
-- Name: smart_contracts smart_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_pkey PRIMARY KEY (id);


--
-- Name: spending_limit_history spending_limit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limit_history
    ADD CONSTRAINT spending_limit_history_pkey PRIMARY KEY (id);


--
-- Name: spending_limit_overrides spending_limit_overrides_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limit_overrides
    ADD CONSTRAINT spending_limit_overrides_pkey PRIMARY KEY (id);


--
-- Name: spending_limit_violations spending_limit_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limit_violations
    ADD CONSTRAINT spending_limit_violations_pkey PRIMARY KEY (id);


--
-- Name: spending_limits spending_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limits
    ADD CONSTRAINT spending_limits_pkey PRIMARY KEY (id);


--
-- Name: split_bill_participants split_bill_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_pkey PRIMARY KEY (id);


--
-- Name: split_bills split_bills_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bills
    ADD CONSTRAINT split_bills_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- Name: sso_providers sso_providers_provider_name_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sso_providers
    ADD CONSTRAINT sso_providers_provider_name_key UNIQUE (provider_name);


--
-- Name: stablecoin_balances stablecoin_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.stablecoin_balances
    ADD CONSTRAINT stablecoin_balances_pkey PRIMARY KEY (id);


--
-- Name: stablecoin_balances stablecoin_balances_user_id_currency_provider_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.stablecoin_balances
    ADD CONSTRAINT stablecoin_balances_user_id_currency_provider_key UNIQUE (user_id, currency, provider);


--
-- Name: super_app_bookings super_app_bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.super_app_bookings
    ADD CONSTRAINT super_app_bookings_pkey PRIMARY KEY (id);


--
-- Name: tenant_audit_logs tenant_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: tenant_billing tenant_billing_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_billing
    ADD CONSTRAINT tenant_billing_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_tenant_id_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_setting_key_key UNIQUE (tenant_id, setting_key);


--
-- Name: tenant_transactions tenant_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_pkey PRIMARY KEY (id);


--
-- Name: tenant_users tenant_users_tenant_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_tenant_id_user_id_key UNIQUE (tenant_id, user_id);


--
-- Name: tenant_vault_keys tenant_vault_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_vault_keys
    ADD CONSTRAINT tenant_vault_keys_pkey PRIMARY KEY (id);


--
-- Name: tenant_wallets tenant_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_tenant_code_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_tenant_code_key UNIQUE (tenant_code);


--
-- Name: tillipay_cards tillipay_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_pkey PRIMARY KEY (id);


--
-- Name: tillipay_cards tillipay_cards_tillipay_card_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_tillipay_card_id_key UNIQUE (tillipay_card_id);


--
-- Name: tillipay_transactions tillipay_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_pkey PRIMARY KEY (id);


--
-- Name: tillipay_transactions tillipay_transactions_tillipay_tx_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_tillipay_tx_id_key UNIQUE (tillipay_tx_id);


--
-- Name: tokens tokens_chain_contract_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_chain_contract_address_key UNIQUE (chain, contract_address);


--
-- Name: tokens tokens_chain_mint_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_chain_mint_address_key UNIQUE (chain, mint_address);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: treasury_accounts treasury_accounts_enterprise_id_chain_address_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_enterprise_id_chain_address_key UNIQUE (enterprise_id, chain, address);


--
-- Name: treasury_accounts treasury_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_pkey PRIMARY KEY (id);


--
-- Name: treasury_swaps treasury_swaps_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_swaps
    ADD CONSTRAINT treasury_swaps_pkey PRIMARY KEY (id);


--
-- Name: treasury_transactions treasury_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_pkey PRIMARY KEY (id);


--
-- Name: enterprise_treasuries uniq_organization_treasury; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT uniq_organization_treasury UNIQUE (organization_id);


--
-- Name: spending_limits unique_entity_limit; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limits
    ADD CONSTRAINT unique_entity_limit UNIQUE (entity_type, entity_id, limit_type);


--
-- Name: user_biometrics user_biometrics_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_pkey PRIMARY KEY (id);


--
-- Name: user_biometrics user_biometrics_user_id_device_id_biometric_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_user_id_device_id_biometric_type_key UNIQUE (user_id, device_id, biometric_type);


--
-- Name: user_devices_enhanced user_devices_enhanced_device_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_device_id_key UNIQUE (device_id);


--
-- Name: user_devices_enhanced user_devices_enhanced_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_settings user_mfa_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_settings user_mfa_settings_user_id_mfa_type_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_user_id_mfa_type_key UNIQUE (user_id, mfa_type);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_key UNIQUE (user_id);


--
-- Name: user_sso_connections user_sso_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_pkey PRIMARY KEY (id);


--
-- Name: user_sso_connections user_sso_connections_provider_id_external_user_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_external_user_id_key UNIQUE (provider_id, external_user_id);


--
-- Name: user_tokens user_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_pkey PRIMARY KEY (id);


--
-- Name: wallet_mode_decisions wallet_mode_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_mode_decisions
    ADD CONSTRAINT wallet_mode_decisions_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: zk_compliance_proofs zk_compliance_proofs_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_pkey PRIMARY KEY (id);


--
-- Name: zoho_automation_rules zoho_automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules
    ADD CONSTRAINT zoho_automation_rules_pkey PRIMARY KEY (id);


--
-- Name: zoho_connections zoho_connections_account_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections
    ADD CONSTRAINT zoho_connections_account_id_key UNIQUE (account_id);


--
-- Name: zoho_connections zoho_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_connections
    ADD CONSTRAINT zoho_connections_pkey PRIMARY KEY (id);


--
-- Name: zoho_entities zoho_entities_account_id_entity_type_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_account_id_entity_type_entity_id_key UNIQUE (account_id, entity_type, entity_id);


--
-- Name: zoho_entities zoho_entities_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_pkey PRIMARY KEY (id);


--
-- Name: zoho_recurring_profiles zoho_recurring_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles
    ADD CONSTRAINT zoho_recurring_profiles_pkey PRIMARY KEY (id);


--
-- Name: zoho_sync_history zoho_sync_history_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history
    ADD CONSTRAINT zoho_sync_history_pkey PRIMARY KEY (id);


--
-- Name: zoho_tax_rules zoho_tax_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules
    ADD CONSTRAINT zoho_tax_rules_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_insights_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_ai_insights_type ON public.ai_financial_insights USING btree (insight_type);


--
-- Name: idx_ai_insights_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_ai_insights_user ON public.ai_financial_insights USING btree (user_id);


--
-- Name: idx_api_keys_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_active ON public.api_keys USING btree (is_active, expires_at);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_api_keys_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_audit_logs_actor; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_actor ON public.audit_logs USING btree (actor_id);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_audit_logs_timestamp ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_auth_audit_event; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_event ON public.auth_audit_log USING btree (event_type);


--
-- Name: idx_auth_audit_success; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_success ON public.auth_audit_log USING btree (success, created_at DESC);


--
-- Name: idx_auth_audit_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_timestamp ON public.auth_audit_log USING btree (created_at DESC);


--
-- Name: idx_auth_audit_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_audit_user ON public.auth_audit_log USING btree (user_id);


--
-- Name: idx_auth_challenges_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_challenges_expires ON public.auth_challenges USING btree (expires_at);


--
-- Name: idx_auth_challenges_user_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_challenges_user_type ON public.auth_challenges USING btree (user_key, challenge_type);


--
-- Name: idx_auth_sessions_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_active ON public.auth_sessions USING btree (is_active, expires_at);


--
-- Name: idx_auth_sessions_refresh; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_refresh ON public.auth_sessions USING btree (refresh_token);


--
-- Name: idx_auth_sessions_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_token ON public.auth_sessions USING btree (session_token);


--
-- Name: idx_auth_sessions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auth_sessions_user ON public.auth_sessions USING btree (user_id);


--
-- Name: idx_auto_topup_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auto_topup_user ON public.auto_topup_rules USING btree (user_id);


--
-- Name: idx_auto_topup_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_auto_topup_wallet ON public.auto_topup_rules USING btree (wallet_id);


--
-- Name: idx_batch_transfer_recipients_batch; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_batch_transfer_recipients_batch ON public.batch_transfer_recipients USING btree (batch_id);


--
-- Name: idx_batch_transfers_sender; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_batch_transfers_sender ON public.batch_transfers USING btree (sender_id);


--
-- Name: idx_bill_payments_bill; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bill_payments_bill ON public.bill_payments USING btree (bill_id);


--
-- Name: idx_bill_payments_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bill_payments_user ON public.bill_payments USING btree (user_id);


--
-- Name: idx_billing_metrics_period; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_billing_metrics_period ON public.billing_metrics USING btree (period_start, period_end);


--
-- Name: idx_billing_metrics_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_billing_metrics_tenant_id ON public.billing_metrics USING btree (tenant_id);


--
-- Name: idx_bills_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bills_due_date ON public.bills USING btree (due_date);


--
-- Name: idx_bills_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bills_user ON public.bills USING btree (user_id);


--
-- Name: idx_blockchain_tx_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_hash ON public.blockchain_transactions USING btree (transaction_hash);


--
-- Name: idx_blockchain_tx_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_user ON public.blockchain_transactions USING btree (user_id);


--
-- Name: idx_blockchain_tx_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_tx_wallet ON public.blockchain_transactions USING btree (wallet_id);


--
-- Name: idx_blockchain_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_wallets_address ON public.blockchain_wallets USING btree (address);


--
-- Name: idx_blockchain_wallets_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_blockchain_wallets_user ON public.blockchain_wallets USING btree (user_id);


--
-- Name: idx_bookings_service_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_service_date ON public.super_app_bookings USING btree (service_date);


--
-- Name: idx_bookings_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_type ON public.super_app_bookings USING btree (booking_type);


--
-- Name: idx_bookings_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bookings_user ON public.super_app_bookings USING btree (user_id);


--
-- Name: idx_bridge_swaps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bridge_swaps_status ON public.bridge_swaps USING btree (status);


--
-- Name: idx_bridge_swaps_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_bridge_swaps_user ON public.bridge_swaps USING btree (user_id);


--
-- Name: idx_business_rules_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_business_rules_entity ON public.business_rules USING btree (entity_type, entity_id);


--
-- Name: idx_business_rules_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_business_rules_type ON public.business_rules USING btree (rule_type);


--
-- Name: idx_businesses_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_businesses_org ON public.businesses USING btree (organization_id);


--
-- Name: idx_cash_loans_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_cash_loans_status ON public.ready_cash_loans USING btree (status);


--
-- Name: idx_cash_loans_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_cash_loans_user ON public.ready_cash_loans USING btree (user_id);


--
-- Name: idx_charity_orgs_category; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_charity_orgs_category ON public.charity_organizations USING btree (category);


--
-- Name: idx_child_parents_child; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_child_parents_child ON public.child_parents USING btree (child_id);


--
-- Name: idx_child_parents_parent; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_child_parents_parent ON public.child_parents USING btree (parent_id);


--
-- Name: idx_compliance_checks_tx; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_checks_tx ON public.compliance_checks USING btree (transaction_id);


--
-- Name: idx_compliance_checks_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_compliance_checks_user ON public.compliance_checks USING btree (user_id);


--
-- Name: idx_consumer_rewards_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_consumer_rewards_user ON public.consumer_rewards USING btree (user_id);


--
-- Name: idx_consumer_subscriptions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_consumer_subscriptions_user ON public.consumer_subscriptions USING btree (user_id);


--
-- Name: idx_consumer_virtual_cards_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_consumer_virtual_cards_user ON public.consumer_virtual_cards USING btree (user_id);


--
-- Name: idx_contract_interactions_contract; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_contract_interactions_contract ON public.contract_interactions USING btree (contract_id);


--
-- Name: idx_contract_interactions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_contract_interactions_user ON public.contract_interactions USING btree (user_id);


--
-- Name: idx_custody_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custody_type ON public.custody_configurations USING btree (custody_type);


--
-- Name: idx_custody_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_custody_user ON public.custody_configurations USING btree (user_id);


--
-- Name: idx_customer_credits_customer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_customer ON public.customer_credits USING btree (customer_id);


--
-- Name: idx_customer_credits_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_organization ON public.customer_credits USING btree (organization_id);


--
-- Name: idx_customer_credits_source; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_source ON public.customer_credits USING btree (source_invoice_id);


--
-- Name: idx_customer_credits_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_customer_credits_status ON public.customer_credits USING btree (status);


--
-- Name: idx_donations_charity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_donations_charity ON public.charity_donations USING btree (charity_id);


--
-- Name: idx_donations_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_donations_user ON public.charity_donations USING btree (user_id);


--
-- Name: idx_enterprise_ramps_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_created ON public.enterprise_ramps USING btree (created_at);


--
-- Name: idx_enterprise_ramps_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_organization ON public.enterprise_ramps USING btree (organization_id);


--
-- Name: idx_enterprise_ramps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_status ON public.enterprise_ramps USING btree (status);


--
-- Name: idx_enterprise_ramps_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_ramps_type ON public.enterprise_ramps USING btree (type);


--
-- Name: idx_enterprise_treasuries_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_treasuries_organization ON public.enterprise_treasuries USING btree (organization_id);


--
-- Name: idx_enterprise_treasuries_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_enterprise_treasuries_status ON public.enterprise_treasuries USING btree (status);


--
-- Name: idx_gift_cards_code; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_code ON public.gift_cards USING btree (code);


--
-- Name: idx_gift_cards_purchaser; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_purchaser ON public.gift_cards USING btree (purchaser_id);


--
-- Name: idx_gift_cards_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_gift_cards_recipient ON public.gift_cards USING btree (recipient_id);


--
-- Name: idx_invoice_events_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_created ON public.invoice_events USING btree (created_at);


--
-- Name: idx_invoice_events_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_created_at ON public.invoice_events USING btree (created_at);


--
-- Name: idx_invoice_events_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_invoice ON public.invoice_events USING btree (invoice_id);


--
-- Name: idx_invoice_events_invoice_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_invoice_id ON public.invoice_events USING btree (invoice_id);


--
-- Name: idx_invoice_events_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_events_type ON public.invoice_events USING btree (event_type);


--
-- Name: idx_invoice_items_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_items_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_invoice_line_items_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_line_items_invoice ON public.invoice_line_items USING btree (invoice_id);


--
-- Name: idx_invoice_payments_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_created ON public.invoice_payments USING btree (created_at);


--
-- Name: idx_invoice_payments_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_invoice ON public.invoice_payments USING btree (invoice_id);


--
-- Name: idx_invoice_payments_payer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_payer ON public.invoice_payments USING btree (payer_id);


--
-- Name: idx_invoice_payments_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_payments_status ON public.invoice_payments USING btree (status);


--
-- Name: idx_invoice_templates_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_templates_active ON public.invoice_templates USING btree (is_active);


--
-- Name: idx_invoice_templates_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_templates_organization ON public.invoice_templates USING btree (organization_id);


--
-- Name: idx_invoice_tokens_chain; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_chain ON public.invoice_tokens USING btree (chain);


--
-- Name: idx_invoice_tokens_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_created_at ON public.invoice_tokens USING btree (created_at);


--
-- Name: idx_invoice_tokens_description; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_description ON public.invoice_tokens USING gin (to_tsvector('english'::regconfig, description));


--
-- Name: idx_invoice_tokens_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_due_date ON public.invoice_tokens USING btree (due_date);


--
-- Name: idx_invoice_tokens_from_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_from_user ON public.invoice_tokens USING btree (from_user_id);


--
-- Name: idx_invoice_tokens_line_items; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_line_items ON public.invoice_tokens USING gin (line_items);


--
-- Name: idx_invoice_tokens_metadata; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_metadata ON public.invoice_tokens USING gin (metadata);


--
-- Name: idx_invoice_tokens_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_status ON public.invoice_tokens USING btree (status);


--
-- Name: idx_invoice_tokens_to_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_to_user ON public.invoice_tokens USING btree (to_user_id);


--
-- Name: idx_invoice_tokens_token_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_tokens_token_id ON public.invoice_tokens USING btree (token_id);


--
-- Name: idx_invoice_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_address ON public.invoice_wallets USING btree (wallet_address);


--
-- Name: idx_invoice_wallets_invoice; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_invoice ON public.invoice_wallets USING btree (invoice_id);


--
-- Name: idx_invoice_wallets_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoice_wallets_status ON public.invoice_wallets USING btree (status);


--
-- Name: idx_invoices_due_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_due_date ON public.invoices USING btree (due_date);


--
-- Name: idx_invoices_number; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_number ON public.invoices USING btree (invoice_number);


--
-- Name: idx_invoices_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_organization ON public.invoices USING btree (organization_id);


--
-- Name: idx_invoices_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_recipient ON public.invoices USING btree (recipient_id);


--
-- Name: idx_invoices_solana_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_solana_address ON public.invoices USING btree (solana_address);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (status);


--
-- Name: idx_invoices_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_invoices_user ON public.invoices USING btree (user_id);


--
-- Name: idx_kyc_sessions_provider; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_kyc_sessions_provider ON public.kyc_sessions USING btree (provider, session_id);


--
-- Name: idx_kyc_sessions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_kyc_sessions_user ON public.kyc_sessions USING btree (user_id);


--
-- Name: idx_limit_history_changed_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_limit_history_changed_at ON public.spending_limit_history USING btree (changed_at);


--
-- Name: idx_limit_history_spending_limit; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_limit_history_spending_limit ON public.spending_limit_history USING btree (spending_limit_id);


--
-- Name: idx_loyalty_tx_program; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_loyalty_tx_program ON public.loyalty_transactions USING btree (reward_program_id);


--
-- Name: idx_loyalty_tx_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_loyalty_tx_user ON public.loyalty_transactions USING btree (user_id);


--
-- Name: idx_magic_links_expires; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_expires ON public.magic_links USING btree (expires_at);


--
-- Name: idx_magic_links_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_token ON public.magic_links USING btree (token);


--
-- Name: idx_magic_links_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_magic_links_user ON public.magic_links USING btree (user_id);


--
-- Name: idx_mode_decisions_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_mode_decisions_wallet ON public.wallet_mode_decisions USING btree (wallet_id);


--
-- Name: idx_multi_sig_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_multi_sig_enterprise ON public.multi_sig_wallets USING btree (enterprise_id);


--
-- Name: idx_multi_sig_tx_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_multi_sig_tx_wallet ON public.multi_sig_transactions USING btree (wallet_id);


--
-- Name: idx_notifications_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_notifications_created ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_from_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_notifications_from_user ON public.notifications USING btree ("fromUserId");


--
-- Name: idx_notifications_receiver_read; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_notifications_receiver_read ON public.notifications USING btree ("receiverRead");


--
-- Name: idx_notifications_to_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_notifications_to_user ON public.notifications USING btree ("toUserId");


--
-- Name: idx_org_users_org_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_org_id ON public.organization_users USING btree (organization_id);


--
-- Name: idx_org_users_role; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_role ON public.organization_users USING btree (role);


--
-- Name: idx_org_users_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_status ON public.organization_users USING btree (invitation_status);


--
-- Name: idx_org_users_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_org_users_user_id ON public.organization_users USING btree (user_id);


--
-- Name: idx_organizations_feature_tier; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_feature_tier ON public.organizations USING btree (feature_tier);


--
-- Name: idx_organizations_kyc_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_kyc_status ON public.organizations USING btree (kyc_status);


--
-- Name: idx_organizations_parent; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_parent ON public.organizations USING btree (parent_id);


--
-- Name: idx_organizations_path; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_path ON public.organizations USING gin (path_ids);


--
-- Name: idx_organizations_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_status ON public.organizations USING btree (status);


--
-- Name: idx_organizations_tenant; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_tenant ON public.organizations USING btree (tenant_id);


--
-- Name: idx_organizations_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_type ON public.organizations USING btree (org_type);


--
-- Name: idx_organizations_wallet_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_organizations_wallet_type ON public.organizations USING btree (wallet_type);


--
-- Name: idx_p2p_transfers_recipient; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_p2p_transfers_recipient ON public.p2p_transfers USING btree (recipient_id);


--
-- Name: idx_p2p_transfers_sender; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_p2p_transfers_sender ON public.p2p_transfers USING btree (sender_id);


--
-- Name: idx_payment_methods_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_methods_user ON public.payment_methods USING btree (user_id);


--
-- Name: idx_payment_requests_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_created ON public.payment_requests USING btree (created_at);


--
-- Name: idx_payment_requests_payer; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_payer ON public.payment_requests USING btree (payer_id);


--
-- Name: idx_payment_requests_requester; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_requester ON public.payment_requests USING btree (requester_id);


--
-- Name: idx_payment_requests_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_payment_requests_status ON public.payment_requests USING btree (status);


--
-- Name: idx_price_feeds_symbol; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_price_feeds_symbol ON public.price_feeds USING btree (token_symbol, base_currency);


--
-- Name: idx_price_feeds_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_price_feeds_timestamp ON public.price_feeds USING btree ("timestamp" DESC);


--
-- Name: idx_quantum_keys_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_quantum_keys_wallet ON public.quantum_key_registry USING btree (wallet_id);


--
-- Name: idx_recurring_templates_next_date; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recurring_templates_next_date ON public.recurring_invoice_templates USING btree (next_invoice_date);


--
-- Name: idx_recurring_templates_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_recurring_templates_user ON public.recurring_invoice_templates USING btree (user_id);


--
-- Name: idx_risk_analysis_session; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_session ON public.auth_risk_analysis USING btree (session_id);


--
-- Name: idx_risk_analysis_timestamp; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_timestamp ON public.auth_risk_analysis USING btree (analyzed_at DESC);


--
-- Name: idx_risk_analysis_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_risk_analysis_user ON public.auth_risk_analysis USING btree (user_id);


--
-- Name: idx_sage_entities_lookup; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_entities_lookup ON public.sage_entities USING btree (account_id, entity_type, sage_id);


--
-- Name: idx_sage_ledger_nominal; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_ledger_nominal ON public.sage_ledger_accounts USING btree (account_id, nominal_code);


--
-- Name: idx_sage_sync_queue_pending; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sage_sync_queue_pending ON public.sage_sync_queue USING btree (account_id, status, priority DESC);


--
-- Name: idx_smart_contracts_owner; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_smart_contracts_owner ON public.smart_contracts USING btree (owner_id);


--
-- Name: idx_spending_limits_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_spending_limits_entity ON public.spending_limits USING btree (entity_type, entity_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_spending_limits_priority; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_spending_limits_priority ON public.spending_limits USING btree (priority DESC) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_spending_limits_reset; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_spending_limits_reset ON public.spending_limits USING btree (reset_time) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_spending_limits_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_spending_limits_type ON public.spending_limits USING btree (limit_type) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_spending_limits_usage; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_spending_limits_usage ON public.spending_limits USING btree (current_usage, limit_amount) WHERE ((is_active = true) AND (deleted_at IS NULL));


--
-- Name: idx_split_bills_creator; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_bills_creator ON public.split_bills USING btree (creator_id);


--
-- Name: idx_split_participants_bill; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_participants_bill ON public.split_bill_participants USING btree (split_bill_id);


--
-- Name: idx_split_participants_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_split_participants_user ON public.split_bill_participants USING btree (user_id);


--
-- Name: idx_sso_providers_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sso_providers_active ON public.sso_providers USING btree (is_active);


--
-- Name: idx_sso_providers_name; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_sso_providers_name ON public.sso_providers USING btree (provider_name);


--
-- Name: idx_stablecoin_balances_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_stablecoin_balances_user ON public.stablecoin_balances USING btree (user_id);


--
-- Name: idx_tenant_audit_logs_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_audit_logs_created_at ON public.tenant_audit_logs USING btree (created_at);


--
-- Name: idx_tenant_audit_logs_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_audit_logs_tenant_id ON public.tenant_audit_logs USING btree (tenant_id);


--
-- Name: idx_tenant_billing_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_billing_tenant_id ON public.tenant_billing USING btree (tenant_id);


--
-- Name: idx_tenant_transactions_created_at; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_transactions_created_at ON public.tenant_transactions USING btree (created_at);


--
-- Name: idx_tenant_transactions_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_transactions_tenant_id ON public.tenant_transactions USING btree (tenant_id);


--
-- Name: idx_tenant_users_role; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_role ON public.tenant_users USING btree (role);


--
-- Name: idx_tenant_users_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_status ON public.tenant_users USING btree (status);


--
-- Name: idx_tenant_users_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_tenant_id ON public.tenant_users USING btree (tenant_id);


--
-- Name: idx_tenant_users_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_users_user_id ON public.tenant_users USING btree (user_id);


--
-- Name: idx_tenant_wallets_tenant_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenant_wallets_tenant_id ON public.tenant_wallets USING btree (tenant_id);


--
-- Name: idx_tenants_code; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_code ON public.tenants USING btree (tenant_code);


--
-- Name: idx_tenants_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_status ON public.tenants USING btree (status);


--
-- Name: idx_tenants_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tenants_type ON public.tenants USING btree (type);


--
-- Name: idx_tillipay_cards_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tillipay_cards_user ON public.tillipay_cards USING btree (user_id);


--
-- Name: idx_tillipay_tx_card; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tillipay_tx_card ON public.tillipay_transactions USING btree (card_id);


--
-- Name: idx_tokens_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tokens_enterprise ON public.tokens USING btree (enterprise_id);


--
-- Name: idx_tokens_symbol; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_tokens_symbol ON public.tokens USING btree (token_symbol);


--
-- Name: idx_transactions_batch; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_batch ON public.transactions USING btree (batch_id);


--
-- Name: idx_transactions_hash; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_hash ON public.transactions USING btree (transaction_hash);


--
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- Name: idx_transactions_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_user ON public.transactions USING btree (user_id);


--
-- Name: idx_transactions_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_transactions_wallet ON public.transactions USING btree (wallet_id);


--
-- Name: idx_treasury_enterprise; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_enterprise ON public.treasury_accounts USING btree (enterprise_id);


--
-- Name: idx_treasury_swaps_created; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_created ON public.treasury_swaps USING btree (created_at);


--
-- Name: idx_treasury_swaps_organization; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_organization ON public.treasury_swaps USING btree (organization_id);


--
-- Name: idx_treasury_swaps_status; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_swaps_status ON public.treasury_swaps USING btree (status);


--
-- Name: idx_treasury_tx_account; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_tx_account ON public.treasury_transactions USING btree (treasury_account_id);


--
-- Name: idx_treasury_tx_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_treasury_tx_token ON public.treasury_transactions USING btree (token_id);


--
-- Name: idx_user_biometrics_active; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_active ON public.user_biometrics USING btree (user_id, is_active);


--
-- Name: idx_user_biometrics_device; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_device ON public.user_biometrics USING btree (device_id);


--
-- Name: idx_user_biometrics_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_biometrics_user ON public.user_biometrics USING btree (user_id);


--
-- Name: idx_user_devices_enhanced_device; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_device ON public.user_devices_enhanced USING btree (device_id);


--
-- Name: idx_user_devices_enhanced_trusted; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_trusted ON public.user_devices_enhanced USING btree (user_id, is_trusted);


--
-- Name: idx_user_devices_enhanced_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_devices_enhanced_user ON public.user_devices_enhanced USING btree (user_id);


--
-- Name: idx_user_mfa_enabled; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_mfa_enabled ON public.user_mfa_settings USING btree (user_id, is_enabled);


--
-- Name: idx_user_mfa_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_mfa_user ON public.user_mfa_settings USING btree (user_id);


--
-- Name: idx_user_profiles_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_profiles_type ON public.user_profiles USING btree (profile_type);


--
-- Name: idx_user_profiles_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_profiles_user_id ON public.user_profiles USING btree (user_id);


--
-- Name: idx_user_sso_external; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_external ON public.user_sso_connections USING btree (external_user_id);


--
-- Name: idx_user_sso_provider; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_provider ON public.user_sso_connections USING btree (provider_id);


--
-- Name: idx_user_sso_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_sso_user ON public.user_sso_connections USING btree (user_id);


--
-- Name: idx_user_tokens_token; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_tokens_token ON public.user_tokens USING btree (token);


--
-- Name: idx_user_tokens_user_id; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_user_tokens_user_id ON public.user_tokens USING btree (user_id);


--
-- Name: idx_users_account_locked; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_account_locked ON public.users USING btree (account_locked_until);


--
-- Name: idx_users_auth_level; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_auth_level ON public.users USING btree (auth_level);


--
-- Name: idx_users_custody_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_custody_type ON public.users USING btree (custody_type);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_verified; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_email_verified ON public.users USING btree (email_verified);


--
-- Name: idx_users_mobile; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_mobile ON public.users USING btree (mobile);


--
-- Name: idx_users_notification_preferences; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_notification_preferences ON public.users USING gin (notification_preferences);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone);


--
-- Name: idx_users_primary_contact; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_primary_contact ON public.users USING btree (primary_contact);


--
-- Name: idx_users_primary_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_primary_org ON public.users USING btree (primary_organization_id);


--
-- Name: idx_users_require_mfa; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_require_mfa ON public.users USING btree (require_mfa);


--
-- Name: idx_users_risk_profile; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_risk_profile ON public.users USING btree (risk_profile);


--
-- Name: idx_users_user_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_user_type ON public.users USING btree (user_type);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_users_whatsapp_enabled; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_whatsapp_enabled ON public.users USING btree (whatsapp_enabled);


--
-- Name: idx_users_whatsapp_number; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_users_whatsapp_number ON public.users USING btree (whatsapp_number);


--
-- Name: idx_violations_entity; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_violations_entity ON public.spending_limit_violations USING btree (entity_type, entity_id);


--
-- Name: idx_violations_occurred; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_violations_occurred ON public.spending_limit_violations USING btree (occurred_at);


--
-- Name: idx_wallet_events_type; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_type ON public.wallet_lifecycle_events USING btree (event_type);


--
-- Name: idx_wallet_events_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallet_events_wallet ON public.wallet_lifecycle_events USING btree (wallet_id);


--
-- Name: idx_wallets_address; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_address ON public.wallets USING btree (wallet_address);


--
-- Name: idx_wallets_org; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_org ON public.wallets USING btree (organization_id);


--
-- Name: idx_wallets_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_wallets_user ON public.wallets USING btree (user_id);


--
-- Name: idx_webauthn_credential; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webauthn_credential ON public.webauthn_credentials USING btree (credential_id);


--
-- Name: idx_webauthn_user; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_webauthn_user ON public.webauthn_credentials USING btree (user_id);


--
-- Name: idx_zk_proofs_wallet; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zk_proofs_wallet ON public.zk_compliance_proofs USING btree (wallet_id);


--
-- Name: idx_zoho_entities_lookup; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zoho_entities_lookup ON public.zoho_entities USING btree (account_id, entity_type, entity_id);


--
-- Name: idx_zoho_sync_history; Type: INDEX; Schema: public; Owner: alisaberi
--

CREATE INDEX idx_zoho_sync_history ON public.zoho_sync_history USING btree (account_id, entity_type, status);


--
-- Name: tenant_users check_tenant_user_validity; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER check_tenant_user_validity BEFORE INSERT OR UPDATE ON public.tenant_users FOR EACH ROW EXECUTE FUNCTION public.prevent_org_users_in_tenant_users();


--
-- Name: users ensure_user_consistency_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER ensure_user_consistency_trigger BEFORE INSERT OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.ensure_user_consistency();


--
-- Name: invoice_tokens invoice_tokens_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER invoice_tokens_updated_at BEFORE UPDATE ON public.invoice_tokens FOR EACH ROW EXECUTE FUNCTION public.update_invoice_updated_at();


--
-- Name: recurring_invoice_templates recurring_templates_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER recurring_templates_updated_at BEFORE UPDATE ON public.recurring_invoice_templates FOR EACH ROW EXECUTE FUNCTION public.update_invoice_updated_at();


--
-- Name: spending_limits spending_limits_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER spending_limits_updated_at_trigger BEFORE UPDATE ON public.spending_limits FOR EACH ROW EXECUTE FUNCTION public.update_spending_limits_updated_at();


--
-- Name: invoice_payments trigger_update_invoice_on_payment; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER trigger_update_invoice_on_payment AFTER INSERT OR UPDATE ON public.invoice_payments FOR EACH ROW EXECUTE FUNCTION public.update_invoice_status_on_payment();


--
-- Name: bill_payments update_bill_payments_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_bill_payments_updated_at BEFORE UPDATE ON public.bill_payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: consumer_preferences update_consumer_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_consumer_preferences_updated_at BEFORE UPDATE ON public.consumer_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: consumer_rewards update_consumer_rewards_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_consumer_rewards_updated_at BEFORE UPDATE ON public.consumer_rewards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: consumer_subscriptions update_consumer_subscriptions_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_consumer_subscriptions_updated_at BEFORE UPDATE ON public.consumer_subscriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: consumer_virtual_cards update_consumer_virtual_cards_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_consumer_virtual_cards_updated_at BEFORE UPDATE ON public.consumer_virtual_cards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoice_payments update_invoice_payments_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_invoice_payments_updated_at BEFORE UPDATE ON public.invoice_payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices update_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notifications update_notifications_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_notifications_updated_at_trigger BEFORE UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.update_notifications_updated_at();


--
-- Name: organizations update_organizations_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: p2p_transfers update_p2p_transfers_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_p2p_transfers_updated_at BEFORE UPDATE ON public.p2p_transfers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: auth_risk_analysis update_risk_profile_trigger; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_risk_profile_trigger AFTER INSERT ON public.auth_risk_analysis FOR EACH ROW EXECUTE FUNCTION public.update_user_risk_profile();


--
-- Name: stablecoin_balances update_stablecoin_balances_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_stablecoin_balances_updated_at BEFORE UPDATE ON public.stablecoin_balances FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: transactions update_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: wallets update_wallets_updated_at; Type: TRIGGER; Schema: public; Owner: alisaberi
--

CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_financial_insights ai_financial_insights_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ai_financial_insights
    ADD CONSTRAINT ai_financial_insights_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: auth_audit_log auth_audit_log_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: auth_audit_log auth_audit_log_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id);


--
-- Name: auth_audit_log auth_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_risk_analysis auth_risk_analysis_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.auth_sessions(id);


--
-- Name: auth_risk_analysis auth_risk_analysis_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_risk_analysis
    ADD CONSTRAINT auth_risk_analysis_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auth_sessions auth_sessions_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auto_topup_rules auto_topup_rules_source_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_source_payment_method_id_fkey FOREIGN KEY (source_payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: auto_topup_rules auto_topup_rules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: auto_topup_rules auto_topup_rules_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.auto_topup_rules
    ADD CONSTRAINT auto_topup_rules_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id);


--
-- Name: batch_transfer_recipients batch_transfer_recipients_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.batch_transfer_recipients
    ADD CONSTRAINT batch_transfer_recipients_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.batch_transfers(batch_id);


--
-- Name: batch_transfers batch_transfers_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.batch_transfers
    ADD CONSTRAINT batch_transfers_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: bill_payments bill_payments_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(id);


--
-- Name: bill_payments bill_payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: bill_payments bill_payments_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: bill_payments bill_payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bill_payments
    ADD CONSTRAINT bill_payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: billing_metrics billing_metrics_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.billing_metrics
    ADD CONSTRAINT billing_metrics_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: bills bills_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: bills bills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blockchain_transactions blockchain_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: blockchain_transactions blockchain_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_transactions
    ADD CONSTRAINT blockchain_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.blockchain_wallets(id);


--
-- Name: blockchain_wallets blockchain_wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.blockchain_wallets
    ADD CONSTRAINT blockchain_wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bridge_swaps bridge_swaps_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.bridge_swaps
    ADD CONSTRAINT bridge_swaps_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: business_rules business_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.business_rules
    ADD CONSTRAINT business_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: businesses businesses_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: charity_donations charity_donations_charity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_charity_id_fkey FOREIGN KEY (charity_id) REFERENCES public.charity_organizations(id);


--
-- Name: charity_donations charity_donations_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: charity_donations charity_donations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.charity_donations
    ADD CONSTRAINT charity_donations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: child_parents child_parents_child_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_child_id_fkey FOREIGN KEY (child_id) REFERENCES public.users(id);


--
-- Name: child_parents child_parents_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.child_parents
    ADD CONSTRAINT child_parents_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.users(id);


--
-- Name: compliance_checks compliance_checks_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: compliance_checks compliance_checks_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: compliance_checks compliance_checks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.compliance_checks
    ADD CONSTRAINT compliance_checks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: consumer_preferences consumer_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_preferences
    ADD CONSTRAINT consumer_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: consumer_rewards consumer_rewards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_rewards
    ADD CONSTRAINT consumer_rewards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: consumer_subscriptions consumer_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_subscriptions
    ADD CONSTRAINT consumer_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: consumer_virtual_cards consumer_virtual_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.consumer_virtual_cards
    ADD CONSTRAINT consumer_virtual_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: contract_interactions contract_interactions_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.smart_contracts(id);


--
-- Name: contract_interactions contract_interactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.contract_interactions
    ADD CONSTRAINT contract_interactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: custody_configurations custody_configurations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.custody_configurations
    ADD CONSTRAINT custody_configurations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: customer_credits customer_credits_applied_to_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_applied_to_invoice_id_fkey FOREIGN KEY (applied_to_invoice_id) REFERENCES public.invoices(id);


--
-- Name: customer_credits customer_credits_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.users(id);


--
-- Name: customer_credits customer_credits_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: customer_credits customer_credits_source_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.customer_credits
    ADD CONSTRAINT customer_credits_source_invoice_id_fkey FOREIGN KEY (source_invoice_id) REFERENCES public.invoices(id);


--
-- Name: enterprise_ramps enterprise_ramps_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_ramps
    ADD CONSTRAINT enterprise_ramps_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: enterprise_treasuries enterprise_treasuries_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.enterprise_treasuries
    ADD CONSTRAINT enterprise_treasuries_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: gift_cards gift_cards_purchaser_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_purchaser_id_fkey FOREIGN KEY (purchaser_id) REFERENCES public.users(id);


--
-- Name: gift_cards gift_cards_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: invoice_attachments invoice_attachments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_attachments
    ADD CONSTRAINT invoice_attachments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id) ON DELETE CASCADE;


--
-- Name: invoice_batch_items invoice_batch_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.invoice_batches(batch_id) ON DELETE CASCADE;


--
-- Name: invoice_batch_items invoice_batch_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batch_items
    ADD CONSTRAINT invoice_batch_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id);


--
-- Name: invoice_batches invoice_batches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_batches
    ADD CONSTRAINT invoice_batches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: invoice_events invoice_events_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_events invoice_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_events
    ADD CONSTRAINT invoice_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: invoice_line_items invoice_line_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payment_methods invoice_payment_methods_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payment_methods
    ADD CONSTRAINT invoice_payment_methods_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoice_tokens(invoice_id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.users(id);


--
-- Name: invoice_templates invoice_templates_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_templates
    ADD CONSTRAINT invoice_templates_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: invoice_tokens invoice_tokens_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id);


--
-- Name: invoice_tokens invoice_tokens_paid_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_paid_by_user_id_fkey FOREIGN KEY (paid_by_user_id) REFERENCES public.users(id);


--
-- Name: invoice_tokens invoice_tokens_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_tokens
    ADD CONSTRAINT invoice_tokens_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: invoice_wallets invoice_wallets_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoice_wallets
    ADD CONSTRAINT invoice_wallets_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: invoices invoices_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: kyc_sessions kyc_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.kyc_sessions
    ADD CONSTRAINT kyc_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: loyalty_transactions loyalty_transactions_reference_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_reference_transaction_id_fkey FOREIGN KEY (reference_transaction_id) REFERENCES public.transactions(id);


--
-- Name: loyalty_transactions loyalty_transactions_reward_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_reward_program_id_fkey FOREIGN KEY (reward_program_id) REFERENCES public.loyalty_rewards(id);


--
-- Name: loyalty_transactions loyalty_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: magic_links magic_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: multi_sig_transactions multi_sig_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: multi_sig_transactions multi_sig_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_transactions
    ADD CONSTRAINT multi_sig_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.multi_sig_wallets(id);


--
-- Name: multi_sig_wallets multi_sig_wallets_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.multi_sig_wallets
    ADD CONSTRAINT multi_sig_wallets_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_fromUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_fromUserId_fkey" FOREIGN KEY ("fromUserId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_toUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_toUserId_fkey" FOREIGN KEY ("toUserId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id);


--
-- Name: organization_users organization_users_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON DELETE CASCADE;


--
-- Name: organization_users organization_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organization_users
    ADD CONSTRAINT organization_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: organizations organizations_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.organizations(id);


--
-- Name: organizations organizations_parent_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_parent_organization_id_fkey FOREIGN KEY (parent_organization_id) REFERENCES public.organizations(id);


--
-- Name: organizations organizations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: p2p_transfers p2p_transfers_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.p2p_transfers
    ADD CONSTRAINT p2p_transfers_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: p2p_transfers p2p_transfers_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.p2p_transfers
    ADD CONSTRAINT p2p_transfers_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id);


--
-- Name: payment_methods payment_methods_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payment_requests payment_requests_payer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_payer_id_fkey FOREIGN KEY (payer_id) REFERENCES public.users(id);


--
-- Name: payment_requests payment_requests_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.payment_requests
    ADD CONSTRAINT payment_requests_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: quantum_key_registry quantum_key_registry_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.quantum_key_registry
    ADD CONSTRAINT quantum_key_registry_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: ready_cash_loans ready_cash_loans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.ready_cash_loans
    ADD CONSTRAINT ready_cash_loans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: recurring_invoice_templates recurring_invoice_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.recurring_invoice_templates
    ADD CONSTRAINT recurring_invoice_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: sage_bank_reconciliations sage_bank_reconciliations_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_bank_reconciliations
    ADD CONSTRAINT sage_bank_reconciliations_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_entities sage_entities_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_entities
    ADD CONSTRAINT sage_entities_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_journal_entries sage_journal_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_journal_entries
    ADD CONSTRAINT sage_journal_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_ledger_accounts sage_ledger_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_ledger_accounts
    ADD CONSTRAINT sage_ledger_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_sync_queue sage_sync_queue_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_sync_queue
    ADD CONSTRAINT sage_sync_queue_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: sage_tax_returns sage_tax_returns_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.sage_tax_returns
    ADD CONSTRAINT sage_tax_returns_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.sage_connections(account_id);


--
-- Name: smart_contracts smart_contracts_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.smart_contracts
    ADD CONSTRAINT smart_contracts_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: spending_limit_overrides spending_limit_overrides_spending_limit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limit_overrides
    ADD CONSTRAINT spending_limit_overrides_spending_limit_id_fkey FOREIGN KEY (spending_limit_id) REFERENCES public.spending_limits(id) ON DELETE CASCADE;


--
-- Name: spending_limit_violations spending_limit_violations_spending_limit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.spending_limit_violations
    ADD CONSTRAINT spending_limit_violations_spending_limit_id_fkey FOREIGN KEY (spending_limit_id) REFERENCES public.spending_limits(id) ON DELETE SET NULL;


--
-- Name: split_bill_participants split_bill_participants_split_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_split_bill_id_fkey FOREIGN KEY (split_bill_id) REFERENCES public.split_bills(id) ON DELETE CASCADE;


--
-- Name: split_bill_participants split_bill_participants_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: split_bill_participants split_bill_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bill_participants
    ADD CONSTRAINT split_bill_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: split_bills split_bills_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.split_bills
    ADD CONSTRAINT split_bills_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: stablecoin_balances stablecoin_balances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.stablecoin_balances
    ADD CONSTRAINT stablecoin_balances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: super_app_bookings super_app_bookings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.super_app_bookings
    ADD CONSTRAINT super_app_bookings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tenant_audit_logs tenant_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_audit_logs tenant_audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_audit_logs
    ADD CONSTRAINT tenant_audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tenant_billing tenant_billing_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_billing
    ADD CONSTRAINT tenant_billing_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_transactions tenant_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_transactions tenant_transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_transactions
    ADD CONSTRAINT tenant_transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.tenant_wallets(id);


--
-- Name: tenant_users tenant_users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_users tenant_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_users
    ADD CONSTRAINT tenant_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tenant_vault_keys tenant_vault_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_vault_keys
    ADD CONSTRAINT tenant_vault_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_wallets tenant_wallets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tenant_wallets
    ADD CONSTRAINT tenant_wallets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tillipay_cards tillipay_cards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_cards
    ADD CONSTRAINT tillipay_cards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tillipay_transactions tillipay_transactions_card_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tillipay_transactions
    ADD CONSTRAINT tillipay_transactions_card_id_fkey FOREIGN KEY (card_id) REFERENCES public.tillipay_cards(id);


--
-- Name: tokens tokens_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_from_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_from_user_id_fkey FOREIGN KEY (from_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_to_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_to_user_id_fkey FOREIGN KEY (to_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.wallets(id);


--
-- Name: treasury_accounts treasury_accounts_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_accounts
    ADD CONSTRAINT treasury_accounts_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.users(id);


--
-- Name: treasury_swaps treasury_swaps_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_swaps
    ADD CONSTRAINT treasury_swaps_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: treasury_transactions treasury_transactions_blockchain_tx_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_blockchain_tx_id_fkey FOREIGN KEY (blockchain_tx_id) REFERENCES public.blockchain_transactions(id);


--
-- Name: treasury_transactions treasury_transactions_executed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_executed_by_fkey FOREIGN KEY (executed_by) REFERENCES public.users(id);


--
-- Name: treasury_transactions treasury_transactions_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.tokens(id);


--
-- Name: treasury_transactions treasury_transactions_treasury_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.treasury_transactions
    ADD CONSTRAINT treasury_transactions_treasury_account_id_fkey FOREIGN KEY (treasury_account_id) REFERENCES public.treasury_accounts(id);


--
-- Name: user_biometrics user_biometrics_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.user_devices_enhanced(id);


--
-- Name: user_biometrics user_biometrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_biometrics
    ADD CONSTRAINT user_biometrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_devices_enhanced user_devices_enhanced_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_devices_enhanced
    ADD CONSTRAINT user_devices_enhanced_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_mfa_settings user_mfa_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_mfa_settings
    ADD CONSTRAINT user_mfa_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_profiles user_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sso_connections user_sso_connections_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.sso_providers(id);


--
-- Name: user_sso_connections user_sso_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_sso_connections
    ADD CONSTRAINT user_sso_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_tokens user_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT user_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_primary_organization_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_organization_fkey FOREIGN KEY (primary_organization_id) REFERENCES public.organizations(id);


--
-- Name: users users_primary_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_primary_organization_id_fkey FOREIGN KEY (primary_organization_id) REFERENCES public.organizations(id);


--
-- Name: wallet_lifecycle_events wallet_lifecycle_events_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_lifecycle_events
    ADD CONSTRAINT wallet_lifecycle_events_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: wallet_mode_decisions wallet_mode_decisions_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallet_mode_decisions
    ADD CONSTRAINT wallet_mode_decisions_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: wallets wallets_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id);


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: zk_compliance_proofs zk_compliance_proofs_wallet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zk_compliance_proofs
    ADD CONSTRAINT zk_compliance_proofs_wallet_id_fkey FOREIGN KEY (wallet_id) REFERENCES public.invoice_wallets(id);


--
-- Name: zoho_automation_rules zoho_automation_rules_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_automation_rules
    ADD CONSTRAINT zoho_automation_rules_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_entities zoho_entities_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_entities
    ADD CONSTRAINT zoho_entities_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_recurring_profiles zoho_recurring_profiles_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_recurring_profiles
    ADD CONSTRAINT zoho_recurring_profiles_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_sync_history zoho_sync_history_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_sync_history
    ADD CONSTRAINT zoho_sync_history_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: zoho_tax_rules zoho_tax_rules_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alisaberi
--

ALTER TABLE ONLY public.zoho_tax_rules
    ADD CONSTRAINT zoho_tax_rules_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.zoho_connections(account_id);


--
-- Name: tenant_audit_logs; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_audit_logs tenant_audit_logs_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_audit_logs_isolation_policy ON public.tenant_audit_logs USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_settings tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_settings USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_transactions tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_transactions USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_wallets tenant_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_isolation_policy ON public.tenant_wallets USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_transactions; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_users; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_users ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_users tenant_users_isolation_policy; Type: POLICY; Schema: public; Owner: alisaberi
--

CREATE POLICY tenant_users_isolation_policy ON public.tenant_users USING (((tenant_id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenant_wallets; Type: ROW SECURITY; Schema: public; Owner: alisaberi
--

ALTER TABLE public.tenant_wallets ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict ba7VW0oln19ewAOKkQ2gyTLOHkRZQ0g3w0Ok7CczoAWvOERK1SAQjbKoit7YKZp

